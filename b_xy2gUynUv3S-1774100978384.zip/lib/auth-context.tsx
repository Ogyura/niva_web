"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface Achievement {
  id: string
  name: string
  description: string
  icon: string
  unlockedAt?: string
  game?: string
}

export interface GameStats {
  gameId: string
  gameName: string
  highScore: number
  gamesPlayed: number
  totalScore: number
  bestTime?: number
  lastPlayed?: string
}

export interface User {
  id: string
  email: string
  username: string
  avatar?: string
  createdAt: string
  achievements: Achievement[]
  gameStats: GameStats[]
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<boolean>
  register: (email: string, username: string, password: string) => Promise<{ success: boolean; code?: string }>
  verifyCode: (email: string, code: string) => Promise<boolean>
  logout: () => void
  updateGameStats: (gameId: string, gameName: string, score: number, time?: number) => void
  unlockAchievement: (achievement: Omit<Achievement, 'unlockedAt'>) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  { id: "first-game", name: "Первая игра", description: "Сыграйте в любую игру", icon: "gamepad" },
  { id: "score-1000", name: "Тысячник", description: "Наберите 1000 очков в любой игре", icon: "trophy" },
  { id: "score-5000", name: "Мастер", description: "Наберите 5000 очков в любой игре", icon: "star" },
  { id: "play-5", name: "Завсегдатай", description: "Сыграйте 5 игр", icon: "repeat" },
  { id: "play-all", name: "Коллекционер", description: "Сыграйте во все игры", icon: "grid" },
  { id: "hill-master", name: "Горный король", description: "Наберите 3000 очков в Hill Climb", icon: "mountain", game: "hill-climb" },
  { id: "shooter-pro", name: "Меткий стрелок", description: "Пройдите 5 волн в Shooter", icon: "target", game: "virus-shooter" },
  { id: "puzzle-expert", name: "Эксперт пазлов", description: "Соберите 20 линий в Puzzle", icon: "puzzle", game: "virus-puzzle" },
]

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const savedUser = localStorage.getItem("ddos-guard-user")
    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser)
        // Migrate old users
        if (!parsed.email) {
          parsed.email = parsed.username + "@ddos-guard.net"
        }
        if (!parsed.achievements) {
          parsed.achievements = []
        }
        if (!parsed.gameStats) {
          parsed.gameStats = []
        }
        if (!parsed.createdAt) {
          parsed.createdAt = new Date().toISOString()
        }
        setUser(parsed)
      } catch {
        localStorage.removeItem("ddos-guard-user")
      }
    }
    setIsLoading(false)
  }, [])

  const saveUser = (userData: User) => {
    setUser(userData)
    localStorage.setItem("ddos-guard-user", JSON.stringify(userData))
    localStorage.setItem("ddosGuardUser", userData.username)
  }

  const login = async (email: string, password: string): Promise<boolean> => {
    await new Promise((resolve) => setTimeout(resolve, 500))
    
    // Check stored users
    const storedUsers = JSON.parse(localStorage.getItem("ddos-guard-users") || "[]")
    const existingUser = storedUsers.find((u: { email: string; password: string }) => 
      u.email === email && u.password === password
    )
    
    if (existingUser) {
      const userData: User = {
        id: existingUser.id,
        email: existingUser.email,
        username: existingUser.username,
        avatar: "/images/mascot.png",
        createdAt: existingUser.createdAt || new Date().toISOString(),
        achievements: existingUser.achievements || [],
        gameStats: existingUser.gameStats || [],
      }
      saveUser(userData)
      return true
    }
    
    return false
  }

  const register = async (email: string, username: string, password: string): Promise<{ success: boolean; code?: string }> => {
    await new Promise((resolve) => setTimeout(resolve, 500))
    
    if (!email.includes("@") || password.length < 4 || username.length < 3) {
      return { success: false }
    }
    
    // Check if user exists
    const storedUsers = JSON.parse(localStorage.getItem("ddos-guard-users") || "[]")
    const exists = storedUsers.find((u: { email: string }) => u.email === email)
    
    if (exists) {
      return { success: false }
    }
    
    // Generate verification code
    const code = Math.floor(100000 + Math.random() * 900000).toString()
    
    // Store pending registration
    localStorage.setItem("ddos-guard-pending", JSON.stringify({
      email,
      username,
      password,
      code,
      createdAt: new Date().toISOString(),
    }))
    
    return { success: true, code }
  }

  const verifyCode = async (email: string, inputCode: string): Promise<boolean> => {
    await new Promise((resolve) => setTimeout(resolve, 300))
    
    const pending = JSON.parse(localStorage.getItem("ddos-guard-pending") || "{}")
    
    if (pending.email === email && pending.code === inputCode) {
      const storedUsers = JSON.parse(localStorage.getItem("ddos-guard-users") || "[]")
      
      const newUserData = {
        id: Math.random().toString(36).substring(7),
        email: pending.email,
        username: pending.username,
        password: pending.password,
        createdAt: pending.createdAt,
        achievements: [],
        gameStats: [],
      }
      
      storedUsers.push(newUserData)
      localStorage.setItem("ddos-guard-users", JSON.stringify(storedUsers))
      localStorage.removeItem("ddos-guard-pending")
      
      const userData: User = {
        id: newUserData.id,
        email: newUserData.email,
        username: newUserData.username,
        avatar: "/images/mascot.png",
        createdAt: newUserData.createdAt,
        achievements: [],
        gameStats: [],
      }
      
      saveUser(userData)
      return true
    }
    
    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("ddos-guard-user")
    localStorage.removeItem("ddosGuardUser")
  }

  const updateGameStats = (gameId: string, gameName: string, score: number, time?: number) => {
    if (!user) return
    
    const updatedStats = [...user.gameStats]
    const existingIndex = updatedStats.findIndex(s => s.gameId === gameId)
    
    if (existingIndex >= 0) {
      const existing = updatedStats[existingIndex]
      updatedStats[existingIndex] = {
        ...existing,
        highScore: Math.max(existing.highScore, score),
        gamesPlayed: existing.gamesPlayed + 1,
        totalScore: existing.totalScore + score,
        bestTime: time ? (existing.bestTime ? Math.min(existing.bestTime, time) : time) : existing.bestTime,
        lastPlayed: new Date().toISOString(),
      }
    } else {
      updatedStats.push({
        gameId,
        gameName,
        highScore: score,
        gamesPlayed: 1,
        totalScore: score,
        bestTime: time,
        lastPlayed: new Date().toISOString(),
      })
    }
    
    const updatedUser = { ...user, gameStats: updatedStats }
    
    // Check for achievements
    const totalGames = updatedStats.reduce((sum, s) => sum + s.gamesPlayed, 0)
    const uniqueGames = updatedStats.length
    const maxScore = Math.max(...updatedStats.map(s => s.highScore))
    
    if (totalGames >= 1 && !user.achievements.find(a => a.id === "first-game")) {
      unlockAchievementInternal(updatedUser, DEFAULT_ACHIEVEMENTS.find(a => a.id === "first-game")!)
    }
    if (totalGames >= 5 && !user.achievements.find(a => a.id === "play-5")) {
      unlockAchievementInternal(updatedUser, DEFAULT_ACHIEVEMENTS.find(a => a.id === "play-5")!)
    }
    if (uniqueGames >= 10 && !user.achievements.find(a => a.id === "play-all")) {
      unlockAchievementInternal(updatedUser, DEFAULT_ACHIEVEMENTS.find(a => a.id === "play-all")!)
    }
    if (maxScore >= 1000 && !user.achievements.find(a => a.id === "score-1000")) {
      unlockAchievementInternal(updatedUser, DEFAULT_ACHIEVEMENTS.find(a => a.id === "score-1000")!)
    }
    if (maxScore >= 5000 && !user.achievements.find(a => a.id === "score-5000")) {
      unlockAchievementInternal(updatedUser, DEFAULT_ACHIEVEMENTS.find(a => a.id === "score-5000")!)
    }
    
    // Game specific achievements
    const hillStats = updatedStats.find(s => s.gameId === "hill-climb")
    if (hillStats && hillStats.highScore >= 3000 && !user.achievements.find(a => a.id === "hill-master")) {
      unlockAchievementInternal(updatedUser, DEFAULT_ACHIEVEMENTS.find(a => a.id === "hill-master")!)
    }
    
    saveUser(updatedUser)
    
    // Also update stored users
    const storedUsers = JSON.parse(localStorage.getItem("ddos-guard-users") || "[]")
    const userIndex = storedUsers.findIndex((u: { email: string }) => u.email === user.email)
    if (userIndex >= 0) {
      storedUsers[userIndex] = { ...storedUsers[userIndex], gameStats: updatedStats, achievements: updatedUser.achievements }
      localStorage.setItem("ddos-guard-users", JSON.stringify(storedUsers))
    }
  }

  const unlockAchievementInternal = (userData: User, achievement: Omit<Achievement, 'unlockedAt'>) => {
    if (!userData.achievements.find(a => a.id === achievement.id)) {
      userData.achievements.push({
        ...achievement,
        unlockedAt: new Date().toISOString(),
      })
    }
  }

  const unlockAchievement = (achievement: Omit<Achievement, 'unlockedAt'>) => {
    if (!user) return
    if (user.achievements.find(a => a.id === achievement.id)) return
    
    const updatedUser = {
      ...user,
      achievements: [
        ...user.achievements,
        { ...achievement, unlockedAt: new Date().toISOString() }
      ]
    }
    saveUser(updatedUser)
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      isLoading, 
      login, 
      register, 
      verifyCode, 
      logout,
      updateGameStats,
      unlockAchievement
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export { DEFAULT_ACHIEVEMENTS }
