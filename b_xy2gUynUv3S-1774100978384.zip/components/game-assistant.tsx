"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { X, MessageCircle, Send, Bot, ChevronDown, Gamepad2, HelpCircle } from "lucide-react"

interface GameAssistantProps {
  onClose: () => void
}

interface GameQuestion {
  id: string
  question: string
  answer: string
}

interface GameInfo {
  id: string
  name: string
  description: string
  questions: GameQuestion[]
}

const GAME_DATA: GameInfo[] = [
  {
    id: "hill-climb",
    name: "Virus Hill Climb",
    description: "Гонки по холмам с физикой и сбором вирусов",
    questions: [
      {
        id: "hc1",
        question: "Как управлять машиной?",
        answer: "Используйте клавиши A/D или стрелки влево/вправо. D или стрелка вправо - газ, A или стрелка влево - тормоз. Также можно нажимать на педали на экране мышкой."
      },
      {
        id: "hc2",
        question: "Как получить больше топлива?",
        answer: "Собирайте вирусы на трассе! Каждый вирус дает вам топливо и очки. Красные вирусы дают 5 очков, зеленые 25 очков, синие 100 очков. Все вирусы восполняют 8 единиц топлива."
      },
      {
        id: "hc3",
        question: "Почему игра заканчивается?",
        answer: "Игра заканчивается в трех случаях: 1) Истекло время (2 минуты), 2) Закончилось топливо и машина остановилась, 3) Машина перевернулась (угол наклона больше 108 градусов)."
      },
      {
        id: "hc4",
        question: "Как набрать максимум очков?",
        answer: "Старайтесь ехать быстро и собирать все вирусы на пути. Синие вирусы дают максимум очков (100). Следите за топливом и не переворачивайтесь на крутых холмах!"
      },
      {
        id: "hc5",
        question: "Что показывают датчики внизу?",
        answer: "Левый датчик показывает RPM (обороты двигателя), правый - BOOST (ускорение). Сверху слева - полоска топлива и текущие очки. По центру - оставшееся время и пройденная дистанция."
      }
    ]
  },
  {
    id: "virus-shooter",
    name: "Virus Shooter",
    description: "Шутер по вирусам с турелью",
    questions: [
      {
        id: "vs1",
        question: "Как стрелять по вирусам?",
        answer: "Наведите мышку на вирус и кликните для выстрела. Турель автоматически поворачивается в сторону курсора. Чем быстрее кликаете - тем больше пуль выпустите."
      },
      {
        id: "vs2",
        question: "Что делают бонусы?",
        answer: "R (Rapid Fire) - ускоренная стрельба на 5 секунд. S (Shield) - восполняет 30% щита. B (Bomb) - уничтожает всех вирусов на экране. Бонусы падают сверху, ловите их турелью."
      },
      {
        id: "vs3",
        question: "Как работает щит?",
        answer: "Когда вирус достигает нижней части экрана, вы теряете 10% щита. Если щит опустится до 0%, игра окончена. Собирайте бонус S чтобы восстановить щит."
      },
      {
        id: "vs4",
        question: "Чем отличаются вирусы?",
        answer: "Зеленые вирусы (2 HP, 100 очков) - самые слабые. Красные вирусы (4 HP, 200 очков) - средние. Фиолетовые вирусы (6 HP, 300 очков) - самые крепкие. Чем выше волна, тем больше сильных вирусов."
      },
      {
        id: "vs5",
        question: "Как пройти дальше по волнам?",
        answer: "Каждые 10 убитых вирусов - новая волна. Вирусы становятся быстрее и их больше. Используйте бомбы для экстренных ситуаций и старайтесь не пропускать бонусы Rapid Fire для увеличения урона."
      }
    ]
  },
  {
    id: "virus-puzzle",
    name: "Virus Puzzle",
    description: "Тетрис с вирусными блоками",
    questions: [
      {
        id: "vp1",
        question: "Как управлять фигурами?",
        answer: "Стрелки влево/вправо или A/D - двигать фигуру. Стрелка вверх или W - повернуть фигуру. Стрелка вниз или S - ускорить падение. Пробел - мгновенно сбросить фигуру вниз (hard drop)."
      },
      {
        id: "vp2",
        question: "Как набирать очки?",
        answer: "Заполните горизонтальную линию полностью - она исчезнет и даст очки. 1 линия = 100 очков, 2 линии = 300 очков, 3 линии = 500 очков, 4 линии (Tetris) = 800 очков. Очки умножаются на текущий уровень!"
      },
      {
        id: "vp3",
        question: "Как повышается уровень?",
        answer: "Каждые 10 собранных линий повышают уровень. С каждым уровнем фигуры падают быстрее, но очки за линии умножаются на номер уровня. На уровне 5 вы получите 500 очков за одну линию!"
      },
      {
        id: "vp4",
        question: "Что показывает призрак фигуры?",
        answer: "Полупрозрачная фигура внизу показывает, куда упадет текущая фигура. Это помогает планировать размещение и делать точные hard drop нажатием пробела."
      },
      {
        id: "vp5",
        question: "Почему игра заканчивается?",
        answer: "Игра заканчивается когда: 1) Истекло время (2 минуты), или 2) Новая фигура не может появиться, потому что стопка блоков достигла верха поля. Старайтесь не оставлять дырок в рядах!"
      }
    ]
  },
  {
    id: "flappy-virus",
    name: "Flappy Virus",
    description: "Пролетай между препятствиями",
    questions: [
      {
        id: "fv1",
        question: "Как управлять вирусом?",
        answer: "Нажимайте любую клавишу, пробел или кликайте мышкой чтобы подпрыгнуть. Вирус постоянно падает вниз под действием гравитации, поэтому нужно регулярно подпрыгивать."
      },
      {
        id: "fv2",
        question: "Как набирать очки?",
        answer: "Вы получаете 1 очко за каждый пролет между трубами. Чем дольше летите - тем больше очков. Старайтесь пролетать точно по центру между трубами."
      },
      {
        id: "fv3",
        question: "Почему так сложно?",
        answer: "Это классическая игра, основанная на Flappy Bird. Ключ к успеху - мягкие, частые нажатия вместо резких прыжков. Привыкните к физике падения и прыжка."
      },
      {
        id: "fv4",
        question: "Какие есть советы?",
        answer: "1) Смотрите на следующую трубу заранее. 2) Не паникуйте после прохождения - сразу готовьтесь к следующей. 3) Лучше пролететь чуть выше центра, чем задеть нижнюю трубу."
      },
      {
        id: "fv5",
        question: "Есть ли бонусы?",
        answer: "В этой версии бонусов нет - чистый геймплей на рефлексы и точность. Сосредоточьтесь на ритме прыжков и предсказании траектории полета."
      }
    ]
  },
  {
    id: "virus-snake",
    name: "Virus Snake",
    description: "Классическая змейка в мире вирусов",
    questions: [
      {
        id: "sn1",
        question: "Как управлять змейкой?",
        answer: "Используйте стрелки или WASD для поворота. Змейка постоянно движется вперед, вы можете только поворачивать. Нельзя развернуться на 180 градусов!"
      },
      {
        id: "sn2",
        question: "Что нужно собирать?",
        answer: "Собирайте клетки (еду) на поле. Каждая съеденная клетка удлиняет змейку и дает очки. Чем длиннее змейка - тем сложнее маневрировать."
      },
      {
        id: "sn3",
        question: "Когда игра заканчивается?",
        answer: "Игра заканчивается если: 1) Змейка врежется в стену (край поля), 2) Змейка врежется в своё тело, 3) Истечет время (2 минуты)."
      },
      {
        id: "sn4",
        question: "Как набрать больше очков?",
        answer: "Двигайтесь эффективно, не делайте лишних поворотов. Планируйте маршрут заранее, особенно когда змейка длинная. Используйте пространство поля рационально."
      },
      {
        id: "sn5",
        question: "Есть ли разные уровни сложности?",
        answer: "Сложность растет автоматически - чем длиннее змейка, тем труднее управлять. Скорость остается постоянной, но пространство для маневра уменьшается."
      }
    ]
  },
  {
    id: "virus-pong",
    name: "Virus Pong",
    description: "Классический понг против ИИ",
    questions: [
      {
        id: "pg1",
        question: "Как управлять ракеткой?",
        answer: "Двигайте мышкой вверх-вниз или используйте стрелки/клавиши W и S. Ваша ракетка слева, ракетка ИИ справа."
      },
      {
        id: "pg2",
        question: "Как начисляются очки?",
        answer: "Когда мяч пролетает мимо ракетки противника - вы получаете очко. Когда мяч пролетает мимо вашей ракетки - очко получает ИИ. Игра до 10 очков или до истечения времени."
      },
      {
        id: "pg3",
        question: "Почему мяч летит быстрее?",
        answer: "Мяч ускоряется с каждым отбитием. Чем дольше длится розыгрыш, тем быстрее мяч. После гола скорость сбрасывается."
      },
      {
        id: "pg4",
        question: "Как обыграть ИИ?",
        answer: "ИИ следит за мячом, но не идеально. Старайтесь отбивать мяч краями ракетки для изменения угла полета. Резкие углы сложнее для ИИ."
      },
      {
        id: "pg5",
        question: "Можно играть вдвоём?",
        answer: "В текущей версии только игра против ИИ. Второй игрок управляется компьютером. Сосредоточьтесь на точном позиционировании ракетки."
      }
    ]
  },
  {
    id: "virus-memory",
    name: "Virus Memory",
    description: "Найди пары одинаковых вирусов",
    questions: [
      {
        id: "mm1",
        question: "Как играть?",
        answer: "Кликайте на карточки чтобы перевернуть их. Запоминайте где какой вирус. Найдите две одинаковые карточки подряд - они останутся открытыми."
      },
      {
        id: "mm2",
        question: "Как начисляются очки?",
        answer: "Найденная пара = очки. Чем быстрее находите пары подряд, тем больше бонус за комбо. Ошибки не штрафуются, но тратят время."
      },
      {
        id: "mm3",
        question: "Какие есть советы?",
        answer: "1) Запоминайте позиции даже неудачных попыток. 2) Начните с углов и краев. 3) Создавайте мысленную карту расположения. 4) Не торопитесь - думайте перед кликом."
      },
      {
        id: "mm4",
        question: "Сколько пар нужно найти?",
        answer: "На поле 16 карточек (4x4) = 8 пар. Найдите все пары до истечения времени. С каждым успешным раундом сложность может увеличиться."
      },
      {
        id: "mm5",
        question: "Что улучшает память?",
        answer: "Эта игра тренирует кратковременную визуальную память. Регулярная игра улучшает способность запоминать расположение объектов и концентрацию."
      }
    ]
  },
  {
    id: "virus-breakout",
    name: "Virus Breakout",
    description: "Арканоид с вирусными блоками",
    questions: [
      {
        id: "bo1",
        question: "Как управлять платформой?",
        answer: "Двигайте мышкой влево-вправо или используйте стрелки/клавиши A и D. Платформа движется только горизонтально внизу экрана."
      },
      {
        id: "bo2",
        question: "Как разбивать блоки?",
        answer: "Отбивайте мяч платформой так, чтобы он попадал в блоки сверху. Каждый блок разбивается от попадания мяча и дает очки."
      },
      {
        id: "bo3",
        question: "Что если мяч упадёт?",
        answer: "Если мяч пролетит мимо платформы внизу, вы теряете жизнь. Всего 3 жизни. После потери жизни мяч появляется на платформе заново."
      },
      {
        id: "bo4",
        question: "Есть ли бонусы?",
        answer: "Некоторые блоки содержат бонусы: расширение платформы, дополнительный мяч, замедление. Ловите падающие бонусы платформой!"
      },
      {
        id: "bo5",
        question: "Как изменить угол отскока?",
        answer: "Угол отскока зависит от того, какой частью платформы вы отбиваете мяч. Край платформы дает более острый угол, центр - прямой отскок."
      }
    ]
  },
  {
    id: "virus-defense",
    name: "Virus Defense",
    description: "Защита базы от волн вирусов",
    questions: [
      {
        id: "td1",
        question: "Как играть в tower defense?",
        answer: "Кликайте на свободные места чтобы ставить башни. Башни автоматически стреляют по вирусам. Вирусы идут по определенному пути к вашей базе."
      },
      {
        id: "td2",
        question: "Какие есть башни?",
        answer: "Базовая башня - дешевая, средний урон. Снайперская - дорогая, высокий урон, медленная. Пулеметная - быстрая стрельба, малый урон. Выбирайте под ситуацию!"
      },
      {
        id: "td3",
        question: "Как получить деньги на башни?",
        answer: "Убитые вирусы дают золото. В начале у вас есть стартовый капитал. Планируйте экономно - не ставьте все башни сразу."
      },
      {
        id: "td4",
        question: "Когда игра заканчивается?",
        answer: "Если вирус дойдет до базы - вы теряете здоровье. Когда здоровье опустится до 0, игра окончена. Или когда истечет время."
      },
      {
        id: "td5",
        question: "Какая стратегия лучше?",
        answer: "Ставьте башни в узких местах пути. Комбинируйте разные типы башен. Не тратьте все деньги - оставляйте запас на экстренные случаи."
      }
    ]
  },
  {
    id: "virus-runner",
    name: "Virus Runner",
    description: "Бесконечный раннер с препятствиями",
    questions: [
      {
        id: "rn1",
        question: "Как управлять?",
        answer: "Пробел или стрелка вверх - прыжок. Стрелка вниз - пригнуться (скольжение). Персонаж бежит автоматически, вы управляете только прыжками и приседаниями."
      },
      {
        id: "rn2",
        question: "Какие есть препятствия?",
        answer: "Низкие препятствия - перепрыгивайте. Высокие препятствия - приседайте и проскальзывайте под ними. Вирусы - избегайте столкновения любым способом."
      },
      {
        id: "rn3",
        question: "Как набирать очки?",
        answer: "Очки растут автоматически по мере бега. Чем дальше пробежите - тем больше очков. Можно собирать бонусные монетки на пути для дополнительных очков."
      },
      {
        id: "rn4",
        question: "Почему становится сложнее?",
        answer: "Скорость бега постепенно увеличивается. Препятствия появляются чаще и в более сложных комбинациях. Нужны быстрые реакции!"
      },
      {
        id: "rn5",
        question: "Есть ли секреты?",
        answer: "Смотрите вперед, а не на персонажа. Привыкните к таймингу прыжков. Иногда лучше пригнуться чем прыгать. Практика - ключ к успеху!"
      }
    ]
  }
]

export function GameAssistant({ onClose }: GameAssistantProps) {
  const [selectedGame, setSelectedGame] = useState<string | null>(null)
  const [selectedQuestion, setSelectedQuestion] = useState<string | null>(null)
  const [chatHistory, setChatHistory] = useState<Array<{ type: 'user' | 'bot'; text: string }>>([
    { type: 'bot', text: 'Привет! Я помощник по играм DDOS-GUARD. Выберите игру, чтобы получить ответы на вопросы.' }
  ])

  const currentGame = GAME_DATA.find(g => g.id === selectedGame)

  const handleGameSelect = (gameId: string) => {
    setSelectedGame(gameId)
    setSelectedQuestion(null)
    const game = GAME_DATA.find(g => g.id === gameId)
    if (game) {
      setChatHistory(prev => [...prev, 
        { type: 'user', text: `Расскажи про ${game.name}` },
        { type: 'bot', text: `${game.name} - ${game.description}. Выберите один из вопросов ниже, чтобы узнать больше!` }
      ])
    }
  }

  const handleQuestionSelect = (questionId: string) => {
    setSelectedQuestion(questionId)
    const question = currentGame?.questions.find(q => q.id === questionId)
    if (question) {
      setChatHistory(prev => [...prev,
        { type: 'user', text: question.question },
        { type: 'bot', text: question.answer }
      ])
    }
  }

  const handleBack = () => {
    if (selectedQuestion) {
      setSelectedQuestion(null)
    } else if (selectedGame) {
      setSelectedGame(null)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      {/* Modal */}
      <div className="relative w-full max-w-2xl h-[600px] flex flex-col glass-card rounded-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-purple-500/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Игровой помощник</h2>
              <p className="text-purple-300/70 text-xs">Отвечу на вопросы по всем играм</p>
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-purple-300 hover:text-white hover:bg-purple-500/20"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Chat area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {chatHistory.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                  msg.type === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-br-none'
                    : 'glass-card text-purple-100 rounded-bl-none'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
        </div>

        {/* Selection area */}
        <div className="border-t border-purple-500/20 p-4">
          {!selectedGame ? (
            <>
              <p className="text-purple-300/70 text-sm mb-3 flex items-center gap-2">
                <Gamepad2 className="w-4 h-4" />
                Выберите игру:
              </p>
              <div className="grid grid-cols-2 gap-2 max-h-[200px] overflow-y-auto">
                {GAME_DATA.map(game => (
                  <button
                    key={game.id}
                    onClick={() => handleGameSelect(game.id)}
                    className="glass-card rounded-lg px-3 py-2 text-left hover:bg-white/10 transition-colors"
                  >
                    <span className="text-white text-sm font-medium">{game.name}</span>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center justify-between mb-3">
                <button
                  onClick={handleBack}
                  className="text-purple-400 hover:text-white text-sm flex items-center gap-1"
                >
                  <ChevronDown className="w-4 h-4 rotate-90" />
                  Назад
                </button>
                <span className="text-cyan-400 text-sm font-medium">{currentGame?.name}</span>
              </div>
              
              <p className="text-purple-300/70 text-sm mb-3 flex items-center gap-2">
                <HelpCircle className="w-4 h-4" />
                Выберите вопрос:
              </p>
              <div className="space-y-2 max-h-[150px] overflow-y-auto">
                {currentGame?.questions.map(q => (
                  <button
                    key={q.id}
                    onClick={() => handleQuestionSelect(q.id)}
                    className={`w-full glass-card rounded-lg px-3 py-2 text-left hover:bg-white/10 transition-colors ${
                      selectedQuestion === q.id ? 'border border-cyan-500/50' : ''
                    }`}
                  >
                    <span className="text-white text-sm">{q.question}</span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
