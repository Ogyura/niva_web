"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { ProfileCabinet } from "@/components/profile-cabinet"
import { GameAssistant } from "@/components/game-assistant"
import { Button } from "@/components/ui/button"
import { Shield, Trophy, Gamepad2, LogOut, User, Play, Fuel, Zap, Bug, Clock, Target, Sword, Brain, Blocks, Castle, Timer, Puzzle, MessageCircle, Award } from "lucide-react"

interface LeaderboardEntry {
  username: string
  score: number
  distance: string
  date: string
  game: string
}

type GameFilter = "all" | "hill-climb" | "flappy-virus" | "virus-shooter" | "virus-snake" | "virus-pong" | "virus-memory" | "virus-breakout" | "virus-defense" | "virus-runner" | "virus-puzzle"

const GAMES = [
  {
    id: "hill-climb",
    name: "Virus Hill Climb",
    description: "Гонки по холмам с физикой! Собирай вирусы для топлива.",
    icon: Fuel,
    color: "blue",
    gradient: "from-blue-600 to-purple-600",
    tags: ["Физика", "2 мин"],
    href: "/games/hill-climb"
  },
  {
    id: "flappy-virus",
    name: "Flappy Virus",
    description: "Управляй летающим вирусом! Пролетай между трубами.",
    icon: Bug,
    color: "red",
    gradient: "from-red-600 to-orange-600",
    tags: ["Аркада", "2 мин"],
    href: "/games/flappy-virus"
  },
  {
    id: "virus-shooter",
    name: "Virus Shooter",
    description: "Уничтожай вирусы! Стреляй антителами и защити организм.",
    icon: Target,
    color: "green",
    gradient: "from-green-600 to-emerald-600",
    tags: ["Шутер", "2 мин"],
    href: "/games/virus-shooter"
  },
  {
    id: "virus-snake",
    name: "Virus Snake",
    description: "Классическая змейка в мире вирусов! Собирай клетки.",
    icon: Sword,
    color: "purple",
    gradient: "from-purple-600 to-pink-600",
    tags: ["Аркада", "2 мин"],
    href: "/games/virus-snake"
  },
  {
    id: "virus-pong",
    name: "Virus Pong",
    description: "Вирусный понг против ИИ! Отбивай заражённый мяч.",
    icon: Gamepad2,
    color: "cyan",
    gradient: "from-cyan-600 to-blue-600",
    tags: ["Спорт", "2 мин"],
    href: "/games/virus-pong"
  },
  {
    id: "virus-memory",
    name: "Virus Memory",
    description: "Найди пары вирусов! Тренируй память и скорость.",
    icon: Brain,
    color: "yellow",
    gradient: "from-yellow-600 to-orange-600",
    tags: ["Память", "2 мин"],
    href: "/games/virus-memory"
  },
  {
    id: "virus-breakout",
    name: "Virus Breakout",
    description: "Разбей блоки вирусов! Классический арканоид.",
    icon: Blocks,
    color: "pink",
    gradient: "from-pink-600 to-rose-600",
    tags: ["Аркада", "2 мин"],
    href: "/games/virus-breakout"
  },
  {
    id: "virus-defense",
    name: "Virus Defense",
    description: "Защити базу! Ставь башни и уничтожай волны вирусов.",
    icon: Castle,
    color: "amber",
    gradient: "from-amber-600 to-yellow-600",
    tags: ["Стратегия", "2 мин"],
    href: "/games/virus-defense"
  },
  {
    id: "virus-runner",
    name: "Virus Runner",
    description: "Беги и прыгай! Уклоняйся от вирусов на скорости.",
    icon: Timer,
    color: "teal",
    gradient: "from-teal-600 to-cyan-600",
    tags: ["Раннер", "2 мин"],
    href: "/games/virus-runner"
  },
  {
    id: "virus-puzzle",
    name: "Virus Puzzle",
    description: "Тетрис с вирусами! Собирай линии и очищай поле.",
    icon: Puzzle,
    color: "indigo",
    gradient: "from-indigo-600 to-violet-600",
    tags: ["Пазл", "2 мин"],
    href: "/games/virus-puzzle"
  }
]

export function MainApp() {
  const { user, logout } = useAuth()
  const [activeTab, setActiveTab] = useState<"games" | "leaderboard">("games")
  const [leaderboardGame, setLeaderboardGame] = useState<GameFilter>("all")
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [showProfile, setShowProfile] = useState(false)
  const [showAssistant, setShowAssistant] = useState(false)

  useEffect(() => {
    const loadLeaderboard = () => {
      const allEntries: LeaderboardEntry[] = []
      
      GAMES.forEach(game => {
        const key = `${game.id.replace(/-/g, '')}Leaderboard`
        const altKey = `${game.id.split('-').map((w, i) => i === 0 ? w : w.charAt(0).toUpperCase() + w.slice(1)).join('')}Leaderboard`
        
        let data = localStorage.getItem(key)
        if (!data) {
          data = localStorage.getItem(altKey)
        }
        const camelKey = game.id.replace(/-([a-z])/g, (_, c) => c.toUpperCase()) + 'Leaderboard'
        if (!data) {
          data = localStorage.getItem(camelKey)
        }
        
        if (data) {
          try {
            const entries: LeaderboardEntry[] = JSON.parse(data)
            allEntries.push(...entries)
          } catch {
            // Skip invalid data
          }
        }
      })
      
      let filtered = allEntries
      if (leaderboardGame !== "all") {
        filtered = allEntries.filter(entry => entry.game === leaderboardGame)
      }
      
      filtered.sort((a, b) => b.score - a.score)
      setLeaderboard(filtered.slice(0, 20))
    }
    
    loadLeaderboard()
    
    if (activeTab === "leaderboard") {
      const interval = setInterval(loadLeaderboard, 1000)
      return () => clearInterval(interval)
    }
  }, [activeTab, leaderboardGame])

  return (
    <div className="min-h-screen gradient-bg-animated wave-lines">
      {/* Header */}
      <header className="glass border-b border-purple-500/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-purple-500/50">
              <Image
                src="/images/mascot.png"
                alt="DDOS-GUARD"
                fill
                loading="eager"
                className="object-cover object-top scale-125"
              />
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6 text-blue-400" />
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                DDOS-GUARD
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button
              onClick={() => setShowAssistant(true)}
              variant="outline"
              size="sm"
              className="border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/20 hover:text-white"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Помощник
            </Button>
            <button
              onClick={() => setShowProfile(true)}
              className="flex items-center gap-2 glass-card px-4 py-2 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                {user?.username[0].toUpperCase()}
              </div>
              <span className="text-white font-medium">{user?.username}</span>
              {user && user.achievements && user.achievements.length > 0 && (
                <div className="flex items-center gap-1 text-yellow-400">
                  <Award className="w-3 h-3" />
                  <span className="text-xs">{user.achievements.length}</span>
                </div>
              )}
            </button>
            <Button
              onClick={logout}
              variant="outline"
              size="sm"
              className="border-purple-500/30 text-purple-300 hover:bg-purple-500/20 hover:text-white"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Выйти
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row items-center gap-8">
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
                Защити сеть
              </span>
              <br />
              <span className="text-white">играя!</span>
            </h1>
            <p className="text-purple-300/80 text-lg md:text-xl max-w-lg mx-auto lg:mx-0">
              10 игр на выбор: гонки, шутеры, пазлы и стратегии в мире вирусов!
            </p>
          </div>
          
          <div className="relative w-48 h-48 lg:w-64 lg:h-64">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/30 to-purple-600/30 rounded-full blur-2xl animate-pulse-glow" />
            <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-purple-500/50 neon-purple">
              <Image
                src="/images/mascot.png"
                alt="DDOS-GUARD Ninja"
                fill
                loading="eager"
                priority
                className="object-cover object-top scale-110"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Navigation Tabs */}
      <section className="container mx-auto px-4 mb-6">
        <div className="flex justify-center gap-4">
          <Button
            onClick={() => setActiveTab("games")}
            className={`px-8 py-3 rounded-xl font-semibold transition-all ${
              activeTab === "games"
                ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white neon-purple"
                : "glass text-purple-300 hover:text-white"
            }`}
          >
            <Gamepad2 className="w-5 h-5 mr-2" />
            Игры
          </Button>
          <Button
            onClick={() => setActiveTab("leaderboard")}
            className={`px-8 py-3 rounded-xl font-semibold transition-all ${
              activeTab === "leaderboard"
                ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white neon-purple"
                : "glass text-purple-300 hover:text-white"
            }`}
          >
            <Trophy className="w-5 h-5 mr-2" />
            Рейтинг
          </Button>
        </div>
      </section>

      {/* Content */}
      <section className="container mx-auto px-4 pb-12">
        {activeTab === "games" ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {GAMES.map((game) => (
              <GameCard key={game.id} game={game} />
            ))}
          </div>
        ) : (
          <LeaderboardSection 
            leaderboard={leaderboard} 
            activeGame={leaderboardGame}
            onGameChange={setLeaderboardGame}
          />
        )}
      </section>

      {/* Footer */}
      <footer className="glass border-t border-purple-500/20 py-6">
        <div className="container mx-auto px-4 text-center">
          <p className="text-purple-400/60 text-sm">
            DDOS-GUARD Games Arena - Защита через игры
          </p>
        </div>
      </footer>

      {/* Profile Modal */}
      {showProfile && <ProfileCabinet onClose={() => setShowProfile(false)} />}
      
      {/* AI Assistant Modal */}
      {showAssistant && <GameAssistant onClose={() => setShowAssistant(false)} />}
    </div>
  )
}

function GameCard({ game }: { game: typeof GAMES[0] }) {
  const Icon = game.icon
  
  const colorClasses: Record<string, string> = {
    blue: "text-blue-400",
    red: "text-red-400",
    green: "text-green-400",
    purple: "text-purple-400",
    cyan: "text-cyan-400",
    yellow: "text-yellow-400",
    pink: "text-pink-400",
    amber: "text-amber-400",
    teal: "text-teal-400",
    indigo: "text-indigo-400"
  }
  
  const bgClasses: Record<string, string> = {
    blue: "from-blue-900/50 to-indigo-900/50",
    red: "from-red-900/50 to-orange-900/50",
    green: "from-green-900/50 to-emerald-900/50",
    purple: "from-purple-900/50 to-pink-900/50",
    cyan: "from-cyan-900/50 to-blue-900/50",
    yellow: "from-yellow-900/50 to-orange-900/50",
    pink: "from-pink-900/50 to-rose-900/50",
    amber: "from-amber-900/50 to-yellow-900/50",
    teal: "from-teal-900/50 to-cyan-900/50",
    indigo: "from-indigo-900/50 to-violet-900/50"
  }
  
  const tagColors: Record<string, string> = {
    blue: "text-blue-400",
    red: "text-red-400",
    green: "text-green-400",
    purple: "text-purple-400",
    cyan: "text-cyan-400",
    yellow: "text-yellow-400",
    pink: "text-pink-400",
    amber: "text-amber-400",
    teal: "text-teal-400",
    indigo: "text-indigo-400"
  }
  
  return (
    <Link href={game.href}>
      <div className="glass-card rounded-2xl p-5 hover:scale-105 transition-all duration-300 cursor-pointer group h-full flex flex-col">
        <div className={`relative w-full h-28 rounded-xl bg-gradient-to-br ${bgClasses[game.color]} mb-4 overflow-hidden flex items-center justify-center`}>
          <div className="absolute inset-0 opacity-20">
            <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
              <defs>
                <pattern id={`pattern-${game.id}`} x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                  <circle cx="10" cy="10" r="2" fill="currentColor" opacity="0.3" />
                </pattern>
              </defs>
              <rect width="100" height="100" fill={`url(#pattern-${game.id})`} />
            </svg>
          </div>
          <Icon className={`w-16 h-16 ${colorClasses[game.color]} group-hover:scale-110 transition-transform duration-300`} />
        </div>
        
        <div className="flex-1 flex flex-col">
          <div className="flex items-center gap-2 mb-2">
            <Icon className={`w-5 h-5 ${colorClasses[game.color]}`} />
            <h3 className="text-lg font-bold text-white">{game.name}</h3>
          </div>
          <p className="text-purple-300/70 text-sm mb-3 flex-1">
            {game.description}
          </p>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {game.tags.map((tag, idx) => (
              <div key={idx} className="glass-card px-2 py-0.5 rounded-full">
                <span className={`${idx === 0 ? tagColors[game.color] : 'text-yellow-400'} text-xs font-medium flex items-center gap-1`}>
                  {tag.includes("мин") && <Clock className="w-3 h-3" />}
                  {tag}
                </span>
              </div>
            ))}
          </div>
          
          <Button className={`w-full py-2 bg-gradient-to-r ${game.gradient} hover:opacity-90 rounded-xl text-sm`}>
            <Play className="w-4 h-4 mr-2" />
            Играть
          </Button>
        </div>
      </div>
    </Link>
  )
}

function LeaderboardSection({ 
  leaderboard, 
  activeGame, 
  onGameChange 
}: { 
  leaderboard: LeaderboardEntry[]
  activeGame: GameFilter
  onGameChange: (game: GameFilter) => void
}) {
  const getGameInfo = (gameId: string) => {
    return GAMES.find(g => g.id === gameId) || GAMES[0]
  }
  
  return (
    <div className="glass-card rounded-2xl p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-white mb-6 text-center">
        <Trophy className="w-6 h-6 inline-block mr-2 text-yellow-400" />
        Топ игроков
      </h2>
      
      {/* Game filter */}
      <div className="flex flex-wrap justify-center gap-2 mb-6">
        <Button
          onClick={() => onGameChange("all")}
          size="sm"
          className={`rounded-full text-xs ${
            activeGame === "all"
              ? "bg-purple-600 text-white"
              : "bg-white/10 text-purple-300 hover:bg-white/20"
          }`}
        >
          Все игры
        </Button>
        {GAMES.map(game => {
          const Icon = game.icon
          return (
            <Button
              key={game.id}
              onClick={() => onGameChange(game.id as GameFilter)}
              size="sm"
              className={`rounded-full text-xs ${
                activeGame === game.id
                  ? `bg-gradient-to-r ${game.gradient} text-white`
                  : "bg-white/10 text-purple-300 hover:bg-white/20"
              }`}
            >
              <Icon className="w-3 h-3 mr-1" />
              {game.name.split(' ')[1]}
            </Button>
          )
        })}
      </div>
      
      {leaderboard.length === 0 ? (
        <div className="text-center py-12">
          <Trophy className="w-16 h-16 text-purple-400/30 mx-auto mb-4" />
          <p className="text-purple-300/60">Пока нет результатов</p>
          <p className="text-purple-400/40 text-sm mt-2">Сыграйте в игру чтобы попасть в рейтинг!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {leaderboard.map((player, index) => {
            const gameInfo = getGameInfo(player.game)
            const Icon = gameInfo.icon
            return (
              <div
                key={`${player.username}-${player.date}-${index}`}
                className={`flex items-center justify-between p-4 rounded-xl ${
                  index < 3
                    ? "bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30"
                    : "bg-white/5"
                }`}
              >
                <div className="flex items-center gap-4">
                  <span
                    className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                      index === 0
                        ? "bg-yellow-500 text-black"
                        : index === 1
                        ? "bg-gray-300 text-black"
                        : index === 2
                        ? "bg-orange-600 text-white"
                        : "bg-purple-600/50 text-white"
                    }`}
                  >
                    {index + 1}
                  </span>
                  <div>
                    <p className="text-white font-semibold">{player.username}</p>
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-purple-400/70 text-sm">{player.distance}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full bg-gradient-to-r ${gameInfo.gradient} text-white flex items-center gap-1`}>
                        <Icon className="w-3 h-3" />
                        {gameInfo.name.split(' ')[1]}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  <span className="text-cyan-400 font-bold">{player.score.toLocaleString()}</span>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
