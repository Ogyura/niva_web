"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Brick {
  x: number
  y: number
  width: number
  height: number
  health: number
  type: number
  pulse: number
}

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  color: string
  size: number
}

interface PowerUp {
  x: number
  y: number
  type: 'expand' | 'multi' | 'slow'
  vy: number
}

export default function VirusBreakoutGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover" | "win">("menu")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120)
  const [lives, setLives] = useState(3)

  const gameRef = useRef({
    paddleX: 350,
    paddleWidth: 100,
    paddleHeight: 15,
    balls: [{ x: 400, y: 500, vx: 4, vy: -4, radius: 8, attached: true }],
    bricks: [] as Brick[],
    particles: [] as Particle[],
    powerUps: [] as PowerUp[],
    score: 0,
    lives: 3,
    stars: [] as { x: number; y: number; size: number; brightness: number }[],
  })

  const saveScore = useCallback((finalScore: number) => {
    const username = localStorage.getItem("ddosGuardUser") || "Anonymous"
    const leaderboard = JSON.parse(localStorage.getItem("ddosGuardLeaderboard") || "[]")
    leaderboard.push({
      username,
      score: finalScore,
      game: "Virus Breakout",
      date: new Date().toISOString(),
    })
    leaderboard.sort((a: any, b: any) => b.score - a.score)
    localStorage.setItem("ddosGuardLeaderboard", JSON.stringify(leaderboard.slice(0, 100)))
    
    if (finalScore > highScore) {
      setHighScore(finalScore)
      localStorage.setItem("virusBreakoutHighScore", finalScore.toString())
    }
  }, [highScore])

  const createBricks = () => {
    const bricks: Brick[] = []
    const rows = 5
    const cols = 10
    const brickWidth = 70
    const brickHeight = 30
    const padding = 5
    const offsetX = 25
    const offsetY = 60

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        bricks.push({
          x: offsetX + col * (brickWidth + padding),
          y: offsetY + row * (brickHeight + padding),
          width: brickWidth,
          height: brickHeight,
          health: rows - row,
          type: row % 3,
          pulse: Math.random() * Math.PI * 2,
        })
      }
    }
    return bricks
  }

  const startGame = useCallback(() => {
    const game = gameRef.current
    game.paddleX = 350
    game.paddleWidth = 100
    game.balls = [{ x: 400, y: 500, vx: 4, vy: -4, radius: 8, attached: true }]
    game.bricks = createBricks()
    game.particles = []
    game.powerUps = []
    game.score = 0
    game.lives = 3

    game.stars = []
    for (let i = 0; i < 100; i++) {
      game.stars.push({
        x: Math.random() * 800,
        y: Math.random() * 600,
        size: Math.random() * 2 + 0.5,
        brightness: Math.random(),
      })
    }

    setScore(0)
    setLives(3)
    setTimeLeft(120)
    setGameState("playing")
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem("virusBreakoutHighScore")
    if (saved) setHighScore(parseInt(saved))
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const game = gameRef.current

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      game.paddleX = Math.max(
        game.paddleWidth / 2,
        Math.min(800 - game.paddleWidth / 2, e.clientX - rect.left)
      )
    }

    const handleClick = () => {
      game.balls.forEach((ball) => {
        if (ball.attached) {
          ball.attached = false
          ball.vy = -6
          ball.vx = (Math.random() - 0.5) * 4
        }
      })
    }

    canvas.addEventListener("mousemove", handleMouseMove)
    canvas.addEventListener("click", handleClick)

    const timerInterval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameState("gameover")
          saveScore(game.score)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    const drawBackground = () => {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 600)
      skyGrad.addColorStop(0, "#1e1b4b")
      skyGrad.addColorStop(0.3, "#312e81")
      skyGrad.addColorStop(0.6, "#6366f1")
      skyGrad.addColorStop(0.85, "#f97316")
      skyGrad.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGrad
      ctx.fillRect(0, 0, 800, 600)

      game.stars.forEach((star) => {
        const brightness = 0.5 + Math.sin(Date.now() / 1000 + star.x) * 0.5
        ctx.fillStyle = `rgba(255, 255, 255, ${brightness * star.brightness})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()
      })
    }

    const drawPaddle = () => {
      const x = game.paddleX - game.paddleWidth / 2
      const y = 560

      const gradient = ctx.createLinearGradient(x, y, x, y + game.paddleHeight)
      gradient.addColorStop(0, "#60a5fa")
      gradient.addColorStop(0.5, "#3b82f6")
      gradient.addColorStop(1, "#1d4ed8")

      ctx.shadowColor = "#3b82f6"
      ctx.shadowBlur = 15

      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.roundRect(x, y, game.paddleWidth, game.paddleHeight, 8)
      ctx.fill()

      // Edge highlights
      ctx.strokeStyle = "#93c5fd"
      ctx.lineWidth = 2
      ctx.stroke()

      ctx.shadowBlur = 0
    }

    const drawBrick = (brick: Brick) => {
      brick.pulse += 0.05
      const colors = [
        { main: "#22c55e", glow: "#4ade80", dark: "#166534" },
        { main: "#ef4444", glow: "#f87171", dark: "#991b1b" },
        { main: "#a855f7", glow: "#c084fc", dark: "#6b21a8" },
      ]
      const color = colors[brick.type]
      const pulseScale = 1 + Math.sin(brick.pulse) * 0.02

      ctx.save()
      ctx.translate(brick.x + brick.width / 2, brick.y + brick.height / 2)
      ctx.scale(pulseScale, pulseScale)
      ctx.translate(-brick.width / 2, -brick.height / 2)

      // Glow
      ctx.shadowColor = color.glow
      ctx.shadowBlur = 10

      // Body
      const gradient = ctx.createLinearGradient(0, 0, 0, brick.height)
      gradient.addColorStop(0, color.glow)
      gradient.addColorStop(0.3, color.main)
      gradient.addColorStop(1, color.dark)
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.roundRect(0, 0, brick.width, brick.height, 6)
      ctx.fill()

      // Spikes (mini virus look)
      const spikeCount = 6
      for (let i = 0; i < spikeCount; i++) {
        const sx = (i + 0.5) * (brick.width / spikeCount)
        ctx.fillStyle = color.glow
        ctx.beginPath()
        ctx.arc(sx, -3, 4, 0, Math.PI * 2)
        ctx.fill()
        ctx.beginPath()
        ctx.arc(sx, brick.height + 3, 4, 0, Math.PI * 2)
        ctx.fill()
      }

      // Health indicator
      ctx.shadowBlur = 0
      ctx.fillStyle = "rgba(0,0,0,0.3)"
      ctx.font = "bold 14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(brick.health.toString(), brick.width / 2, brick.height / 2)
      ctx.fillStyle = "#fff"
      ctx.fillText(brick.health.toString(), brick.width / 2 - 1, brick.height / 2 - 1)

      ctx.restore()
    }

    const drawBall = (ball: { x: number; y: number; radius: number }) => {
      // Trail effect handled in particles

      ctx.save()
      ctx.translate(ball.x, ball.y)

      // Glow
      ctx.shadowColor = "#22d3ee"
      ctx.shadowBlur = 15

      // Ball body
      const gradient = ctx.createRadialGradient(-2, -2, 0, 0, 0, ball.radius)
      gradient.addColorStop(0, "#67e8f9")
      gradient.addColorStop(0.5, "#22d3ee")
      gradient.addColorStop(1, "#0891b2")
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(0, 0, ball.radius, 0, Math.PI * 2)
      ctx.fill()

      // Shine
      ctx.fillStyle = "rgba(255,255,255,0.6)"
      ctx.beginPath()
      ctx.arc(-2, -2, ball.radius * 0.3, 0, Math.PI * 2)
      ctx.fill()

      ctx.shadowBlur = 0
      ctx.restore()
    }

    const drawPowerUp = (powerUp: PowerUp) => {
      const colors = { expand: "#22c55e", multi: "#a855f7", slow: "#3b82f6" }
      const icons = { expand: "E", multi: "M", slow: "S" }

      ctx.save()
      ctx.translate(powerUp.x, powerUp.y)

      ctx.shadowColor = colors[powerUp.type]
      ctx.shadowBlur = 15

      ctx.fillStyle = colors[powerUp.type]
      ctx.beginPath()
      ctx.arc(0, 0, 12, 0, Math.PI * 2)
      ctx.fill()

      ctx.shadowBlur = 0
      ctx.fillStyle = "#fff"
      ctx.font = "bold 12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(icons[powerUp.type], 0, 0)

      ctx.restore()
    }

    let animationId: number
    const gameLoop = () => {
      ctx.clearRect(0, 0, 800, 600)
      drawBackground()

      // Update bricks
      game.bricks.forEach(drawBrick)

      // Update balls
      game.balls = game.balls.filter((ball) => {
        if (ball.attached) {
          ball.x = game.paddleX
          ball.y = 550
        } else {
          ball.x += ball.vx
          ball.y += ball.vy

          // Add trail particles
          if (Math.random() < 0.3) {
            game.particles.push({
              x: ball.x,
              y: ball.y,
              vx: 0,
              vy: 0,
              life: 1,
              color: "#22d3ee",
              size: 4,
            })
          }

          // Wall collisions
          if (ball.x <= ball.radius || ball.x >= 800 - ball.radius) {
            ball.vx = -ball.vx
            ball.x = Math.max(ball.radius, Math.min(800 - ball.radius, ball.x))
          }
          if (ball.y <= ball.radius) {
            ball.vy = -ball.vy
            ball.y = ball.radius
          }

          // Paddle collision
          if (
            ball.y + ball.radius >= 560 &&
            ball.y < 575 &&
            ball.x >= game.paddleX - game.paddleWidth / 2 - ball.radius &&
            ball.x <= game.paddleX + game.paddleWidth / 2 + ball.radius
          ) {
            ball.vy = -Math.abs(ball.vy)
            const hitPos = (ball.x - game.paddleX) / (game.paddleWidth / 2)
            ball.vx = hitPos * 6
            ball.y = 559

            for (let i = 0; i < 5; i++) {
              game.particles.push({
                x: ball.x,
                y: ball.y,
                vx: (Math.random() - 0.5) * 5,
                vy: -Math.random() * 3,
                life: 1,
                color: "#3b82f6",
                size: 3,
              })
            }
          }

          // Brick collision
          for (let i = game.bricks.length - 1; i >= 0; i--) {
            const brick = game.bricks[i]
            if (
              ball.x + ball.radius > brick.x &&
              ball.x - ball.radius < brick.x + brick.width &&
              ball.y + ball.radius > brick.y &&
              ball.y - ball.radius < brick.y + brick.height
            ) {
              brick.health--

              // Determine bounce direction
              const overlapLeft = ball.x + ball.radius - brick.x
              const overlapRight = brick.x + brick.width - (ball.x - ball.radius)
              const overlapTop = ball.y + ball.radius - brick.y
              const overlapBottom = brick.y + brick.height - (ball.y - ball.radius)

              const minOverlapX = Math.min(overlapLeft, overlapRight)
              const minOverlapY = Math.min(overlapTop, overlapBottom)

              if (minOverlapX < minOverlapY) {
                ball.vx = -ball.vx
              } else {
                ball.vy = -ball.vy
              }

              // Particles
              for (let j = 0; j < 8; j++) {
                const colors = ["#22c55e", "#ef4444", "#a855f7"]
                game.particles.push({
                  x: ball.x,
                  y: ball.y,
                  vx: (Math.random() - 0.5) * 6,
                  vy: (Math.random() - 0.5) * 6,
                  life: 1,
                  color: colors[brick.type],
                  size: 4,
                })
              }

              if (brick.health <= 0) {
                game.bricks.splice(i, 1)
                game.score += (brick.type + 1) * 100
                setScore(game.score)

                // Maybe spawn power-up
                if (Math.random() < 0.15) {
                  const types: ('expand' | 'multi' | 'slow')[] = ['expand', 'multi', 'slow']
                  game.powerUps.push({
                    x: brick.x + brick.width / 2,
                    y: brick.y + brick.height / 2,
                    type: types[Math.floor(Math.random() * types.length)],
                    vy: 2,
                  })
                }

                // Check win
                if (game.bricks.length === 0) {
                  const bonus = timeLeft * 20 + game.lives * 500
                  game.score += bonus
                  setScore(game.score)
                  setGameState("win")
                  saveScore(game.score)
                }
              }

              break
            }
          }

          // Ball lost
          if (ball.y > 620) {
            if (game.balls.length === 1) {
              game.lives--
              setLives(game.lives)
              if (game.lives <= 0) {
                setGameState("gameover")
                saveScore(game.score)
              } else {
                return false
              }
            }
            return false
          }
        }

        drawBall(ball)
        return true
      })

      // Respawn ball if needed
      if (game.balls.length === 0 && game.lives > 0) {
        game.balls.push({ x: game.paddleX, y: 500, vx: 4, vy: -4, radius: 8, attached: true })
      }

      // Update power-ups
      game.powerUps = game.powerUps.filter((powerUp) => {
        powerUp.y += powerUp.vy

        // Collect
        if (
          powerUp.y >= 555 &&
          powerUp.y <= 580 &&
          powerUp.x >= game.paddleX - game.paddleWidth / 2 - 15 &&
          powerUp.x <= game.paddleX + game.paddleWidth / 2 + 15
        ) {
          if (powerUp.type === 'expand') {
            game.paddleWidth = Math.min(200, game.paddleWidth + 30)
          } else if (powerUp.type === 'multi' && game.balls.length < 5) {
            const ball = game.balls[0]
            if (ball && !ball.attached) {
              game.balls.push({ ...ball, vx: ball.vx + 2 })
              game.balls.push({ ...ball, vx: ball.vx - 2 })
            }
          } else if (powerUp.type === 'slow') {
            game.balls.forEach((ball) => {
              ball.vx *= 0.7
              ball.vy *= 0.7
            })
          }
          return false
        }

        if (powerUp.y > 600) return false

        drawPowerUp(powerUp)
        return true
      })

      // Update particles
      game.particles = game.particles.filter((p) => {
        p.x += p.vx
        p.y += p.vy
        p.life -= 0.03

        // Only draw if life is positive to avoid negative radius error
        if (p.life > 0) {
          ctx.globalAlpha = Math.max(0, p.life)
          ctx.fillStyle = p.color
          ctx.beginPath()
          ctx.arc(p.x, p.y, Math.max(0.1, p.size * p.life), 0, Math.PI * 2)
          ctx.fill()
          ctx.globalAlpha = 1
        }

        return p.life > 0
      })

      drawPaddle()

      // UI
      ctx.fillStyle = "#fff"
      ctx.font = "bold 20px Arial"
      ctx.textAlign = "left"
      ctx.fillText(`Score: ${game.score}`, 20, 30)
      ctx.fillText(`Lives: ${game.lives}`, 20, 55)

      const minutes = Math.floor(timeLeft / 60)
      const seconds = timeLeft % 60
      ctx.textAlign = "right"
      ctx.fillStyle = timeLeft < 30 ? "#ef4444" : "#fff"
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, "0")}`, 780, 30)

      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      cancelAnimationFrame(animationId)
      clearInterval(timerInterval)
      canvas.removeEventListener("mousemove", handleMouseMove)
      canvas.removeEventListener("click", handleClick)
    }
  }, [gameState, timeLeft, saveScore])

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      <div className="mb-4 flex items-center gap-4">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Virus Breakout</h1>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          className="border-4 border-cyan-500 rounded-lg shadow-2xl cursor-none"
        />

        {gameState === "menu" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-white mb-4">Virus Breakout</h2>
            <p className="text-gray-300 mb-2">Move mouse to control paddle, click to launch</p>
            <p className="text-gray-400 mb-4 text-sm">Destroy all virus bricks!</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-cyan-600 hover:bg-cyan-700">
              Start Game
            </Button>
          </div>
        )}

        {gameState === "gameover" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-red-500 mb-4">Game Over!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-cyan-600 hover:bg-cyan-700">
              Play Again
            </Button>
          </div>
        )}

        {gameState === "win" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-green-500 mb-4">You Win!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-cyan-600 hover:bg-cyan-700">
              Play Again
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
