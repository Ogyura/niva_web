"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

const COLS = 10
const ROWS = 20
const CELL_SIZE = 28

const SHAPES = [
  [[1, 1, 1, 1]], // I
  [[1, 1], [1, 1]], // O
  [[0, 1, 0], [1, 1, 1]], // T
  [[1, 0, 0], [1, 1, 1]], // L
  [[0, 0, 1], [1, 1, 1]], // J
  [[0, 1, 1], [1, 1, 0]], // S
  [[1, 1, 0], [0, 1, 1]], // Z
]

const COLORS = [
  { main: "#22d3ee", glow: "#67e8f9" }, // Cyan
  { main: "#fbbf24", glow: "#fcd34d" }, // Yellow
  { main: "#a855f7", glow: "#c084fc" }, // Purple
  { main: "#f97316", glow: "#fb923c" }, // Orange
  { main: "#3b82f6", glow: "#60a5fa" }, // Blue
  { main: "#22c55e", glow: "#4ade80" }, // Green
  { main: "#ef4444", glow: "#f87171" }, // Red
]

export default function VirusPuzzleGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover">("menu")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120)
  const [level, setLevel] = useState(1)
  const [lines, setLines] = useState(0)

  const gameRef = useRef({
    board: [] as (number | null)[][],
    currentPiece: null as { shape: number[][]; x: number; y: number; type: number } | null,
    nextPiece: null as { shape: number[][]; type: number } | null,
    score: 0,
    lines: 0,
    level: 1,
    lastDrop: 0,
    dropInterval: 1000,
    stars: [] as { x: number; y: number; size: number; brightness: number }[],
    particles: [] as { x: number; y: number; vx: number; vy: number; life: number; color: string }[],
  })

  const saveScore = useCallback((finalScore: number) => {
    const username = localStorage.getItem("ddosGuardUser") || "Anonymous"
    const leaderboard = JSON.parse(localStorage.getItem("ddosGuardLeaderboard") || "[]")
    leaderboard.push({
      username,
      score: finalScore,
      game: "Virus Puzzle",
      date: new Date().toISOString(),
    })
    leaderboard.sort((a: any, b: any) => b.score - a.score)
    localStorage.setItem("ddosGuardLeaderboard", JSON.stringify(leaderboard.slice(0, 100)))
    
    if (finalScore > highScore) {
      setHighScore(finalScore)
      localStorage.setItem("virusPuzzleHighScore", finalScore.toString())
    }
  }, [highScore])

  const createPiece = () => {
    const type = Math.floor(Math.random() * SHAPES.length)
    return {
      shape: SHAPES[type].map((row) => [...row]),
      type,
    }
  }

  const startGame = useCallback(() => {
    const game = gameRef.current
    game.board = Array(ROWS).fill(null).map(() => Array(COLS).fill(null))
    game.nextPiece = createPiece()
    game.currentPiece = null
    game.score = 0
    game.lines = 0
    game.level = 1
    game.lastDrop = Date.now()
    game.dropInterval = 1000
    game.particles = []

    game.stars = []
    for (let i = 0; i < 60; i++) {
      game.stars.push({
        x: Math.random() * 500,
        y: Math.random() * 600,
        size: Math.random() * 2 + 0.5,
        brightness: Math.random(),
      })
    }

    setScore(0)
    setLines(0)
    setLevel(1)
    setTimeLeft(120)
    setGameState("playing")
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem("virusPuzzleHighScore")
    if (saved) setHighScore(parseInt(saved))
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const game = gameRef.current

    const spawnPiece = () => {
      if (!game.nextPiece) game.nextPiece = createPiece()
      game.currentPiece = {
        ...game.nextPiece,
        x: Math.floor(COLS / 2) - Math.floor(game.nextPiece.shape[0].length / 2),
        y: 0,
      }
      game.nextPiece = createPiece()

      // Check game over
      if (checkCollision(game.currentPiece.x, game.currentPiece.y, game.currentPiece.shape)) {
        setGameState("gameover")
        saveScore(game.score)
      }
    }

    const checkCollision = (x: number, y: number, shape: number[][]) => {
      for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
          if (shape[row][col]) {
            const newX = x + col
            const newY = y + row
            if (newX < 0 || newX >= COLS || newY >= ROWS) return true
            if (newY >= 0 && game.board[newY][newX] !== null) return true
          }
        }
      }
      return false
    }

    const lockPiece = () => {
      if (!game.currentPiece) return
      const { shape, x, y, type } = game.currentPiece

      for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
          if (shape[row][col] && y + row >= 0) {
            game.board[y + row][x + col] = type
          }
        }
      }

      // Check for complete lines
      let linesCleared = 0
      for (let row = ROWS - 1; row >= 0; row--) {
        if (game.board[row].every((cell) => cell !== null)) {
          // Add particles
          for (let col = 0; col < COLS; col++) {
            for (let i = 0; i < 5; i++) {
              game.particles.push({
                x: 100 + col * CELL_SIZE + CELL_SIZE / 2,
                y: 50 + row * CELL_SIZE + CELL_SIZE / 2,
                vx: (Math.random() - 0.5) * 8,
                vy: (Math.random() - 0.5) * 8,
                life: 1,
                color: COLORS[game.board[row][col] || 0].glow,
              })
            }
          }

          game.board.splice(row, 1)
          game.board.unshift(Array(COLS).fill(null))
          linesCleared++
          row++ // Check same row again
        }
      }

      if (linesCleared > 0) {
        const points = [0, 100, 300, 500, 800][linesCleared] * game.level
        game.score += points
        game.lines += linesCleared
        setScore(game.score)
        setLines(game.lines)

        // Level up
        const newLevel = Math.floor(game.lines / 10) + 1
        if (newLevel !== game.level) {
          game.level = newLevel
          game.dropInterval = Math.max(100, 1000 - (newLevel - 1) * 100)
          setLevel(newLevel)
        }
      }

      game.currentPiece = null
    }

    const rotatePiece = () => {
      if (!game.currentPiece) return
      const { shape, x, y } = game.currentPiece
      const newShape = shape[0].map((_, i) => shape.map((row) => row[i]).reverse())

      if (!checkCollision(x, y, newShape)) {
        game.currentPiece.shape = newShape
      }
    }

    const movePiece = (dx: number, dy: number) => {
      if (!game.currentPiece) return false
      const { x, y, shape } = game.currentPiece

      if (!checkCollision(x + dx, y + dy, shape)) {
        game.currentPiece.x += dx
        game.currentPiece.y += dy
        return true
      }
      return false
    }

    const hardDrop = () => {
      if (!game.currentPiece) return
      while (movePiece(0, 1)) {
        game.score += 2
      }
      setScore(game.score)
      lockPiece()
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "ArrowLeft" || e.key === "a" || e.key === "A") {
        movePiece(-1, 0)
      } else if (e.code === "ArrowRight" || e.key === "d" || e.key === "D") {
        movePiece(1, 0)
      } else if (e.code === "ArrowDown" || e.key === "s" || e.key === "S") {
        if (movePiece(0, 1)) {
          game.score += 1
          setScore(game.score)
        }
      } else if (e.code === "ArrowUp" || e.key === "w" || e.key === "W") {
        rotatePiece()
      } else if (e.code === "Space") {
        hardDrop()
      }
    }

    window.addEventListener("keydown", handleKeyDown)

    const timerInterval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameState("gameover")
          saveScore(game.score)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    const drawBackground = () => {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 600)
      skyGrad.addColorStop(0, "#1e1b4b")
      skyGrad.addColorStop(0.4, "#312e81")
      skyGrad.addColorStop(0.7, "#6366f1")
      skyGrad.addColorStop(0.9, "#f97316")
      skyGrad.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGrad
      ctx.fillRect(0, 0, 500, 650)

      game.stars.forEach((star) => {
        const brightness = 0.5 + Math.sin(Date.now() / 1000 + star.x) * 0.5
        ctx.fillStyle = `rgba(255, 255, 255, ${brightness * star.brightness})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()
      })
    }

    const drawBoard = () => {
      // Board background
      ctx.fillStyle = "rgba(0, 0, 0, 0.6)"
      ctx.fillRect(98, 48, COLS * CELL_SIZE + 4, ROWS * CELL_SIZE + 4)

      // Grid
      ctx.strokeStyle = "rgba(255, 255, 255, 0.1)"
      ctx.lineWidth = 1
      for (let x = 0; x <= COLS; x++) {
        ctx.beginPath()
        ctx.moveTo(100 + x * CELL_SIZE, 50)
        ctx.lineTo(100 + x * CELL_SIZE, 50 + ROWS * CELL_SIZE)
        ctx.stroke()
      }
      for (let y = 0; y <= ROWS; y++) {
        ctx.beginPath()
        ctx.moveTo(100, 50 + y * CELL_SIZE)
        ctx.lineTo(100 + COLS * CELL_SIZE, 50 + y * CELL_SIZE)
        ctx.stroke()
      }

      // Placed blocks
      for (let row = 0; row < ROWS; row++) {
        for (let col = 0; col < COLS; col++) {
          if (game.board[row][col] !== null) {
            drawBlock(100 + col * CELL_SIZE, 50 + row * CELL_SIZE, game.board[row][col]!)
          }
        }
      }
    }

    const drawBlock = (x: number, y: number, type: number) => {
      const color = COLORS[type]

      ctx.shadowColor = color.glow
      ctx.shadowBlur = 8

      const gradient = ctx.createLinearGradient(x, y, x + CELL_SIZE, y + CELL_SIZE)
      gradient.addColorStop(0, color.glow)
      gradient.addColorStop(0.5, color.main)
      gradient.addColorStop(1, color.main)
      ctx.fillStyle = gradient
      ctx.fillRect(x + 1, y + 1, CELL_SIZE - 2, CELL_SIZE - 2)

      // Inner highlight
      ctx.fillStyle = "rgba(255, 255, 255, 0.3)"
      ctx.fillRect(x + 3, y + 3, CELL_SIZE - 10, 4)

      // Virus detail
      ctx.fillStyle = color.main
      ctx.beginPath()
      ctx.arc(x + CELL_SIZE / 2, y + CELL_SIZE / 2, 3, 0, Math.PI * 2)
      ctx.fill()

      ctx.shadowBlur = 0
    }

    const drawCurrentPiece = () => {
      if (!game.currentPiece) return
      const { shape, x, y, type } = game.currentPiece

      // Ghost piece
      let ghostY = y
      while (!checkCollision(x, ghostY + 1, shape)) {
        ghostY++
      }

      for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
          if (shape[row][col]) {
            ctx.fillStyle = `${COLORS[type].main}30`
            ctx.fillRect(
              100 + (x + col) * CELL_SIZE + 1,
              50 + (ghostY + row) * CELL_SIZE + 1,
              CELL_SIZE - 2,
              CELL_SIZE - 2
            )
          }
        }
      }

      // Actual piece
      for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
          if (shape[row][col] && y + row >= 0) {
            drawBlock(100 + (x + col) * CELL_SIZE, 50 + (y + row) * CELL_SIZE, type)
          }
        }
      }
    }

    const drawNextPiece = () => {
      if (!game.nextPiece) return
      const { shape, type } = game.nextPiece

      ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
      ctx.fillRect(400, 50, 90, 90)

      ctx.fillStyle = "#fff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.fillText("NEXT", 445, 45)

      const offsetX = 415 + (4 - shape[0].length) * 10
      const offsetY = 65 + (4 - shape.length) * 10

      for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
          if (shape[row][col]) {
            const color = COLORS[type]
            ctx.fillStyle = color.main
            ctx.fillRect(offsetX + col * 20 + 1, offsetY + row * 20 + 1, 18, 18)
          }
        }
      }
    }

    let animationId: number
    const gameLoop = () => {
      const now = Date.now()

      // Spawn piece if needed
      if (!game.currentPiece) {
        spawnPiece()
        game.lastDrop = now
      }

      // Auto drop
      if (now - game.lastDrop > game.dropInterval) {
        game.lastDrop = now
        if (!movePiece(0, 1)) {
          lockPiece()
        }
      }

      // Render
      ctx.clearRect(0, 0, 500, 650)
      drawBackground()
      drawBoard()
      drawCurrentPiece()
      drawNextPiece()

      // Particles
      game.particles = game.particles.filter((p) => {
        p.x += p.vx
        p.y += p.vy
        p.life -= 0.02

        ctx.globalAlpha = p.life
        ctx.fillStyle = p.color
        ctx.beginPath()
        ctx.arc(p.x, p.y, 4 * p.life, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = 1

        return p.life > 0
      })

      // UI
      ctx.fillStyle = "#fff"
      ctx.font = "bold 20px Arial"
      ctx.textAlign = "left"
      ctx.fillText(`Score`, 400, 180)
      ctx.fillStyle = "#fbbf24"
      ctx.fillText(`${game.score}`, 400, 205)

      ctx.fillStyle = "#fff"
      ctx.fillText(`Level`, 400, 250)
      ctx.fillStyle = "#22c55e"
      ctx.fillText(`${game.level}`, 400, 275)

      ctx.fillStyle = "#fff"
      ctx.fillText(`Lines`, 400, 320)
      ctx.fillStyle = "#3b82f6"
      ctx.fillText(`${game.lines}`, 400, 345)

      const minutes = Math.floor(timeLeft / 60)
      const seconds = timeLeft % 60
      ctx.fillStyle = timeLeft < 30 ? "#ef4444" : "#fff"
      ctx.fillText(`Time`, 400, 390)
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, "0")}`, 400, 415)

      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      cancelAnimationFrame(animationId)
      clearInterval(timerInterval)
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [gameState, timeLeft, saveScore])

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      <div className="mb-4 flex items-center gap-4">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Virus Puzzle</h1>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={500}
          height={650}
          className="border-4 border-purple-500 rounded-lg shadow-2xl"
        />

        {gameState === "menu" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-white mb-4">Virus Puzzle</h2>
            <p className="text-gray-300 mb-2">Arrange virus blocks to clear lines</p>
            <p className="text-gray-400 mb-4 text-sm">Arrows/WASD to move, Space to drop</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-purple-600 hover:bg-purple-700">
              Start Game
            </Button>
          </div>
        )}

        {gameState === "gameover" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-red-500 mb-4">Game Over!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-xl text-gray-300 mb-2">Lines: {lines} | Level: {level}</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-purple-600 hover:bg-purple-700">
              Play Again
            </Button>
          </div>
        )}
      </div>

      <p className="mt-4 text-gray-400 text-sm">Arrows/WASD: Move & Rotate | Space: Hard Drop</p>
    </div>
  )
}
