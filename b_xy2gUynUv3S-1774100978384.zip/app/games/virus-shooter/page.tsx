"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Virus {
  x: number
  y: number
  radius: number
  speed: number
  type: number
  health: number
  maxHealth: number
  angle: number
  spikePhase: number
}

interface Bullet {
  x: number
  y: number
  angle: number
  speed: number
}

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  color: string
  size: number
}

interface PowerUp {
  x: number
  y: number
  type: 'rapid' | 'shield' | 'bomb'
  life: number
}

export default function VirusShooterGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover">("menu")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120)
  const [wave, setWave] = useState(1)
  const [shield, setShield] = useState(100)
  const [rapidFire, setRapidFire] = useState(false)

  const gameRef = useRef({
    viruses: [] as Virus[],
    bullets: [] as Bullet[],
    particles: [] as Particle[],
    powerUps: [] as PowerUp[],
    turretAngle: 0,
    lastShot: 0,
    shield: 100,
    rapidFire: false,
    rapidFireEnd: 0,
    score: 0,
    wave: 1,
    virusesKilled: 0,
    virusesPerWave: 10,
    mouseX: 400,
    mouseY: 300,
    stars: [] as { x: number; y: number; size: number; brightness: number }[],
  })

  const saveScore = useCallback((finalScore: number) => {
    const username = localStorage.getItem("ddosGuardUser") || "Anonymous"
    const leaderboard = JSON.parse(localStorage.getItem("ddosGuardLeaderboard") || "[]")
    leaderboard.push({
      username,
      score: finalScore,
      game: "Virus Shooter",
      date: new Date().toISOString(),
    })
    leaderboard.sort((a: any, b: any) => b.score - a.score)
    localStorage.setItem("ddosGuardLeaderboard", JSON.stringify(leaderboard.slice(0, 100)))
    
    if (finalScore > highScore) {
      setHighScore(finalScore)
      localStorage.setItem("virusShooterHighScore", finalScore.toString())
    }
  }, [highScore])

  const startGame = useCallback(() => {
    const game = gameRef.current
    game.viruses = []
    game.bullets = []
    game.particles = []
    game.powerUps = []
    game.shield = 100
    game.score = 0
    game.wave = 1
    game.virusesKilled = 0
    game.rapidFire = false
    
    // Initialize stars
    game.stars = []
    for (let i = 0; i < 100; i++) {
      game.stars.push({
        x: Math.random() * 800,
        y: Math.random() * 600,
        size: Math.random() * 2 + 0.5,
        brightness: Math.random(),
      })
    }
    
    // Spawn initial viruses so there's immediate action
    for (let i = 0; i < 3; i++) {
      game.viruses.push({
        x: 100 + Math.random() * 600,
        y: 50 + Math.random() * 150,
        radius: 25,
        speed: 1.5 + Math.random(),
        type: 0,
        health: 2,
        maxHealth: 2,
        angle: 0,
        spikePhase: Math.random() * Math.PI * 2,
      })
    }
    
    setScore(0)
    setTimeLeft(120)
    setWave(1)
    setShield(100)
    setRapidFire(false)
    setGameState("playing")
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem("virusShooterHighScore")
    if (saved) setHighScore(parseInt(saved))
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const game = gameRef.current

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      game.mouseX = e.clientX - rect.left
      game.mouseY = e.clientY - rect.top
    }

    const handleClick = () => {
      const now = Date.now()
      const fireRate = game.rapidFire ? 100 : 250
      if (now - game.lastShot > fireRate) {
        game.lastShot = now
        game.bullets.push({
          x: 400,
          y: 550,
          angle: game.turretAngle,
          speed: 12,
        })
      }
    }

    canvas.addEventListener("mousemove", handleMouseMove)
    canvas.addEventListener("click", handleClick)

    // Timer
    const timerInterval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameState("gameover")
          saveScore(game.score)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    // Spawn viruses - spawn more frequently to ensure constant action
    const spawnInterval = setInterval(() => {
      const maxViruses = 6 + game.wave * 2
      if (game.viruses.length < maxViruses) {
        const types = [0, 1, 2]
        const maxType = Math.min(types.length, Math.ceil(game.wave / 2) + 1)
        const type = types[Math.floor(Math.random() * maxType)]
        const virus: Virus = {
          x: Math.random() * 680 + 60,
          y: -30 - Math.random() * 40,
          radius: 25 + type * 5,
          speed: 1.5 + Math.random() * 1.5 + game.wave * 0.15,
          type,
          health: (type + 1) * 2,
          maxHealth: (type + 1) * 2,
          angle: 0,
          spikePhase: Math.random() * Math.PI * 2,
        }
        game.viruses.push(virus)
      }
    }, Math.max(500, 1200 - game.wave * 80))

    // Power-up spawn
    const powerUpInterval = setInterval(() => {
      if (Math.random() < 0.3 && game.powerUps.length < 2) {
        const types: ('rapid' | 'shield' | 'bomb')[] = ['rapid', 'shield', 'bomb']
        game.powerUps.push({
          x: Math.random() * 700 + 50,
          y: -30,
          type: types[Math.floor(Math.random() * types.length)],
          life: 1,
        })
      }
    }, 5000)

    const drawVirus = (virus: Virus) => {
      const colors = [
        { main: "#22c55e", glow: "#4ade80", dark: "#166534" },
        { main: "#ef4444", glow: "#f87171", dark: "#991b1b" },
        { main: "#a855f7", glow: "#c084fc", dark: "#6b21a8" },
      ]
      const color = colors[virus.type]

      ctx.save()
      ctx.translate(virus.x, virus.y)
      ctx.rotate(virus.angle)

      // Glow
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, virus.radius * 1.5)
      gradient.addColorStop(0, color.glow + "60")
      gradient.addColorStop(1, "transparent")
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(0, 0, virus.radius * 1.5, 0, Math.PI * 2)
      ctx.fill()

      // Spikes
      const spikeCount = 12 + virus.type * 4
      for (let i = 0; i < spikeCount; i++) {
        const angle = (i / spikeCount) * Math.PI * 2
        const spikeLength = virus.radius * 0.5 + Math.sin(virus.spikePhase + i) * 3
        ctx.save()
        ctx.rotate(angle)
        ctx.fillStyle = color.main
        ctx.beginPath()
        ctx.moveTo(virus.radius * 0.7, -3)
        ctx.lineTo(virus.radius + spikeLength, 0)
        ctx.lineTo(virus.radius * 0.7, 3)
        ctx.closePath()
        ctx.fill()
        
        // Spike ball
        ctx.beginPath()
        ctx.arc(virus.radius + spikeLength, 0, 4, 0, Math.PI * 2)
        ctx.fillStyle = color.glow
        ctx.fill()
        ctx.restore()
      }

      // Body gradient
      const bodyGrad = ctx.createRadialGradient(-5, -5, 0, 0, 0, virus.radius)
      bodyGrad.addColorStop(0, color.glow)
      bodyGrad.addColorStop(0.5, color.main)
      bodyGrad.addColorStop(1, color.dark)
      ctx.fillStyle = bodyGrad
      ctx.beginPath()
      ctx.arc(0, 0, virus.radius * 0.8, 0, Math.PI * 2)
      ctx.fill()

      // Evil face
      ctx.fillStyle = "#000"
      ctx.beginPath()
      ctx.ellipse(-8, -5, 6, 8, 0, 0, Math.PI * 2)
      ctx.ellipse(8, -5, 6, 8, 0, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.fillStyle = "#ff0000"
      ctx.beginPath()
      ctx.arc(-8, -5, 3, 0, Math.PI * 2)
      ctx.arc(8, -5, 3, 0, Math.PI * 2)
      ctx.fill()

      // Angry mouth
      ctx.strokeStyle = "#000"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(0, 8, 8, 0.2, Math.PI - 0.2)
      ctx.stroke()

      // Health bar
      ctx.restore()
      const healthPercent = virus.health / virus.maxHealth
      ctx.fillStyle = "#333"
      ctx.fillRect(virus.x - 20, virus.y - virus.radius - 15, 40, 6)
      ctx.fillStyle = healthPercent > 0.5 ? "#22c55e" : healthPercent > 0.25 ? "#eab308" : "#ef4444"
      ctx.fillRect(virus.x - 20, virus.y - virus.radius - 15, 40 * healthPercent, 6)
    }

    const drawTurret = () => {
      const angle = Math.atan2(game.mouseY - 550, game.mouseX - 400)
      game.turretAngle = angle

      ctx.save()
      ctx.translate(400, 550)

      // Base
      const baseGrad = ctx.createRadialGradient(0, 20, 0, 0, 20, 60)
      baseGrad.addColorStop(0, "#64748b")
      baseGrad.addColorStop(1, "#1e293b")
      ctx.fillStyle = baseGrad
      ctx.beginPath()
      ctx.ellipse(0, 20, 50, 25, 0, 0, Math.PI * 2)
      ctx.fill()

      // Turret body
      ctx.rotate(angle + Math.PI / 2)
      const turretGrad = ctx.createLinearGradient(-15, 0, 15, 0)
      turretGrad.addColorStop(0, "#475569")
      turretGrad.addColorStop(0.5, "#94a3b8")
      turretGrad.addColorStop(1, "#475569")
      ctx.fillStyle = turretGrad
      ctx.fillRect(-15, -60, 30, 70)

      // Barrel
      ctx.fillStyle = "#334155"
      ctx.fillRect(-8, -80, 16, 25)
      
      // Muzzle
      ctx.fillStyle = "#1e293b"
      ctx.fillRect(-10, -85, 20, 8)

      // Glow when rapid fire
      if (game.rapidFire) {
        ctx.shadowColor = "#22d3ee"
        ctx.shadowBlur = 20
        ctx.fillStyle = "#22d3ee"
        ctx.fillRect(-6, -85, 12, 5)
        ctx.shadowBlur = 0
      }

      ctx.restore()
    }

    const drawBackground = () => {
      // Sky gradient
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 600)
      skyGrad.addColorStop(0, "#1e1b4b")
      skyGrad.addColorStop(0.3, "#312e81")
      skyGrad.addColorStop(0.6, "#6366f1")
      skyGrad.addColorStop(0.8, "#f97316")
      skyGrad.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGrad
      ctx.fillRect(0, 0, 800, 600)

      // Stars
      game.stars.forEach((star) => {
        const brightness = 0.5 + Math.sin(Date.now() / 1000 + star.x) * 0.5
        ctx.fillStyle = `rgba(255, 255, 255, ${brightness * star.brightness})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()
      })

      // Distant hills
      ctx.fillStyle = "#1e1b4b80"
      ctx.beginPath()
      ctx.moveTo(0, 500)
      for (let x = 0; x <= 800; x += 10) {
        ctx.lineTo(x, 450 + Math.sin(x / 100) * 30 + Math.sin(x / 50) * 15)
      }
      ctx.lineTo(800, 600)
      ctx.lineTo(0, 600)
      ctx.closePath()
      ctx.fill()

      // Ground
      const groundGrad = ctx.createLinearGradient(0, 520, 0, 600)
      groundGrad.addColorStop(0, "#1e293b")
      groundGrad.addColorStop(1, "#0f172a")
      ctx.fillStyle = groundGrad
      ctx.fillRect(0, 520, 800, 80)
    }

    const drawPowerUp = (powerUp: PowerUp) => {
      ctx.save()
      ctx.translate(powerUp.x, powerUp.y)

      // Glow
      const colors = { rapid: "#22d3ee", shield: "#3b82f6", bomb: "#ef4444" }
      ctx.shadowColor = colors[powerUp.type]
      ctx.shadowBlur = 15

      ctx.fillStyle = colors[powerUp.type]
      ctx.beginPath()
      ctx.arc(0, 0, 15, 0, Math.PI * 2)
      ctx.fill()

      ctx.shadowBlur = 0
      ctx.fillStyle = "#fff"
      ctx.font = "bold 14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      const icons = { rapid: "R", shield: "S", bomb: "B" }
      ctx.fillText(icons[powerUp.type], 0, 0)

      ctx.restore()
    }

    let animationId: number
    const gameLoop = () => {
      // Clear
      ctx.clearRect(0, 0, 800, 600)
      drawBackground()

      // Update rapid fire
      if (game.rapidFire && Date.now() > game.rapidFireEnd) {
        game.rapidFire = false
        setRapidFire(false)
      }

      // Update & draw viruses
      game.viruses = game.viruses.filter((virus) => {
        virus.y += virus.speed
        virus.angle += 0.02
        virus.spikePhase += 0.1

        if (virus.y > 520) {
          game.shield -= 10
          setShield(game.shield)
          if (game.shield <= 0) {
            setGameState("gameover")
            saveScore(game.score)
          }
          return false
        }

        drawVirus(virus)
        return true
      })

      // Update & draw bullets
      game.bullets = game.bullets.filter((bullet) => {
        bullet.x += Math.cos(bullet.angle) * bullet.speed
        bullet.y += Math.sin(bullet.angle) * bullet.speed

        // Draw bullet
        ctx.save()
        ctx.translate(bullet.x, bullet.y)
        ctx.rotate(bullet.angle)
        
        const bulletGrad = ctx.createLinearGradient(-10, 0, 10, 0)
        bulletGrad.addColorStop(0, "#22d3ee")
        bulletGrad.addColorStop(1, "#0ea5e9")
        ctx.fillStyle = bulletGrad
        ctx.beginPath()
        ctx.ellipse(0, 0, 8, 3, 0, 0, Math.PI * 2)
        ctx.fill()

        ctx.shadowColor = "#22d3ee"
        ctx.shadowBlur = 10
        ctx.fill()
        ctx.restore()

        // Check collision
        for (let i = game.viruses.length - 1; i >= 0; i--) {
          const virus = game.viruses[i]
          const dx = bullet.x - virus.x
          const dy = bullet.y - virus.y
          const dist = Math.sqrt(dx * dx + dy * dy)

          if (dist < virus.radius + 5) {
            virus.health--
            
            // Hit particles
            for (let j = 0; j < 5; j++) {
              game.particles.push({
                x: bullet.x,
                y: bullet.y,
                vx: (Math.random() - 0.5) * 5,
                vy: (Math.random() - 0.5) * 5,
                life: 1,
                color: ["#22c55e", "#ef4444", "#a855f7"][virus.type],
                size: 3,
              })
            }

            if (virus.health <= 0) {
              // Death particles
              for (let j = 0; j < 15; j++) {
                game.particles.push({
                  x: virus.x,
                  y: virus.y,
                  vx: (Math.random() - 0.5) * 8,
                  vy: (Math.random() - 0.5) * 8,
                  life: 1,
                  color: ["#22c55e", "#ef4444", "#a855f7"][virus.type],
                  size: 5,
                })
              }
              game.viruses.splice(i, 1)
              game.score += (virus.type + 1) * 100
              game.virusesKilled++
              setScore(game.score)

              // Check wave
              if (game.virusesKilled >= game.virusesPerWave) {
                game.wave++
                game.virusesKilled = 0
                game.virusesPerWave += 5
                setWave(game.wave)
              }
            }
            return false
          }
        }

        return bullet.x > 0 && bullet.x < 800 && bullet.y > 0 && bullet.y < 600
      })

      // Update & draw power-ups
      game.powerUps = game.powerUps.filter((powerUp) => {
        powerUp.y += 2

        // Check collection
        const dx = powerUp.x - 400
        const dy = powerUp.y - 550
        if (Math.sqrt(dx * dx + dy * dy) < 50) {
          if (powerUp.type === 'rapid') {
            game.rapidFire = true
            game.rapidFireEnd = Date.now() + 5000
            setRapidFire(true)
          } else if (powerUp.type === 'shield') {
            game.shield = Math.min(100, game.shield + 30)
            setShield(game.shield)
          } else if (powerUp.type === 'bomb') {
            game.viruses.forEach((v) => {
              for (let j = 0; j < 10; j++) {
                game.particles.push({
                  x: v.x,
                  y: v.y,
                  vx: (Math.random() - 0.5) * 8,
                  vy: (Math.random() - 0.5) * 8,
                  life: 1,
                  color: "#ef4444",
                  size: 5,
                })
              }
              game.score += (v.type + 1) * 50
            })
            game.viruses = []
            setScore(game.score)
          }
          return false
        }

        if (powerUp.y > 600) return false

        drawPowerUp(powerUp)
        return true
      })

      // Update & draw particles
      game.particles = game.particles.filter((p) => {
        p.x += p.vx
        p.y += p.vy
        p.life -= 0.02

        ctx.globalAlpha = p.life
        ctx.fillStyle = p.color
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = 1

        return p.life > 0
      })

      drawTurret()

      // UI
      ctx.fillStyle = "#fff"
      ctx.font = "bold 24px Arial"
      ctx.textAlign = "left"
      ctx.fillText(`Score: ${game.score}`, 20, 40)
      ctx.fillText(`Wave: ${game.wave}`, 20, 70)

      // Timer
      const minutes = Math.floor(timeLeft / 60)
      const seconds = timeLeft % 60
      ctx.textAlign = "center"
      ctx.fillStyle = timeLeft < 30 ? "#ef4444" : "#fff"
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, "0")}`, 400, 40)

      // Shield bar
      ctx.fillStyle = "#333"
      ctx.fillRect(600, 25, 150, 20)
      ctx.fillStyle = game.shield > 50 ? "#3b82f6" : game.shield > 25 ? "#eab308" : "#ef4444"
      ctx.fillRect(600, 25, (150 * game.shield) / 100, 20)
      ctx.strokeStyle = "#fff"
      ctx.strokeRect(600, 25, 150, 20)
      ctx.fillStyle = "#fff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.fillText(`SHIELD: ${game.shield}%`, 675, 39)

      if (game.rapidFire) {
        ctx.fillStyle = "#22d3ee"
        ctx.font = "bold 16px Arial"
        ctx.fillText("RAPID FIRE!", 400, 70)
      }

      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      cancelAnimationFrame(animationId)
      clearInterval(timerInterval)
      clearInterval(spawnInterval)
      clearInterval(powerUpInterval)
      canvas.removeEventListener("mousemove", handleMouseMove)
      canvas.removeEventListener("click", handleClick)
    }
  }, [gameState, timeLeft, saveScore])

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      <div className="mb-4 flex items-center gap-4">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Virus Shooter</h1>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          className="border-4 border-indigo-500 rounded-lg shadow-2xl cursor-crosshair"
        />

        {gameState === "menu" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-white mb-4">Virus Shooter</h2>
            <p className="text-gray-300 mb-2">Click to shoot viruses!</p>
            <p className="text-gray-400 mb-4 text-sm">Collect power-ups: R-Rapid Fire, S-Shield, B-Bomb</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-indigo-600 hover:bg-indigo-700">
              Start Game
            </Button>
          </div>
        )}

        {gameState === "gameover" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-red-500 mb-4">Game Over!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-xl text-gray-300 mb-2">Wave Reached: {wave}</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-indigo-600 hover:bg-indigo-700">
              Play Again
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
