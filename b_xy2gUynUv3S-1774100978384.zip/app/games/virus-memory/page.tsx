"use client"

import { useEffect, useState, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Card {
  id: number
  virusType: number
  isFlipped: boolean
  isMatched: boolean
}

const virusColors = [
  { main: "#22c55e", glow: "#4ade80", name: "Green" },
  { main: "#ef4444", glow: "#f87171", name: "Red" },
  { main: "#a855f7", glow: "#c084fc", name: "Purple" },
  { main: "#3b82f6", glow: "#60a5fa", name: "Blue" },
  { main: "#f59e0b", glow: "#fbbf24", name: "Orange" },
  { main: "#ec4899", glow: "#f472b6", name: "Pink" },
  { main: "#14b8a6", glow: "#2dd4bf", name: "Teal" },
  { main: "#6366f1", glow: "#818cf8", name: "Indigo" },
]

export default function VirusMemoryGame() {
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover">("menu")
  const [cards, setCards] = useState<Card[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120)
  const [moves, setMoves] = useState(0)
  const [matches, setMatches] = useState(0)
  const [combo, setCombo] = useState(0)
  const canvasRefs = useRef<(HTMLCanvasElement | null)[]>([])

  const saveScore = useCallback((finalScore: number) => {
    const username = localStorage.getItem("ddosGuardUser") || "Anonymous"
    const leaderboard = JSON.parse(localStorage.getItem("ddosGuardLeaderboard") || "[]")
    leaderboard.push({
      username,
      score: finalScore,
      game: "Virus Memory",
      date: new Date().toISOString(),
    })
    leaderboard.sort((a: any, b: any) => b.score - a.score)
    localStorage.setItem("ddosGuardLeaderboard", JSON.stringify(leaderboard.slice(0, 100)))
    
    if (finalScore > highScore) {
      setHighScore(finalScore)
      localStorage.setItem("virusMemoryHighScore", finalScore.toString())
    }
  }, [highScore])

  const shuffleArray = <T,>(array: T[]): T[] => {
    const shuffled = [...array]
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
    }
    return shuffled
  }

  const startGame = useCallback(() => {
    const pairs = virusColors.map((_, index) => index)
    const cardPairs = [...pairs, ...pairs]
    const shuffledCards = shuffleArray(cardPairs).map((virusType, index) => ({
      id: index,
      virusType,
      isFlipped: false,
      isMatched: false,
    }))

    setCards(shuffledCards)
    setFlippedCards([])
    setScore(0)
    setMoves(0)
    setMatches(0)
    setCombo(0)
    setTimeLeft(120)
    setGameState("playing")
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem("virusMemoryHighScore")
    if (saved) setHighScore(parseInt(saved))
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameState("gameover")
          saveScore(score)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameState, score, saveScore])

  // Draw viruses on canvas
  useEffect(() => {
    cards.forEach((card, index) => {
      const canvas = canvasRefs.current[index]
      if (!canvas) return
      const ctx = canvas.getContext("2d")
      if (!ctx) return

      ctx.clearRect(0, 0, 80, 80)

      if (card.isFlipped || card.isMatched) {
        const color = virusColors[card.virusType]
        const centerX = 40
        const centerY = 40
        const radius = 20

        // Glow
        ctx.shadowColor = color.glow
        ctx.shadowBlur = 15

        // Spikes
        const spikeCount = 8
        for (let i = 0; i < spikeCount; i++) {
          const angle = (i / spikeCount) * Math.PI * 2
          ctx.save()
          ctx.translate(centerX, centerY)
          ctx.rotate(angle)
          ctx.fillStyle = color.main
          ctx.beginPath()
          ctx.moveTo(radius * 0.6, -3)
          ctx.lineTo(radius + 8, 0)
          ctx.lineTo(radius * 0.6, 3)
          ctx.closePath()
          ctx.fill()
          ctx.beginPath()
          ctx.arc(radius + 8, 0, 4, 0, Math.PI * 2)
          ctx.fillStyle = color.glow
          ctx.fill()
          ctx.restore()
        }

        // Body
        const bodyGrad = ctx.createRadialGradient(centerX - 5, centerY - 5, 0, centerX, centerY, radius)
        bodyGrad.addColorStop(0, color.glow)
        bodyGrad.addColorStop(0.5, color.main)
        bodyGrad.addColorStop(1, color.main)
        ctx.fillStyle = bodyGrad
        ctx.beginPath()
        ctx.arc(centerX, centerY, radius * 0.7, 0, Math.PI * 2)
        ctx.fill()

        // Eyes
        ctx.shadowBlur = 0
        ctx.fillStyle = "#000"
        ctx.beginPath()
        ctx.ellipse(centerX - 6, centerY - 3, 4, 5, 0, 0, Math.PI * 2)
        ctx.ellipse(centerX + 6, centerY - 3, 4, 5, 0, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = "#fff"
        ctx.beginPath()
        ctx.arc(centerX - 5, centerY - 4, 2, 0, Math.PI * 2)
        ctx.arc(centerX + 7, centerY - 4, 2, 0, Math.PI * 2)
        ctx.fill()

        // Mouth
        ctx.strokeStyle = "#000"
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.arc(centerX, centerY + 8, 6, 0.2, Math.PI - 0.2)
        ctx.stroke()
      }
    })
  }, [cards])

  const handleCardClick = (cardId: number) => {
    if (gameState !== "playing") return
    if (flippedCards.length >= 2) return

    const card = cards.find((c) => c.id === cardId)
    if (!card || card.isFlipped || card.isMatched) return

    const newCards = cards.map((c) =>
      c.id === cardId ? { ...c, isFlipped: true } : c
    )
    setCards(newCards)

    const newFlipped = [...flippedCards, cardId]
    setFlippedCards(newFlipped)

    if (newFlipped.length === 2) {
      setMoves((m) => m + 1)
      const [first, second] = newFlipped
      const firstCard = newCards.find((c) => c.id === first)!
      const secondCard = newCards.find((c) => c.id === second)!

      if (firstCard.virusType === secondCard.virusType) {
        // Match!
        const newCombo = combo + 1
        setCombo(newCombo)
        const matchScore = 100 * newCombo + Math.floor(timeLeft / 10)
        setScore((s) => s + matchScore)
        setMatches((m) => m + 1)

        setTimeout(() => {
          setCards((prev) =>
            prev.map((c) =>
              c.id === first || c.id === second ? { ...c, isMatched: true } : c
            )
          )
          setFlippedCards([])

          // Check win
          if (matches + 1 === 8) {
            const bonus = timeLeft * 10
            const finalScore = score + matchScore + bonus
            setScore(finalScore)
            setGameState("gameover")
            saveScore(finalScore)
          }
        }, 500)
      } else {
        // No match
        setCombo(0)
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c) =>
              c.id === first || c.id === second ? { ...c, isFlipped: false } : c
            )
          )
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  const minutes = Math.floor(timeLeft / 60)
  const seconds = timeLeft % 60

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-indigo-900 to-orange-600 flex flex-col items-center justify-center p-4">
      <div className="mb-4 flex items-center gap-4">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Virus Memory</h1>
      </div>

      {gameState === "menu" && (
        <div className="bg-black/60 rounded-2xl p-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Virus Memory</h2>
          <p className="text-gray-300 mb-2">Match pairs of viruses!</p>
          <p className="text-gray-400 mb-4 text-sm">Build combos for bonus points</p>
          <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
          <Button onClick={startGame} size="lg" className="bg-purple-600 hover:bg-purple-700">
            Start Game
          </Button>
        </div>
      )}

      {gameState === "playing" && (
        <>
          <div className="flex gap-8 mb-4 text-white">
            <div className="text-center">
              <div className="text-sm text-gray-300">Score</div>
              <div className="text-2xl font-bold text-amber-400">{score}</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-300">Time</div>
              <div className={`text-2xl font-bold ${timeLeft < 30 ? "text-red-500" : "text-white"}`}>
                {minutes}:{seconds.toString().padStart(2, "0")}
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-300">Moves</div>
              <div className="text-2xl font-bold">{moves}</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-300">Combo</div>
              <div className="text-2xl font-bold text-green-400">x{combo}</div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3 p-4 bg-black/40 rounded-xl">
            {cards.map((card, index) => (
              <button
                key={card.id}
                onClick={() => handleCardClick(card.id)}
                disabled={card.isFlipped || card.isMatched}
                className={`w-20 h-20 rounded-lg transition-all duration-300 transform ${
                  card.isMatched
                    ? "opacity-50 scale-95"
                    : card.isFlipped
                    ? "scale-105"
                    : "hover:scale-105 hover:shadow-lg"
                } ${
                  card.isFlipped || card.isMatched
                    ? "bg-slate-800"
                    : "bg-gradient-to-br from-slate-700 to-slate-900 border-2 border-slate-600"
                }`}
                style={{
                  boxShadow: card.isFlipped && !card.isMatched
                    ? `0 0 20px ${virusColors[card.virusType].glow}`
                    : undefined,
                }}
              >
                <canvas
                  ref={(el) => {
                    canvasRefs.current[index] = el
                  }}
                  width={80}
                  height={80}
                  className="w-full h-full"
                />
                {!card.isFlipped && !card.isMatched && (
                  <div className="absolute inset-0 flex items-center justify-center text-4xl text-slate-500">
                    ?
                  </div>
                )}
              </button>
            ))}
          </div>

          <p className="mt-4 text-gray-400 text-sm">Matches: {matches}/8</p>
        </>
      )}

      {gameState === "gameover" && (
        <div className="bg-black/60 rounded-2xl p-8 text-center">
          <h2 className={`text-4xl font-bold mb-4 ${matches === 8 ? "text-green-500" : "text-amber-500"}`}>
            {matches === 8 ? "You Win!" : "Time's Up!"}
          </h2>
          <p className="text-2xl text-white mb-2">Final Score: {score}</p>
          <p className="text-xl text-gray-300 mb-2">Matches: {matches}/8 in {moves} moves</p>
          <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
          <Button onClick={startGame} size="lg" className="bg-purple-600 hover:bg-purple-700">
            Play Again
          </Button>
        </div>
      )}
    </div>
  )
}
