"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Point {
  x: number
  y: number
}

interface Virus {
  x: number
  y: number
  type: number
  pulse: number
}

export default function VirusSnakeGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover">("menu")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120)

  const gameRef = useRef({
    snake: [{ x: 10, y: 10 }] as Point[],
    direction: { x: 1, y: 0 },
    nextDirection: { x: 1, y: 0 },
    viruses: [] as Virus[],
    score: 0,
    gridSize: 20,
    cellSize: 25,
    stars: [] as { x: number; y: number; size: number; brightness: number }[],
  })

  const saveScore = useCallback((finalScore: number) => {
    const username = localStorage.getItem("ddosGuardUser") || "Anonymous"
    const leaderboard = JSON.parse(localStorage.getItem("ddosGuardLeaderboard") || "[]")
    leaderboard.push({
      username,
      score: finalScore,
      game: "Virus Snake",
      date: new Date().toISOString(),
    })
    leaderboard.sort((a: any, b: any) => b.score - a.score)
    localStorage.setItem("ddosGuardLeaderboard", JSON.stringify(leaderboard.slice(0, 100)))
    
    if (finalScore > highScore) {
      setHighScore(finalScore)
      localStorage.setItem("virusSnakeHighScore", finalScore.toString())
    }
  }, [highScore])

  const spawnVirus = useCallback(() => {
    const game = gameRef.current
    let x, y
    do {
      x = Math.floor(Math.random() * game.gridSize)
      y = Math.floor(Math.random() * game.gridSize)
    } while (game.snake.some((s) => s.x === x && s.y === y))

    game.viruses.push({
      x,
      y,
      type: Math.floor(Math.random() * 3),
      pulse: Math.random() * Math.PI * 2,
    })
  }, [])

  const startGame = useCallback(() => {
    const game = gameRef.current
    game.snake = [{ x: 10, y: 10 }]
    game.direction = { x: 1, y: 0 }
    game.nextDirection = { x: 1, y: 0 }
    game.viruses = []
    game.score = 0

    game.stars = []
    for (let i = 0; i < 80; i++) {
      game.stars.push({
        x: Math.random() * 500,
        y: Math.random() * 500,
        size: Math.random() * 2 + 0.5,
        brightness: Math.random(),
      })
    }

    for (let i = 0; i < 3; i++) spawnVirus()

    setScore(0)
    setTimeLeft(120)
    setGameState("playing")
  }, [spawnVirus])

  useEffect(() => {
    const saved = localStorage.getItem("virusSnakeHighScore")
    if (saved) setHighScore(parseInt(saved))
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const game = gameRef.current

    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case "ArrowUp":
        case "w":
        case "W":
          if (game.direction.y !== 1) game.nextDirection = { x: 0, y: -1 }
          break
        case "ArrowDown":
        case "s":
        case "S":
          if (game.direction.y !== -1) game.nextDirection = { x: 0, y: 1 }
          break
        case "ArrowLeft":
        case "a":
        case "A":
          if (game.direction.x !== 1) game.nextDirection = { x: -1, y: 0 }
          break
        case "ArrowRight":
        case "d":
        case "D":
          if (game.direction.x !== -1) game.nextDirection = { x: 1, y: 0 }
          break
      }
    }

    window.addEventListener("keydown", handleKeyDown)

    const timerInterval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameState("gameover")
          saveScore(game.score)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    const drawBackground = () => {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 500)
      skyGrad.addColorStop(0, "#1e1b4b")
      skyGrad.addColorStop(0.4, "#312e81")
      skyGrad.addColorStop(0.7, "#6366f1")
      skyGrad.addColorStop(0.9, "#f97316")
      skyGrad.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGrad
      ctx.fillRect(0, 0, 500, 500)

      game.stars.forEach((star) => {
        const brightness = 0.5 + Math.sin(Date.now() / 1000 + star.x) * 0.5
        ctx.fillStyle = `rgba(255, 255, 255, ${brightness * star.brightness})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()
      })

      // Grid overlay
      ctx.strokeStyle = "rgba(255, 255, 255, 0.05)"
      ctx.lineWidth = 1
      for (let i = 0; i <= game.gridSize; i++) {
        ctx.beginPath()
        ctx.moveTo(i * game.cellSize, 0)
        ctx.lineTo(i * game.cellSize, 500)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(0, i * game.cellSize)
        ctx.lineTo(500, i * game.cellSize)
        ctx.stroke()
      }
    }

    const drawSnake = () => {
      game.snake.forEach((segment, index) => {
        const x = segment.x * game.cellSize + game.cellSize / 2
        const y = segment.y * game.cellSize + game.cellSize / 2
        const radius = game.cellSize / 2 - 2

        if (index === 0) {
          // Head
          const headGrad = ctx.createRadialGradient(x - 3, y - 3, 0, x, y, radius)
          headGrad.addColorStop(0, "#60a5fa")
          headGrad.addColorStop(0.5, "#3b82f6")
          headGrad.addColorStop(1, "#1e40af")
          ctx.fillStyle = headGrad
          ctx.beginPath()
          ctx.arc(x, y, radius, 0, Math.PI * 2)
          ctx.fill()

          // Eyes
          const eyeOffset = game.direction.x !== 0 ? { x: game.direction.x * 4, y: -3 } : { x: -4, y: game.direction.y * 4 }
          ctx.fillStyle = "#fff"
          ctx.beginPath()
          ctx.arc(x + eyeOffset.x - 3, y + eyeOffset.y, 4, 0, Math.PI * 2)
          ctx.arc(x + eyeOffset.x + 5, y + eyeOffset.y, 4, 0, Math.PI * 2)
          ctx.fill()
          ctx.fillStyle = "#000"
          ctx.beginPath()
          ctx.arc(x + eyeOffset.x - 3 + game.direction.x, y + eyeOffset.y + game.direction.y, 2, 0, Math.PI * 2)
          ctx.arc(x + eyeOffset.x + 5 + game.direction.x, y + eyeOffset.y + game.direction.y, 2, 0, Math.PI * 2)
          ctx.fill()

          // Glow
          ctx.shadowColor = "#3b82f6"
          ctx.shadowBlur = 15
          ctx.strokeStyle = "#60a5fa"
          ctx.lineWidth = 2
          ctx.beginPath()
          ctx.arc(x, y, radius, 0, Math.PI * 2)
          ctx.stroke()
          ctx.shadowBlur = 0
        } else {
          // Body segment
          const progress = index / game.snake.length
          const bodyGrad = ctx.createRadialGradient(x - 2, y - 2, 0, x, y, radius * 0.9)
          bodyGrad.addColorStop(0, `rgba(96, 165, 250, ${1 - progress * 0.5})`)
          bodyGrad.addColorStop(0.6, `rgba(59, 130, 246, ${1 - progress * 0.5})`)
          bodyGrad.addColorStop(1, `rgba(30, 64, 175, ${1 - progress * 0.5})`)
          ctx.fillStyle = bodyGrad
          ctx.beginPath()
          ctx.arc(x, y, radius * 0.85 - index * 0.2, 0, Math.PI * 2)
          ctx.fill()

          // Circuit pattern
          if (index % 2 === 0) {
            ctx.strokeStyle = `rgba(147, 197, 253, ${0.5 - progress * 0.3})`
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.arc(x, y, radius * 0.5, 0, Math.PI)
            ctx.stroke()
          }
        }
      })
    }

    const drawVirus = (virus: Virus) => {
      const x = virus.x * game.cellSize + game.cellSize / 2
      const y = virus.y * game.cellSize + game.cellSize / 2
      const radius = game.cellSize / 2 - 4
      virus.pulse += 0.1

      const colors = [
        { main: "#22c55e", glow: "#4ade80", dark: "#166534" },
        { main: "#ef4444", glow: "#f87171", dark: "#991b1b" },
        { main: "#a855f7", glow: "#c084fc", dark: "#6b21a8" },
      ]
      const color = colors[virus.type]

      ctx.save()
      ctx.translate(x, y)

      // Glow
      ctx.shadowColor = color.glow
      ctx.shadowBlur = 10 + Math.sin(virus.pulse) * 5

      // Spikes
      const spikeCount = 8
      for (let i = 0; i < spikeCount; i++) {
        const angle = (i / spikeCount) * Math.PI * 2
        const spikeLen = radius * 0.6 + Math.sin(virus.pulse + i) * 2
        ctx.save()
        ctx.rotate(angle)
        ctx.fillStyle = color.main
        ctx.beginPath()
        ctx.moveTo(radius * 0.6, -2)
        ctx.lineTo(radius + spikeLen, 0)
        ctx.lineTo(radius * 0.6, 2)
        ctx.closePath()
        ctx.fill()
        ctx.beginPath()
        ctx.arc(radius + spikeLen, 0, 3, 0, Math.PI * 2)
        ctx.fillStyle = color.glow
        ctx.fill()
        ctx.restore()
      }

      // Body
      const bodyGrad = ctx.createRadialGradient(-2, -2, 0, 0, 0, radius)
      bodyGrad.addColorStop(0, color.glow)
      bodyGrad.addColorStop(0.5, color.main)
      bodyGrad.addColorStop(1, color.dark)
      ctx.fillStyle = bodyGrad
      ctx.beginPath()
      ctx.arc(0, 0, radius * 0.7, 0, Math.PI * 2)
      ctx.fill()

      // Face
      ctx.fillStyle = "#000"
      ctx.beginPath()
      ctx.ellipse(-4, -2, 3, 4, 0, 0, Math.PI * 2)
      ctx.ellipse(4, -2, 3, 4, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = "#ff0000"
      ctx.beginPath()
      ctx.arc(-4, -2, 1.5, 0, Math.PI * 2)
      ctx.arc(4, -2, 1.5, 0, Math.PI * 2)
      ctx.fill()

      ctx.shadowBlur = 0
      ctx.restore()
    }

    const gameLoop = () => {
      game.direction = game.nextDirection
      const head = game.snake[0]
      const newHead = {
        x: (head.x + game.direction.x + game.gridSize) % game.gridSize,
        y: (head.y + game.direction.y + game.gridSize) % game.gridSize,
      }

      // Check self collision
      if (game.snake.some((s) => s.x === newHead.x && s.y === newHead.y)) {
        setGameState("gameover")
        saveScore(game.score)
        return
      }

      game.snake.unshift(newHead)

      // Check virus collision
      const virusIndex = game.viruses.findIndex((v) => v.x === newHead.x && v.y === newHead.y)
      if (virusIndex !== -1) {
        const virus = game.viruses[virusIndex]
        game.viruses.splice(virusIndex, 1)
        game.score += (virus.type + 1) * 100
        setScore(game.score)
        spawnVirus()
        if (Math.random() < 0.3) spawnVirus()
      } else {
        game.snake.pop()
      }
    }

    const render = () => {
      ctx.clearRect(0, 0, 500, 500)
      drawBackground()
      game.viruses.forEach(drawVirus)
      drawSnake()

      // UI
      ctx.fillStyle = "#fff"
      ctx.font = "bold 20px Arial"
      ctx.textAlign = "left"
      ctx.fillText(`Score: ${game.score}`, 10, 25)

      const minutes = Math.floor(timeLeft / 60)
      const seconds = timeLeft % 60
      ctx.textAlign = "right"
      ctx.fillStyle = timeLeft < 30 ? "#ef4444" : "#fff"
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, "0")}`, 490, 25)
    }

    const gameInterval = setInterval(gameLoop, 120)
    let animationId: number
    const animate = () => {
      render()
      animationId = requestAnimationFrame(animate)
    }
    animate()

    return () => {
      clearInterval(gameInterval)
      clearInterval(timerInterval)
      cancelAnimationFrame(animationId)
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [gameState, timeLeft, spawnVirus, saveScore])

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      <div className="mb-4 flex items-center gap-4">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Virus Snake</h1>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={500}
          height={500}
          className="border-4 border-blue-500 rounded-lg shadow-2xl"
        />

        {gameState === "menu" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-white mb-4">Virus Snake</h2>
            <p className="text-gray-300 mb-2">Use Arrow Keys or WASD to move</p>
            <p className="text-gray-400 mb-4 text-sm">Eat viruses to grow and score points!</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-blue-600 hover:bg-blue-700">
              Start Game
            </Button>
          </div>
        )}

        {gameState === "gameover" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-red-500 mb-4">Game Over!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-blue-600 hover:bg-blue-700">
              Play Again
            </Button>
          </div>
        )}
      </div>

      <p className="mt-4 text-gray-400 text-sm">Arrow Keys / WASD to move</p>
    </div>
  )
}
