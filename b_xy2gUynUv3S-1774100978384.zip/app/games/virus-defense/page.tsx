"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Virus {
  id: number
  x: number
  y: number
  health: number
  maxHealth: number
  speed: number
  type: number
  pathIndex: number
  angle: number
  pulse: number
}

interface Tower {
  x: number
  y: number
  type: number
  range: number
  damage: number
  fireRate: number
  lastFire: number
  angle: number
}

interface Bullet {
  x: number
  y: number
  targetId: number
  speed: number
  damage: number
  color: string
}

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  color: string
}

const PATH = [
  { x: -30, y: 300 },
  { x: 100, y: 300 },
  { x: 100, y: 150 },
  { x: 300, y: 150 },
  { x: 300, y: 400 },
  { x: 500, y: 400 },
  { x: 500, y: 200 },
  { x: 700, y: 200 },
  { x: 700, y: 350 },
  { x: 830, y: 350 },
]

const TOWER_TYPES = [
  { name: "Basic", cost: 50, range: 100, damage: 10, fireRate: 1000, color: "#3b82f6" },
  { name: "Sniper", cost: 100, range: 180, damage: 30, fireRate: 2000, color: "#22c55e" },
  { name: "Rapid", cost: 75, range: 80, damage: 5, fireRate: 300, color: "#f59e0b" },
]

export default function VirusDefenseGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover" | "win">("menu")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [money, setMoney] = useState(200)
  const [lives, setLives] = useState(20)
  const [wave, setWave] = useState(1)
  const [selectedTower, setSelectedTower] = useState(0)

  const gameRef = useRef({
    viruses: [] as Virus[],
    towers: [] as Tower[],
    bullets: [] as Bullet[],
    particles: [] as Particle[],
    virusId: 0,
    money: 200,
    lives: 20,
    wave: 1,
    score: 0,
    waveTimer: 0,
    virusesSpawned: 0,
    virusesPerWave: 10,
    waveInProgress: false,
    stars: [] as { x: number; y: number; size: number; brightness: number }[],
  })

  const saveScore = useCallback((finalScore: number) => {
    const username = localStorage.getItem("ddosGuardUser") || "Anonymous"
    const leaderboard = JSON.parse(localStorage.getItem("ddosGuardLeaderboard") || "[]")
    leaderboard.push({
      username,
      score: finalScore,
      game: "Virus Defense",
      date: new Date().toISOString(),
    })
    leaderboard.sort((a: any, b: any) => b.score - a.score)
    localStorage.setItem("ddosGuardLeaderboard", JSON.stringify(leaderboard.slice(0, 100)))
    
    if (finalScore > highScore) {
      setHighScore(finalScore)
      localStorage.setItem("virusDefenseHighScore", finalScore.toString())
    }
  }, [highScore])

  const startGame = useCallback(() => {
    const game = gameRef.current
    game.viruses = []
    game.towers = []
    game.bullets = []
    game.particles = []
    game.virusId = 0
    game.money = 200
    game.lives = 20
    game.wave = 1
    game.score = 0
    game.waveTimer = 0
    game.virusesSpawned = 0
    game.virusesPerWave = 10
    game.waveInProgress = false

    game.stars = []
    for (let i = 0; i < 80; i++) {
      game.stars.push({
        x: Math.random() * 800,
        y: Math.random() * 600,
        size: Math.random() * 2 + 0.5,
        brightness: Math.random(),
      })
    }

    setScore(0)
    setMoney(200)
    setLives(20)
    setWave(1)
    setGameState("playing")
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem("virusDefenseHighScore")
    if (saved) setHighScore(parseInt(saved))
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const game = gameRef.current

    const handleClick = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top

      // Check if clicking on path
      let onPath = false
      for (let i = 0; i < PATH.length - 1; i++) {
        const p1 = PATH[i]
        const p2 = PATH[i + 1]
        const dist = pointToLineDistance(x, y, p1.x, p1.y, p2.x, p2.y)
        if (dist < 30) {
          onPath = true
          break
        }
      }

      // Check if clicking on existing tower
      const onTower = game.towers.some((t) => {
        const dx = t.x - x
        const dy = t.y - y
        return Math.sqrt(dx * dx + dy * dy) < 25
      })

      if (!onPath && !onTower && x > 20 && x < 780 && y > 20 && y < 580) {
        const towerType = TOWER_TYPES[selectedTower]
        if (game.money >= towerType.cost) {
          game.money -= towerType.cost
          setMoney(game.money)
          game.towers.push({
            x,
            y,
            type: selectedTower,
            range: towerType.range,
            damage: towerType.damage,
            fireRate: towerType.fireRate,
            lastFire: 0,
            angle: 0,
          })
        }
      }
    }

    canvas.addEventListener("click", handleClick)

    const pointToLineDistance = (px: number, py: number, x1: number, y1: number, x2: number, y2: number) => {
      const A = px - x1
      const B = py - y1
      const C = x2 - x1
      const D = y2 - y1
      const dot = A * C + B * D
      const lenSq = C * C + D * D
      let param = -1
      if (lenSq !== 0) param = dot / lenSq
      let xx, yy
      if (param < 0) { xx = x1; yy = y1 }
      else if (param > 1) { xx = x2; yy = y2 }
      else { xx = x1 + param * C; yy = y1 + param * D }
      const dx = px - xx
      const dy = py - yy
      return Math.sqrt(dx * dx + dy * dy)
    }

    const drawBackground = () => {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 600)
      skyGrad.addColorStop(0, "#1e1b4b")
      skyGrad.addColorStop(0.3, "#312e81")
      skyGrad.addColorStop(0.6, "#6366f1")
      skyGrad.addColorStop(0.85, "#f97316")
      skyGrad.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGrad
      ctx.fillRect(0, 0, 800, 600)

      game.stars.forEach((star) => {
        const brightness = 0.5 + Math.sin(Date.now() / 1000 + star.x) * 0.5
        ctx.fillStyle = `rgba(255, 255, 255, ${brightness * star.brightness})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()
      })

      // Draw path
      ctx.strokeStyle = "#475569"
      ctx.lineWidth = 40
      ctx.lineCap = "round"
      ctx.lineJoin = "round"
      ctx.beginPath()
      ctx.moveTo(PATH[0].x, PATH[0].y)
      PATH.slice(1).forEach((p) => ctx.lineTo(p.x, p.y))
      ctx.stroke()

      ctx.strokeStyle = "#64748b"
      ctx.lineWidth = 36
      ctx.beginPath()
      ctx.moveTo(PATH[0].x, PATH[0].y)
      PATH.slice(1).forEach((p) => ctx.lineTo(p.x, p.y))
      ctx.stroke()

      // Path marks
      ctx.setLineDash([20, 20])
      ctx.strokeStyle = "#94a3b8"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(PATH[0].x, PATH[0].y)
      PATH.slice(1).forEach((p) => ctx.lineTo(p.x, p.y))
      ctx.stroke()
      ctx.setLineDash([])
    }

    const drawVirus = (virus: Virus) => {
      virus.angle += 0.03
      virus.pulse += 0.1
      const colors = [
        { main: "#22c55e", glow: "#4ade80" },
        { main: "#ef4444", glow: "#f87171" },
        { main: "#a855f7", glow: "#c084fc" },
      ]
      const color = colors[virus.type]
      const radius = 12 + virus.type * 2

      ctx.save()
      ctx.translate(virus.x, virus.y)
      ctx.rotate(virus.angle)

      ctx.shadowColor = color.glow
      ctx.shadowBlur = 10

      const spikeCount = 8
      for (let i = 0; i < spikeCount; i++) {
        const angle = (i / spikeCount) * Math.PI * 2
        const spikeLen = radius * 0.5 + Math.sin(virus.pulse + i) * 2
        ctx.save()
        ctx.rotate(angle)
        ctx.fillStyle = color.main
        ctx.beginPath()
        ctx.moveTo(radius * 0.6, -2)
        ctx.lineTo(radius + spikeLen, 0)
        ctx.lineTo(radius * 0.6, 2)
        ctx.closePath()
        ctx.fill()
        ctx.beginPath()
        ctx.arc(radius + spikeLen, 0, 3, 0, Math.PI * 2)
        ctx.fillStyle = color.glow
        ctx.fill()
        ctx.restore()
      }

      const bodyGrad = ctx.createRadialGradient(-2, -2, 0, 0, 0, radius * 0.7)
      bodyGrad.addColorStop(0, color.glow)
      bodyGrad.addColorStop(1, color.main)
      ctx.fillStyle = bodyGrad
      ctx.beginPath()
      ctx.arc(0, 0, radius * 0.6, 0, Math.PI * 2)
      ctx.fill()

      ctx.fillStyle = "#000"
      ctx.beginPath()
      ctx.arc(-4, -2, 3, 0, Math.PI * 2)
      ctx.arc(4, -2, 3, 0, Math.PI * 2)
      ctx.fill()

      ctx.shadowBlur = 0
      ctx.restore()

      // Health bar
      const healthPercent = virus.health / virus.maxHealth
      ctx.fillStyle = "#333"
      ctx.fillRect(virus.x - 15, virus.y - radius - 10, 30, 5)
      ctx.fillStyle = healthPercent > 0.5 ? "#22c55e" : healthPercent > 0.25 ? "#eab308" : "#ef4444"
      ctx.fillRect(virus.x - 15, virus.y - radius - 10, 30 * healthPercent, 5)
    }

    const drawTower = (tower: Tower) => {
      const towerType = TOWER_TYPES[tower.type]

      ctx.save()
      ctx.translate(tower.x, tower.y)

      // Range indicator (faint)
      ctx.fillStyle = `${towerType.color}10`
      ctx.beginPath()
      ctx.arc(0, 0, tower.range, 0, Math.PI * 2)
      ctx.fill()

      // Base
      ctx.shadowColor = towerType.color
      ctx.shadowBlur = 10
      const baseGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, 20)
      baseGrad.addColorStop(0, "#94a3b8")
      baseGrad.addColorStop(1, "#475569")
      ctx.fillStyle = baseGrad
      ctx.beginPath()
      ctx.arc(0, 0, 18, 0, Math.PI * 2)
      ctx.fill()

      // Turret
      ctx.rotate(tower.angle)
      ctx.fillStyle = towerType.color
      ctx.fillRect(-5, -25, 10, 20)
      ctx.fillStyle = "#1e293b"
      ctx.fillRect(-3, -30, 6, 8)

      ctx.shadowBlur = 0
      ctx.restore()
    }

    const drawBullet = (bullet: Bullet) => {
      ctx.fillStyle = bullet.color
      ctx.shadowColor = bullet.color
      ctx.shadowBlur = 8
      ctx.beginPath()
      ctx.arc(bullet.x, bullet.y, 4, 0, Math.PI * 2)
      ctx.fill()
      ctx.shadowBlur = 0
    }

    let animationId: number
    const gameLoop = () => {
      const now = Date.now()

      // Spawn viruses
      if (!game.waveInProgress && game.viruses.length === 0) {
        game.waveInProgress = true
        game.virusesSpawned = 0
        game.waveTimer = now
      }

      if (game.waveInProgress && game.virusesSpawned < game.virusesPerWave) {
        if (now - game.waveTimer > 800) {
          game.waveTimer = now
          const type = Math.min(2, Math.floor(Math.random() * (1 + game.wave / 3)))
          game.viruses.push({
            id: game.virusId++,
            x: PATH[0].x,
            y: PATH[0].y,
            health: 30 + type * 20 + game.wave * 5,
            maxHealth: 30 + type * 20 + game.wave * 5,
            speed: 1.5 - type * 0.2 + game.wave * 0.05,
            type,
            pathIndex: 0,
            angle: 0,
            pulse: Math.random() * Math.PI * 2,
          })
          game.virusesSpawned++
        }
      }

      if (game.waveInProgress && game.virusesSpawned >= game.virusesPerWave && game.viruses.length === 0) {
        game.waveInProgress = false
        game.wave++
        game.virusesPerWave += 3
        game.money += 50 + game.wave * 10
        setWave(game.wave)
        setMoney(game.money)

        if (game.wave > 10) {
          const bonus = game.lives * 100 + game.money
          game.score += bonus
          setScore(game.score)
          setGameState("win")
          saveScore(game.score)
        }
      }

      // Update viruses
      game.viruses = game.viruses.filter((virus) => {
        const target = PATH[virus.pathIndex + 1]
        if (!target) {
          game.lives--
          setLives(game.lives)
          if (game.lives <= 0) {
            setGameState("gameover")
            saveScore(game.score)
          }
          return false
        }

        const dx = target.x - virus.x
        const dy = target.y - virus.y
        const dist = Math.sqrt(dx * dx + dy * dy)

        if (dist < virus.speed) {
          virus.pathIndex++
        } else {
          virus.x += (dx / dist) * virus.speed
          virus.y += (dy / dist) * virus.speed
        }

        return true
      })

      // Towers attack
      game.towers.forEach((tower) => {
        let closestVirus: Virus | null = null
        let closestDist = tower.range

        game.viruses.forEach((virus) => {
          const dx = virus.x - tower.x
          const dy = virus.y - tower.y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < closestDist) {
            closestDist = dist
            closestVirus = virus
          }
        })

        if (closestVirus) {
          tower.angle = Math.atan2(closestVirus.y - tower.y, closestVirus.x - tower.x) + Math.PI / 2

          if (now - tower.lastFire > tower.fireRate) {
            tower.lastFire = now
            game.bullets.push({
              x: tower.x,
              y: tower.y,
              targetId: closestVirus.id,
              speed: 8,
              damage: tower.damage,
              color: TOWER_TYPES[tower.type].color,
            })
          }
        }
      })

      // Update bullets
      game.bullets = game.bullets.filter((bullet) => {
        const target = game.viruses.find((v) => v.id === bullet.targetId)
        if (!target) return false

        const dx = target.x - bullet.x
        const dy = target.y - bullet.y
        const dist = Math.sqrt(dx * dx + dy * dy)

        if (dist < 10) {
          target.health -= bullet.damage

          for (let i = 0; i < 3; i++) {
            game.particles.push({
              x: bullet.x,
              y: bullet.y,
              vx: (Math.random() - 0.5) * 4,
              vy: (Math.random() - 0.5) * 4,
              life: 1,
              color: bullet.color,
            })
          }

          if (target.health <= 0) {
            const index = game.viruses.indexOf(target)
            if (index > -1) {
              game.viruses.splice(index, 1)
              game.score += (target.type + 1) * 50
              game.money += 10 + target.type * 5
              setScore(game.score)
              setMoney(game.money)

              for (let i = 0; i < 10; i++) {
                const colors = ["#22c55e", "#ef4444", "#a855f7"]
                game.particles.push({
                  x: target.x,
                  y: target.y,
                  vx: (Math.random() - 0.5) * 8,
                  vy: (Math.random() - 0.5) * 8,
                  life: 1,
                  color: colors[target.type],
                })
              }
            }
          }

          return false
        }

        bullet.x += (dx / dist) * bullet.speed
        bullet.y += (dy / dist) * bullet.speed
        return true
      })

      // Render
      ctx.clearRect(0, 0, 800, 600)
      drawBackground()

      game.towers.forEach(drawTower)
      game.viruses.forEach(drawVirus)
      game.bullets.forEach(drawBullet)

      game.particles = game.particles.filter((p) => {
        p.x += p.vx
        p.y += p.vy
        p.life -= 0.03

        ctx.globalAlpha = p.life
        ctx.fillStyle = p.color
        ctx.beginPath()
        ctx.arc(p.x, p.y, 3 * p.life, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = 1

        return p.life > 0
      })

      // UI
      ctx.fillStyle = "#fff"
      ctx.font = "bold 18px Arial"
      ctx.textAlign = "left"
      ctx.fillText(`Wave: ${game.wave}/10`, 20, 30)
      ctx.fillText(`Lives: ${game.lives}`, 20, 55)
      ctx.fillStyle = "#fbbf24"
      ctx.fillText(`$${game.money}`, 150, 30)
      ctx.fillStyle = "#fff"
      ctx.fillText(`Score: ${game.score}`, 150, 55)

      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      cancelAnimationFrame(animationId)
      canvas.removeEventListener("click", handleClick)
    }
  }, [gameState, selectedTower, saveScore])

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      <div className="mb-4 flex items-center gap-4">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Virus Defense</h1>
      </div>

      {gameState === "playing" && (
        <div className="mb-2 flex gap-2">
          {TOWER_TYPES.map((tower, i) => (
            <Button
              key={i}
              variant={selectedTower === i ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedTower(i)}
              style={{ borderColor: tower.color, color: selectedTower === i ? "#fff" : tower.color }}
              className={selectedTower === i ? "" : "bg-transparent"}
            >
              {tower.name} (${tower.cost})
            </Button>
          ))}
        </div>
      )}

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          className="border-4 border-amber-500 rounded-lg shadow-2xl"
        />

        {gameState === "menu" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-white mb-4">Virus Defense</h2>
            <p className="text-gray-300 mb-2">Click to place towers and defend against viruses!</p>
            <p className="text-gray-400 mb-4 text-sm">Survive 10 waves to win</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-amber-600 hover:bg-amber-700">
              Start Game
            </Button>
          </div>
        )}

        {gameState === "gameover" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-red-500 mb-4">Game Over!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-xl text-gray-300 mb-2">Reached Wave: {wave}</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-amber-600 hover:bg-amber-700">
              Play Again
            </Button>
          </div>
        )}

        {gameState === "win" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-green-500 mb-4">Victory!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-amber-600 hover:bg-amber-700">
              Play Again
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
