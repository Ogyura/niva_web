"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import Link from "next/link"
import { ArrowLeft, Play, RotateCcw, Zap, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Pipe {
  x: number
  gapY: number
  passed: boolean
}

const GAME_DURATION = 120 // 2 minutes
const GRAVITY = 0.4
const JUMP_FORCE = -8
const PIPE_SPEED = 3
const PIPE_GAP = 180
const PIPE_WIDTH = 80

export default function FlappyVirusGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover">("menu")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(GAME_DURATION)

  const gameRef = useRef({
    virusX: 150,
    virusY: 250,
    velocityY: 0,
    rotation: 0,
    pipes: [] as Pipe[],
    score: 0,
    timeLeft: GAME_DURATION,
    lastTime: 0,
    frameCount: 0,
    spikeRotation: 0,
  })

  // Save score to leaderboard
  const saveToLeaderboard = useCallback((finalScore: number) => {
    const stored = localStorage.getItem("flappyVirusLeaderboard")
    const leaderboard = stored ? JSON.parse(stored) : []
    const username = localStorage.getItem("ddosGuardUser") || "Player"
    
    leaderboard.push({
      username,
      score: finalScore,
      distance: `${finalScore} pipes`,
      date: new Date().toISOString(),
      game: "flappy-virus"
    })
    
    leaderboard.sort((a: { score: number }, b: { score: number }) => b.score - a.score)
    const top20 = leaderboard.slice(0, 20)
    
    localStorage.setItem("flappyVirusLeaderboard", JSON.stringify(top20))
  }, [])

  const startGame = useCallback(() => {
    gameRef.current = {
      virusX: 150,
      virusY: 250,
      velocityY: 0,
      rotation: 0,
      pipes: [],
      score: 0,
      timeLeft: GAME_DURATION,
      lastTime: Date.now(),
      frameCount: 0,
      spikeRotation: 0,
    }
    
    setScore(0)
    setTimeLeft(GAME_DURATION)
    setGameState("playing")
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationId: number

    const handleJump = () => {
      gameRef.current.velocityY = JUMP_FORCE
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Space" || e.key === "ArrowUp" || e.key === "w" || e.key === "W") {
        e.preventDefault()
        handleJump()
      }
    }

    const handleClick = () => {
      handleJump()
    }

    window.addEventListener("keydown", handleKeyDown)
    canvas.addEventListener("click", handleClick)
    canvas.addEventListener("touchstart", handleClick)

    const drawBackground = () => {
      // Evening sky gradient (same as hill climb)
      const skyGradient = ctx.createLinearGradient(0, 0, 0, canvas.height * 0.7)
      skyGradient.addColorStop(0, "#1e1b4b")
      skyGradient.addColorStop(0.3, "#4c1d95")
      skyGradient.addColorStop(0.5, "#7c3aed")
      skyGradient.addColorStop(0.7, "#f97316")
      skyGradient.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Stars
      ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
      for (let i = 0; i < 50; i++) {
        const starX = (i * 73 + gameRef.current.frameCount * 0.1) % canvas.width
        const starY = 20 + (i * 31) % 120
        const starSize = 0.5 + (i % 3) * 0.5
        const twinkle = Math.sin(Date.now() * 0.003 + i) * 0.3 + 0.7
        ctx.globalAlpha = twinkle
        ctx.beginPath()
        ctx.arc(starX, starY, starSize, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.globalAlpha = 1

      // Sun
      const sunX = canvas.width - 150
      const sunY = 150
      const sunGradient = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, 60)
      sunGradient.addColorStop(0, "#fef3c7")
      sunGradient.addColorStop(0.3, "#fbbf24")
      sunGradient.addColorStop(0.7, "#f97316")
      sunGradient.addColorStop(1, "transparent")
      ctx.fillStyle = sunGradient
      ctx.beginPath()
      ctx.arc(sunX, sunY, 60, 0, Math.PI * 2)
      ctx.fill()

      // Distant hills
      const hillGradient = ctx.createLinearGradient(0, 350, 0, canvas.height)
      hillGradient.addColorStop(0, "#581c87")
      hillGradient.addColorStop(1, "#7c3aed")
      ctx.fillStyle = hillGradient
      ctx.beginPath()
      ctx.moveTo(0, canvas.height)
      for (let x = 0; x <= canvas.width; x += 40) {
        const y = 400 + Math.sin((x + gameRef.current.frameCount * 0.5) * 0.01) * 40
        ctx.lineTo(x, y)
      }
      ctx.lineTo(canvas.width, canvas.height)
      ctx.closePath()
      ctx.fill()

      // Ground
      const groundGradient = ctx.createLinearGradient(0, canvas.height - 80, 0, canvas.height)
      groundGradient.addColorStop(0, "#166534")
      groundGradient.addColorStop(0.3, "#15803d")
      groundGradient.addColorStop(1, "#14532d")
      ctx.fillStyle = groundGradient
      ctx.fillRect(0, canvas.height - 80, canvas.width, 80)

      // Grass detail
      ctx.fillStyle = "#22c55e"
      for (let x = 0; x < canvas.width; x += 20) {
        const grassX = (x + gameRef.current.frameCount * 2) % canvas.width
        ctx.beginPath()
        ctx.moveTo(grassX, canvas.height - 80)
        ctx.lineTo(grassX + 5, canvas.height - 95)
        ctx.lineTo(grassX + 10, canvas.height - 80)
        ctx.fill()
      }

      // Background floating viruses
      const bgViruses = [
        { baseX: 100, baseY: 80, type: 0 },
        { baseX: 400, baseY: 100, type: 1 },
        { baseX: 700, baseY: 60, type: 2 },
      ]
      
      bgViruses.forEach((virus, i) => {
        const virusX = ((virus.baseX + gameRef.current.frameCount * 0.2) % (canvas.width + 100)) - 50
        const floatY = virus.baseY + Math.sin(Date.now() * 0.002 + i * 2) * 10
        
        const colors = [
          ["#EF4444", "#DC2626"],
          ["#22C55E", "#16A34A"],
          ["#3B82F6", "#2563EB"],
        ]
        const [main, dark] = colors[virus.type]
        
        ctx.save()
        ctx.globalAlpha = 0.4
        ctx.translate(virusX, floatY)
        
        ctx.shadowColor = main
        ctx.shadowBlur = 10
        
        ctx.fillStyle = main
        ctx.beginPath()
        ctx.arc(0, 0, 12, 0, Math.PI * 2)
        ctx.fill()
        
        ctx.fillStyle = dark
        for (let j = 0; j < 6; j++) {
          const angle = (j * Math.PI * 2) / 6 + Date.now() * 0.001
          ctx.beginPath()
          ctx.arc(Math.cos(angle) * 16, Math.sin(angle) * 16, 3, 0, Math.PI * 2)
          ctx.fill()
        }
        
        ctx.restore()
      })
    }

    const drawVirus = (x: number, y: number, rotation: number) => {
      ctx.save()
      ctx.translate(x, y)
      
      // Body rotation based on velocity
      ctx.rotate(rotation)
      
      // Glow effect
      ctx.shadowColor = "#EF4444"
      ctx.shadowBlur = 25
      
      // Main body gradient
      const bodyGradient = ctx.createRadialGradient(-5, -5, 0, 0, 0, 35)
      bodyGradient.addColorStop(0, "#F87171")
      bodyGradient.addColorStop(0.5, "#EF4444")
      bodyGradient.addColorStop(1, "#DC2626")
      
      ctx.fillStyle = bodyGradient
      ctx.beginPath()
      ctx.arc(0, 0, 30, 0, Math.PI * 2)
      ctx.fill()
      
      // Inner highlight
      const innerGradient = ctx.createRadialGradient(-10, -10, 0, 0, 0, 30)
      innerGradient.addColorStop(0, "rgba(255, 255, 255, 0.5)")
      innerGradient.addColorStop(0.5, "rgba(255, 255, 255, 0.1)")
      innerGradient.addColorStop(1, "transparent")
      ctx.fillStyle = innerGradient
      ctx.beginPath()
      ctx.arc(0, 0, 30, 0, Math.PI * 2)
      ctx.fill()
      
      // Animated spikes
      ctx.shadowBlur = 0
      const spikeRotation = gameRef.current.spikeRotation
      
      for (let i = 0; i < 12; i++) {
        const angle = (i * Math.PI * 2) / 12 + spikeRotation
        const spikeLength = 18 + Math.sin(Date.now() * 0.01 + i) * 3
        
        // Spike stem
        const gradient = ctx.createLinearGradient(
          Math.cos(angle) * 25, Math.sin(angle) * 25,
          Math.cos(angle) * (25 + spikeLength), Math.sin(angle) * (25 + spikeLength)
        )
        gradient.addColorStop(0, "#DC2626")
        gradient.addColorStop(1, "#991B1B")
        
        ctx.fillStyle = gradient
        ctx.beginPath()
        ctx.moveTo(Math.cos(angle - 0.2) * 25, Math.sin(angle - 0.2) * 25)
        ctx.lineTo(Math.cos(angle) * (25 + spikeLength), Math.sin(angle) * (25 + spikeLength))
        ctx.lineTo(Math.cos(angle + 0.2) * 25, Math.sin(angle + 0.2) * 25)
        ctx.closePath()
        ctx.fill()
        
        // Spike ball
        ctx.fillStyle = "#B91C1C"
        ctx.beginPath()
        ctx.arc(
          Math.cos(angle) * (25 + spikeLength),
          Math.sin(angle) * (25 + spikeLength),
          6,
          0,
          Math.PI * 2
        )
        ctx.fill()
        
        // Spike ball highlight
        ctx.fillStyle = "rgba(255, 255, 255, 0.3)"
        ctx.beginPath()
        ctx.arc(
          Math.cos(angle) * (25 + spikeLength) - 2,
          Math.sin(angle) * (25 + spikeLength) - 2,
          2,
          0,
          Math.PI * 2
        )
        ctx.fill()
      }
      
      // Eyes
      ctx.fillStyle = "#fff"
      ctx.beginPath()
      ctx.ellipse(-10, -5, 10, 12, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.ellipse(10, -5, 10, 12, 0, 0, Math.PI * 2)
      ctx.fill()
      
      // Pupils (follow rotation slightly)
      const pupilOffset = Math.min(3, rotation * 2)
      ctx.fillStyle = "#1F2937"
      ctx.beginPath()
      ctx.arc(-10 + pupilOffset, -3, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(10 + pupilOffset, -3, 5, 0, Math.PI * 2)
      ctx.fill()
      
      // Eye shine
      ctx.fillStyle = "#fff"
      ctx.beginPath()
      ctx.arc(-12, -6, 2, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(8, -6, 2, 0, Math.PI * 2)
      ctx.fill()
      
      // Evil eyebrows
      ctx.strokeStyle = "#7F1D1D"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(-18, -18)
      ctx.lineTo(-5, -14)
      ctx.stroke()
      ctx.beginPath()
      ctx.moveTo(18, -18)
      ctx.lineTo(5, -14)
      ctx.stroke()
      
      // Mouth
      ctx.fillStyle = "#7F1D1D"
      ctx.beginPath()
      ctx.arc(0, 12, 12, 0.2, Math.PI - 0.2)
      ctx.fill()
      
      // Teeth
      ctx.fillStyle = "#fff"
      for (let i = 0; i < 4; i++) {
        ctx.beginPath()
        ctx.moveTo(-9 + i * 6, 12)
        ctx.lineTo(-6 + i * 6, 18)
        ctx.lineTo(-3 + i * 6, 12)
        ctx.fill()
      }
      
      ctx.restore()
    }

    const drawPipe = (x: number, gapY: number) => {
      const pipeColor1 = "#166534"
      const pipeColor2 = "#15803d"
      const pipeColor3 = "#22c55e"
      const capColor = "#14532d"
      
      // Top pipe
      const topPipeHeight = gapY - PIPE_GAP / 2
      
      // Pipe body gradient
      const topGradient = ctx.createLinearGradient(x, 0, x + PIPE_WIDTH, 0)
      topGradient.addColorStop(0, pipeColor1)
      topGradient.addColorStop(0.3, pipeColor3)
      topGradient.addColorStop(0.7, pipeColor2)
      topGradient.addColorStop(1, pipeColor1)
      
      ctx.fillStyle = topGradient
      ctx.fillRect(x, 0, PIPE_WIDTH, topPipeHeight)
      
      // Top pipe cap
      ctx.fillStyle = capColor
      ctx.fillRect(x - 5, topPipeHeight - 30, PIPE_WIDTH + 10, 30)
      
      // Cap gradient overlay
      const capGradient = ctx.createLinearGradient(x - 5, 0, x + PIPE_WIDTH + 5, 0)
      capGradient.addColorStop(0, "rgba(0,0,0,0.3)")
      capGradient.addColorStop(0.3, "rgba(255,255,255,0.1)")
      capGradient.addColorStop(0.7, "rgba(0,0,0,0.1)")
      capGradient.addColorStop(1, "rgba(0,0,0,0.3)")
      ctx.fillStyle = capGradient
      ctx.fillRect(x - 5, topPipeHeight - 30, PIPE_WIDTH + 10, 30)
      
      // Pipe shine
      ctx.fillStyle = "rgba(255, 255, 255, 0.2)"
      ctx.fillRect(x + 10, 0, 8, topPipeHeight - 30)
      
      // Bottom pipe
      const bottomPipeY = gapY + PIPE_GAP / 2
      const bottomPipeHeight = canvas.height - 80 - bottomPipeY
      
      ctx.fillStyle = topGradient
      ctx.fillRect(x, bottomPipeY, PIPE_WIDTH, bottomPipeHeight)
      
      // Bottom pipe cap
      ctx.fillStyle = capColor
      ctx.fillRect(x - 5, bottomPipeY, PIPE_WIDTH + 10, 30)
      ctx.fillStyle = capGradient
      ctx.fillRect(x - 5, bottomPipeY, PIPE_WIDTH + 10, 30)
      
      // Pipe shine
      ctx.fillStyle = "rgba(255, 255, 255, 0.2)"
      ctx.fillRect(x + 10, bottomPipeY + 30, 8, bottomPipeHeight - 30)
      
      // Decorative rings on pipes
      ctx.strokeStyle = pipeColor1
      ctx.lineWidth = 3
      for (let ring = 0; ring < 3; ring++) {
        if (topPipeHeight - 60 - ring * 40 > 0) {
          ctx.beginPath()
          ctx.moveTo(x, topPipeHeight - 60 - ring * 40)
          ctx.lineTo(x + PIPE_WIDTH, topPipeHeight - 60 - ring * 40)
          ctx.stroke()
        }
        if (bottomPipeY + 60 + ring * 40 < canvas.height - 80) {
          ctx.beginPath()
          ctx.moveTo(x, bottomPipeY + 60 + ring * 40)
          ctx.lineTo(x + PIPE_WIDTH, bottomPipeY + 60 + ring * 40)
          ctx.stroke()
        }
      }
    }

    const drawUI = () => {
      // Timer
      const minutes = Math.floor(gameRef.current.timeLeft / 60)
      const seconds = Math.floor(gameRef.current.timeLeft % 60)
      const timeString = `${minutes}:${seconds.toString().padStart(2, '0')}`
      
      ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
      ctx.fillRect(canvas.width / 2 - 60, 10, 120, 50)
      ctx.strokeStyle = "#7c3aed"
      ctx.lineWidth = 2
      ctx.strokeRect(canvas.width / 2 - 60, 10, 120, 50)
      
      ctx.fillStyle = gameRef.current.timeLeft <= 30 ? "#EF4444" : "#fff"
      ctx.font = "bold 28px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(timeString, canvas.width / 2, 45)
      
      // Score
      ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
      ctx.fillRect(20, 10, 100, 50)
      ctx.strokeStyle = "#7c3aed"
      ctx.strokeRect(20, 10, 100, 50)
      
      ctx.fillStyle = "#FBBF24"
      ctx.font = "bold 32px sans-serif"
      ctx.textAlign = "left"
      ctx.fillText(gameRef.current.score.toString(), 40, 48)
      
      // Controls hint
      ctx.fillStyle = "rgba(255, 255, 255, 0.6)"
      ctx.font = "14px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText("SPACE / TAP to fly", canvas.width / 2, canvas.height - 90)
    }

    const checkCollision = () => {
      const game = gameRef.current
      const virusRadius = 30
      
      // Ground collision
      if (game.virusY + virusRadius > canvas.height - 80) {
        return true
      }
      
      // Ceiling collision
      if (game.virusY - virusRadius < 0) {
        return true
      }
      
      // Pipe collision
      for (const pipe of game.pipes) {
        const pipeLeft = pipe.x
        const pipeRight = pipe.x + PIPE_WIDTH
        
        if (game.virusX + virusRadius > pipeLeft && game.virusX - virusRadius < pipeRight) {
          const topPipeBottom = pipe.gapY - PIPE_GAP / 2
          const bottomPipeTop = pipe.gapY + PIPE_GAP / 2
          
          if (game.virusY - virusRadius < topPipeBottom || game.virusY + virusRadius > bottomPipeTop) {
            return true
          }
        }
      }
      
      return false
    }

    const gameLoop = () => {
      const game = gameRef.current
      
      // Update timer
      const now = Date.now()
      const deltaTime = (now - game.lastTime) / 1000
      game.lastTime = now
      game.timeLeft -= deltaTime
      game.frameCount++
      game.spikeRotation += 0.03
      setTimeLeft(Math.max(0, game.timeLeft))
      
      // Time's up
      if (game.timeLeft <= 0) {
        saveToLeaderboard(game.score)
        setGameState("gameover")
        if (game.score > highScore) {
          setHighScore(game.score)
        }
        return
      }
      
      // Physics
      game.velocityY += GRAVITY
      game.virusY += game.velocityY
      
      // Rotation based on velocity
      game.rotation = Math.min(Math.max(game.velocityY * 0.05, -0.5), 0.5)
      
      // Generate pipes
      if (game.pipes.length === 0 || game.pipes[game.pipes.length - 1].x < canvas.width - 300) {
        const minGap = 150
        const maxGap = canvas.height - 80 - 150
        const gapY = minGap + Math.random() * (maxGap - minGap)
        game.pipes.push({ x: canvas.width, gapY, passed: false })
      }
      
      // Update pipes
      for (let i = game.pipes.length - 1; i >= 0; i--) {
        game.pipes[i].x -= PIPE_SPEED
        
        // Score when passing pipe
        if (!game.pipes[i].passed && game.pipes[i].x + PIPE_WIDTH < game.virusX) {
          game.pipes[i].passed = true
          game.score++
          setScore(game.score)
        }
        
        // Remove off-screen pipes
        if (game.pipes[i].x < -PIPE_WIDTH) {
          game.pipes.splice(i, 1)
        }
      }
      
      // Check collision
      if (checkCollision()) {
        saveToLeaderboard(game.score)
        setGameState("gameover")
        if (game.score > highScore) {
          setHighScore(game.score)
        }
        return
      }
      
      // Draw
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      drawBackground()
      
      for (const pipe of game.pipes) {
        drawPipe(pipe.x, pipe.gapY)
      }
      
      drawVirus(game.virusX, game.virusY, game.rotation)
      drawUI()
      
      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener("keydown", handleKeyDown)
      canvas.removeEventListener("click", handleClick)
      canvas.removeEventListener("touchstart", handleClick)
    }
  }, [gameState, highScore, saveToLeaderboard])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div className="min-h-screen gradient-bg-animated wave-lines flex flex-col">
      <header className="glass border-b border-purple-500/20 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="text-purple-300 hover:text-white hover:bg-purple-500/20">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Назад
            </Button>
          </Link>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">
            Flappy Virus
          </h1>
          <div className="flex items-center gap-4 text-purple-300">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-cyan-400" />
              <span className={`font-bold ${timeLeft <= 30 ? 'text-red-400' : ''}`}>{formatTime(timeLeft)}</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span className="font-bold">{score}</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 flex items-center justify-center p-4">
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={800}
            height={600}
            className="rounded-2xl border-4 border-purple-500/30 shadow-2xl cursor-pointer"
          />
          
          {gameState === "menu" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center glass rounded-2xl">
              <div className="mb-8">
                <svg width="120" height="120" viewBox="-60 -60 120 120">
                  <defs>
                    <radialGradient id="virusGrad" cx="30%" cy="30%">
                      <stop offset="0%" stopColor="#F87171" />
                      <stop offset="50%" stopColor="#EF4444" />
                      <stop offset="100%" stopColor="#DC2626" />
                    </radialGradient>
                  </defs>
                  <circle cx="0" cy="0" r="35" fill="url(#virusGrad)" />
                  {[0, 1, 2, 3, 4, 5, 6, 7].map(i => {
                    const angle = (i * Math.PI * 2) / 8
                    return (
                      <g key={i}>
                        <line
                          x1={Math.cos(angle) * 30}
                          y1={Math.sin(angle) * 30}
                          x2={Math.cos(angle) * 50}
                          y2={Math.sin(angle) * 50}
                          stroke="#DC2626"
                          strokeWidth="6"
                        />
                        <circle
                          cx={Math.cos(angle) * 50}
                          cy={Math.sin(angle) * 50}
                          r="8"
                          fill="#B91C1C"
                        />
                      </g>
                    )
                  })}
                  <ellipse cx="-10" cy="-5" rx="10" ry="12" fill="white" />
                  <ellipse cx="10" cy="-5" rx="10" ry="12" fill="white" />
                  <circle cx="-10" cy="-3" r="5" fill="#1F2937" />
                  <circle cx="10" cy="-3" r="5" fill="#1F2937" />
                </svg>
              </div>
              <h2 className="text-4xl font-bold text-white mb-4">Flappy Virus</h2>
              <p className="text-purple-300 mb-4 text-center max-w-md">
                Управляй летающим вирусом! Пролетай между трубами и набирай очки.
              </p>
              <p className="text-cyan-400 mb-8 text-center">
                <Clock className="w-5 h-5 inline-block mr-2" />
                Время: 2 минуты
              </p>
              <Button
                onClick={startGame}
                className="px-12 py-6 text-xl bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 rounded-xl"
              >
                <Play className="w-8 h-8 mr-3" />
                Играть
              </Button>
              <p className="text-purple-400/60 mt-6 text-sm">
                SPACE / TAP / Клик чтобы лететь вверх
              </p>
            </div>
          )}

          {gameState === "gameover" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center glass rounded-2xl">
              <h2 className="text-4xl font-bold text-cyan-400 mb-4">
                {timeLeft <= 0 ? "Время вышло!" : "Игра окончена!"}
              </h2>
              <div className="text-center mb-8">
                <p className="text-2xl text-white mb-2">Очки: <span className="text-cyan-400">{score}</span></p>
                <p className="text-lg text-purple-300">Труб пройдено: {score}</p>
                <p className="text-lg text-yellow-400">Рекорд: {highScore}</p>
                <p className="text-sm text-green-400 mt-2">Результат сохранен в рейтинг!</p>
              </div>
              <Button
                onClick={startGame}
                className="px-8 py-4 text-lg bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 rounded-xl"
              >
                <RotateCcw className="w-6 h-6 mr-2" />
                Играть снова
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
