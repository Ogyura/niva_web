"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  color: string
}

export default function VirusPongGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover">("menu")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120)
  const [playerScore, setPlayerScore] = useState(0)
  const [aiScore, setAiScore] = useState(0)

  const gameRef = useRef({
    playerY: 250,
    aiY: 250,
    ballX: 400,
    ballY: 300,
    ballVX: 5,
    ballVY: 3,
    ballRadius: 15,
    paddleHeight: 100,
    paddleWidth: 15,
    particles: [] as Particle[],
    virusAngle: 0,
    virusPulse: 0,
    score: 0,
    playerScore: 0,
    aiScore: 0,
    stars: [] as { x: number; y: number; size: number; brightness: number }[],
    trail: [] as { x: number; y: number; age: number }[],
  })

  const saveScore = useCallback((finalScore: number) => {
    const username = localStorage.getItem("ddosGuardUser") || "Anonymous"
    const leaderboard = JSON.parse(localStorage.getItem("ddosGuardLeaderboard") || "[]")
    leaderboard.push({
      username,
      score: finalScore,
      game: "Virus Pong",
      date: new Date().toISOString(),
    })
    leaderboard.sort((a: any, b: any) => b.score - a.score)
    localStorage.setItem("ddosGuardLeaderboard", JSON.stringify(leaderboard.slice(0, 100)))
    
    if (finalScore > highScore) {
      setHighScore(finalScore)
      localStorage.setItem("virusPongHighScore", finalScore.toString())
    }
  }, [highScore])

  const startGame = useCallback(() => {
    const game = gameRef.current
    game.playerY = 250
    game.aiY = 250
    game.ballX = 400
    game.ballY = 300
    game.ballVX = 5
    game.ballVY = 3
    game.particles = []
    game.score = 0
    game.playerScore = 0
    game.aiScore = 0
    game.trail = []

    game.stars = []
    for (let i = 0; i < 100; i++) {
      game.stars.push({
        x: Math.random() * 800,
        y: Math.random() * 600,
        size: Math.random() * 2 + 0.5,
        brightness: Math.random(),
      })
    }

    setScore(0)
    setPlayerScore(0)
    setAiScore(0)
    setTimeLeft(120)
    setGameState("playing")
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem("virusPongHighScore")
    if (saved) setHighScore(parseInt(saved))
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const game = gameRef.current

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      game.playerY = Math.max(
        game.paddleHeight / 2,
        Math.min(600 - game.paddleHeight / 2, e.clientY - rect.top)
      )
    }

    canvas.addEventListener("mousemove", handleMouseMove)

    const timerInterval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameState("gameover")
          saveScore(game.score)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    const drawBackground = () => {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 600)
      skyGrad.addColorStop(0, "#1e1b4b")
      skyGrad.addColorStop(0.3, "#312e81")
      skyGrad.addColorStop(0.6, "#6366f1")
      skyGrad.addColorStop(0.85, "#f97316")
      skyGrad.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGrad
      ctx.fillRect(0, 0, 800, 600)

      game.stars.forEach((star) => {
        const brightness = 0.5 + Math.sin(Date.now() / 1000 + star.x) * 0.5
        ctx.fillStyle = `rgba(255, 255, 255, ${brightness * star.brightness})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()
      })

      // Center line
      ctx.setLineDash([10, 10])
      ctx.strokeStyle = "rgba(255, 255, 255, 0.3)"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(400, 0)
      ctx.lineTo(400, 600)
      ctx.stroke()
      ctx.setLineDash([])
    }

    const drawPaddle = (x: number, y: number, isPlayer: boolean) => {
      const gradient = ctx.createLinearGradient(x - 10, 0, x + 10, 0)
      if (isPlayer) {
        gradient.addColorStop(0, "#3b82f6")
        gradient.addColorStop(0.5, "#60a5fa")
        gradient.addColorStop(1, "#3b82f6")
      } else {
        gradient.addColorStop(0, "#ef4444")
        gradient.addColorStop(0.5, "#f87171")
        gradient.addColorStop(1, "#ef4444")
      }

      ctx.shadowColor = isPlayer ? "#3b82f6" : "#ef4444"
      ctx.shadowBlur = 15

      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.roundRect(
        x - game.paddleWidth / 2,
        y - game.paddleHeight / 2,
        game.paddleWidth,
        game.paddleHeight,
        8
      )
      ctx.fill()

      // Glow edge
      ctx.strokeStyle = isPlayer ? "#93c5fd" : "#fca5a5"
      ctx.lineWidth = 2
      ctx.stroke()

      ctx.shadowBlur = 0
    }

    const drawVirusBall = () => {
      game.virusAngle += 0.05
      game.virusPulse += 0.15

      // Trail
      game.trail.unshift({ x: game.ballX, y: game.ballY, age: 0 })
      game.trail = game.trail.filter((t) => {
        t.age++
        return t.age < 15
      })

      game.trail.forEach((t, i) => {
        const alpha = 1 - t.age / 15
        ctx.fillStyle = `rgba(34, 197, 94, ${alpha * 0.5})`
        ctx.beginPath()
        ctx.arc(t.x, t.y, game.ballRadius * (1 - t.age / 20), 0, Math.PI * 2)
        ctx.fill()
      })

      ctx.save()
      ctx.translate(game.ballX, game.ballY)
      ctx.rotate(game.virusAngle)

      // Glow
      ctx.shadowColor = "#22c55e"
      ctx.shadowBlur = 20

      // Spikes
      const spikeCount = 10
      for (let i = 0; i < spikeCount; i++) {
        const angle = (i / spikeCount) * Math.PI * 2
        const spikeLen = game.ballRadius * 0.6 + Math.sin(game.virusPulse + i) * 3
        ctx.save()
        ctx.rotate(angle)
        ctx.fillStyle = "#22c55e"
        ctx.beginPath()
        ctx.moveTo(game.ballRadius * 0.6, -3)
        ctx.lineTo(game.ballRadius + spikeLen, 0)
        ctx.lineTo(game.ballRadius * 0.6, 3)
        ctx.closePath()
        ctx.fill()
        ctx.beginPath()
        ctx.arc(game.ballRadius + spikeLen, 0, 4, 0, Math.PI * 2)
        ctx.fillStyle = "#4ade80"
        ctx.fill()
        ctx.restore()
      }

      // Body
      const bodyGrad = ctx.createRadialGradient(-3, -3, 0, 0, 0, game.ballRadius)
      bodyGrad.addColorStop(0, "#4ade80")
      bodyGrad.addColorStop(0.5, "#22c55e")
      bodyGrad.addColorStop(1, "#166534")
      ctx.fillStyle = bodyGrad
      ctx.beginPath()
      ctx.arc(0, 0, game.ballRadius * 0.7, 0, Math.PI * 2)
      ctx.fill()

      // Eyes
      ctx.fillStyle = "#000"
      ctx.beginPath()
      ctx.ellipse(-5, -3, 4, 5, 0, 0, Math.PI * 2)
      ctx.ellipse(5, -3, 4, 5, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = "#ff0000"
      ctx.beginPath()
      ctx.arc(-5, -3, 2, 0, Math.PI * 2)
      ctx.arc(5, -3, 2, 0, Math.PI * 2)
      ctx.fill()

      ctx.shadowBlur = 0
      ctx.restore()
    }

    let animationId: number
    const gameLoop = () => {
      // AI movement
      const aiTarget = game.ballY
      const aiSpeed = 4
      if (game.aiY < aiTarget - 10) game.aiY += aiSpeed
      else if (game.aiY > aiTarget + 10) game.aiY -= aiSpeed

      // Ball movement
      game.ballX += game.ballVX
      game.ballY += game.ballVY

      // Top/bottom bounce
      if (game.ballY <= game.ballRadius || game.ballY >= 600 - game.ballRadius) {
        game.ballVY = -game.ballVY
        game.ballY = Math.max(game.ballRadius, Math.min(600 - game.ballRadius, game.ballY))
      }

      // Paddle collision - Player
      if (
        game.ballX - game.ballRadius <= 40 &&
        game.ballX > 20 &&
        game.ballY >= game.playerY - game.paddleHeight / 2 - 10 &&
        game.ballY <= game.playerY + game.paddleHeight / 2 + 10
      ) {
        game.ballVX = Math.abs(game.ballVX) * 1.05
        game.ballVY += (game.ballY - game.playerY) * 0.1
        game.score += 10
        setScore(game.score)

        for (let i = 0; i < 8; i++) {
          game.particles.push({
            x: game.ballX,
            y: game.ballY,
            vx: Math.random() * 5 + 2,
            vy: (Math.random() - 0.5) * 8,
            life: 1,
            color: "#3b82f6",
          })
        }
      }

      // Paddle collision - AI
      if (
        game.ballX + game.ballRadius >= 760 &&
        game.ballX < 780 &&
        game.ballY >= game.aiY - game.paddleHeight / 2 - 10 &&
        game.ballY <= game.aiY + game.paddleHeight / 2 + 10
      ) {
        game.ballVX = -Math.abs(game.ballVX) * 1.05
        game.ballVY += (game.ballY - game.aiY) * 0.1

        for (let i = 0; i < 8; i++) {
          game.particles.push({
            x: game.ballX,
            y: game.ballY,
            vx: -Math.random() * 5 - 2,
            vy: (Math.random() - 0.5) * 8,
            life: 1,
            color: "#ef4444",
          })
        }
      }

      // Scoring
      if (game.ballX < 0) {
        game.aiScore++
        setAiScore(game.aiScore)
        game.ballX = 400
        game.ballY = 300
        game.ballVX = -5
        game.ballVY = (Math.random() - 0.5) * 6
      }

      if (game.ballX > 800) {
        game.playerScore++
        game.score += 100
        setPlayerScore(game.playerScore)
        setScore(game.score)
        game.ballX = 400
        game.ballY = 300
        game.ballVX = 5
        game.ballVY = (Math.random() - 0.5) * 6
      }

      // Speed cap
      game.ballVX = Math.sign(game.ballVX) * Math.min(Math.abs(game.ballVX), 15)
      game.ballVY = Math.sign(game.ballVY) * Math.min(Math.abs(game.ballVY), 10)

      // Render
      ctx.clearRect(0, 0, 800, 600)
      drawBackground()

      // Particles
      game.particles = game.particles.filter((p) => {
        p.x += p.vx
        p.y += p.vy
        p.life -= 0.03

        ctx.globalAlpha = p.life
        ctx.fillStyle = p.color
        ctx.beginPath()
        ctx.arc(p.x, p.y, 4 * p.life, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = 1

        return p.life > 0
      })

      drawPaddle(30, game.playerY, true)
      drawPaddle(770, game.aiY, false)
      drawVirusBall()

      // Scores
      ctx.fillStyle = "#fff"
      ctx.font = "bold 48px Arial"
      ctx.textAlign = "center"
      ctx.fillText(game.playerScore.toString(), 200, 80)
      ctx.fillText(game.aiScore.toString(), 600, 80)

      ctx.font = "20px Arial"
      ctx.fillStyle = "#93c5fd"
      ctx.fillText("YOU", 200, 110)
      ctx.fillStyle = "#fca5a5"
      ctx.fillText("AI", 600, 110)

      // Timer
      const minutes = Math.floor(timeLeft / 60)
      const seconds = timeLeft % 60
      ctx.font = "bold 24px Arial"
      ctx.fillStyle = timeLeft < 30 ? "#ef4444" : "#fff"
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, "0")}`, 400, 40)

      // Total score
      ctx.font = "16px Arial"
      ctx.fillStyle = "#fbbf24"
      ctx.fillText(`Score: ${game.score}`, 400, 580)

      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      cancelAnimationFrame(animationId)
      clearInterval(timerInterval)
      canvas.removeEventListener("mousemove", handleMouseMove)
    }
  }, [gameState, timeLeft, saveScore])

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      <div className="mb-4 flex items-center gap-4">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Virus Pong</h1>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          className="border-4 border-green-500 rounded-lg shadow-2xl cursor-none"
        />

        {gameState === "menu" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-white mb-4">Virus Pong</h2>
            <p className="text-gray-300 mb-2">Move your mouse to control the paddle</p>
            <p className="text-gray-400 mb-4 text-sm">Defend against the virus ball!</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-green-600 hover:bg-green-700">
              Start Game
            </Button>
          </div>
        )}

        {gameState === "gameover" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-amber-500 mb-4">Time's Up!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-xl text-gray-300 mb-2">
              You {playerScore} - {aiScore} AI
            </p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-green-600 hover:bg-green-700">
              Play Again
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
