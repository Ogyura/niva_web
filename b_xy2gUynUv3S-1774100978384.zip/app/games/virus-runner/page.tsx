"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Obstacle {
  x: number
  y: number
  width: number
  height: number
  type: 'virus' | 'spike' | 'flying'
  virusType: number
  pulse: number
}

interface Coin {
  x: number
  y: number
  collected: boolean
  pulse: number
}

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  color: string
}

export default function VirusRunnerGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover">("menu")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120)
  const [distance, setDistance] = useState(0)

  const gameRef = useRef({
    playerX: 100,
    playerY: 400,
    playerVY: 0,
    isJumping: false,
    isDucking: false,
    obstacles: [] as Obstacle[],
    coins: [] as Coin[],
    particles: [] as Particle[],
    score: 0,
    distance: 0,
    speed: 6,
    groundY: 450,
    lastObstacle: 0,
    lastCoin: 0,
    runFrame: 0,
    stars: [] as { x: number; y: number; size: number; brightness: number }[],
    hills: [] as { x: number; height: number; width: number }[],
  })

  const saveScore = useCallback((finalScore: number) => {
    const username = localStorage.getItem("ddosGuardUser") || "Anonymous"
    const leaderboard = JSON.parse(localStorage.getItem("ddosGuardLeaderboard") || "[]")
    leaderboard.push({
      username,
      score: finalScore,
      game: "Virus Runner",
      date: new Date().toISOString(),
    })
    leaderboard.sort((a: any, b: any) => b.score - a.score)
    localStorage.setItem("ddosGuardLeaderboard", JSON.stringify(leaderboard.slice(0, 100)))
    
    if (finalScore > highScore) {
      setHighScore(finalScore)
      localStorage.setItem("virusRunnerHighScore", finalScore.toString())
    }
  }, [highScore])

  const startGame = useCallback(() => {
    const game = gameRef.current
    game.playerY = 400
    game.playerVY = 0
    game.isJumping = false
    game.isDucking = false
    game.obstacles = []
    game.coins = []
    game.particles = []
    game.score = 0
    game.distance = 0
    game.speed = 6
    game.lastObstacle = 0
    game.lastCoin = 0

    game.stars = []
    for (let i = 0; i < 100; i++) {
      game.stars.push({
        x: Math.random() * 800,
        y: Math.random() * 300,
        size: Math.random() * 2 + 0.5,
        brightness: Math.random(),
      })
    }

    game.hills = []
    for (let i = 0; i < 8; i++) {
      game.hills.push({
        x: i * 150,
        height: 50 + Math.random() * 80,
        width: 120 + Math.random() * 60,
      })
    }

    setScore(0)
    setDistance(0)
    setTimeLeft(120)
    setGameState("playing")
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem("virusRunnerHighScore")
    if (saved) setHighScore(parseInt(saved))
  }, [])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const game = gameRef.current

    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.code === "Space" || e.code === "ArrowUp" || e.key === "w" || e.key === "W") && !game.isJumping) {
        game.isJumping = true
        game.playerVY = -15
      }
      if (e.code === "ArrowDown" || e.key === "s" || e.key === "S") {
        game.isDucking = true
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === "ArrowDown" || e.key === "s" || e.key === "S") {
        game.isDucking = false
      }
    }

    const handleTouch = () => {
      if (!game.isJumping) {
        game.isJumping = true
        game.playerVY = -15
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)
    canvas.addEventListener("touchstart", handleTouch)
    canvas.addEventListener("click", handleTouch)

    const timerInterval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setGameState("gameover")
          saveScore(game.score)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    const drawBackground = () => {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 600)
      skyGrad.addColorStop(0, "#1e1b4b")
      skyGrad.addColorStop(0.3, "#312e81")
      skyGrad.addColorStop(0.5, "#6366f1")
      skyGrad.addColorStop(0.7, "#f97316")
      skyGrad.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGrad
      ctx.fillRect(0, 0, 800, 600)

      // Stars
      game.stars.forEach((star) => {
        const brightness = 0.5 + Math.sin(Date.now() / 1000 + star.x) * 0.5
        ctx.fillStyle = `rgba(255, 255, 255, ${brightness * star.brightness})`
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fill()
      })

      // Hills
      ctx.fillStyle = "#312e8180"
      game.hills.forEach((hill) => {
        ctx.beginPath()
        ctx.moveTo(hill.x, game.groundY)
        ctx.quadraticCurveTo(
          hill.x + hill.width / 2,
          game.groundY - hill.height,
          hill.x + hill.width,
          game.groundY
        )
        ctx.fill()
      })

      // Ground
      const groundGrad = ctx.createLinearGradient(0, game.groundY, 0, 600)
      groundGrad.addColorStop(0, "#1e293b")
      groundGrad.addColorStop(1, "#0f172a")
      ctx.fillStyle = groundGrad
      ctx.fillRect(0, game.groundY, 800, 150)

      // Ground line
      ctx.strokeStyle = "#475569"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(0, game.groundY)
      ctx.lineTo(800, game.groundY)
      ctx.stroke()
    }

    const drawPlayer = () => {
      const x = game.playerX
      const y = game.playerY
      const height = game.isDucking ? 30 : 50
      game.runFrame += 0.2

      ctx.save()
      ctx.translate(x, y)

      // Shadow
      ctx.fillStyle = "rgba(0,0,0,0.3)"
      ctx.beginPath()
      ctx.ellipse(0, game.groundY - y + 5, 20, 8, 0, 0, Math.PI * 2)
      ctx.fill()

      // Body
      ctx.shadowColor = "#3b82f6"
      ctx.shadowBlur = 15

      const bodyGrad = ctx.createLinearGradient(-15, -height, 15, 0)
      bodyGrad.addColorStop(0, "#60a5fa")
      bodyGrad.addColorStop(0.5, "#3b82f6")
      bodyGrad.addColorStop(1, "#1d4ed8")
      ctx.fillStyle = bodyGrad

      // Robot body
      ctx.beginPath()
      ctx.roundRect(-15, -height, 30, height - 10, 8)
      ctx.fill()

      // Head
      ctx.fillStyle = "#93c5fd"
      ctx.beginPath()
      ctx.roundRect(-12, -height - 15, 24, 18, 6)
      ctx.fill()

      // Eyes
      ctx.fillStyle = "#fff"
      ctx.beginPath()
      ctx.arc(-5, -height - 8, 4, 0, Math.PI * 2)
      ctx.arc(5, -height - 8, 4, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = "#000"
      ctx.beginPath()
      ctx.arc(-4, -height - 8, 2, 0, Math.PI * 2)
      ctx.arc(6, -height - 8, 2, 0, Math.PI * 2)
      ctx.fill()

      // Antenna
      ctx.strokeStyle = "#60a5fa"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(0, -height - 15)
      ctx.lineTo(0, -height - 25)
      ctx.stroke()
      ctx.fillStyle = "#22d3ee"
      ctx.beginPath()
      ctx.arc(0, -height - 27, 4, 0, Math.PI * 2)
      ctx.fill()

      // Legs (animated)
      ctx.shadowBlur = 0
      if (!game.isJumping && !game.isDucking) {
        const legOffset = Math.sin(game.runFrame) * 8
        ctx.fillStyle = "#1d4ed8"
        ctx.fillRect(-10, -10, 8, 12 + legOffset)
        ctx.fillRect(2, -10, 8, 12 - legOffset)
      }

      // Jetpack flames when jumping
      if (game.isJumping) {
        ctx.fillStyle = "#f97316"
        const flameHeight = 10 + Math.random() * 10
        ctx.beginPath()
        ctx.moveTo(-8, 0)
        ctx.lineTo(-4, flameHeight)
        ctx.lineTo(0, 0)
        ctx.fill()
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.lineTo(4, flameHeight)
        ctx.lineTo(8, 0)
        ctx.fill()
      }

      ctx.restore()
    }

    const drawVirus = (obs: Obstacle) => {
      obs.pulse += 0.1
      const colors = [
        { main: "#22c55e", glow: "#4ade80" },
        { main: "#ef4444", glow: "#f87171" },
        { main: "#a855f7", glow: "#c084fc" },
      ]
      const color = colors[obs.virusType]
      const radius = obs.width / 2

      ctx.save()
      ctx.translate(obs.x + radius, obs.y + radius)
      ctx.rotate(obs.pulse * 0.5)

      ctx.shadowColor = color.glow
      ctx.shadowBlur = 15

      // Spikes
      const spikeCount = 10
      for (let i = 0; i < spikeCount; i++) {
        const angle = (i / spikeCount) * Math.PI * 2
        const spikeLen = radius * 0.5 + Math.sin(obs.pulse + i) * 3
        ctx.save()
        ctx.rotate(angle)
        ctx.fillStyle = color.main
        ctx.beginPath()
        ctx.moveTo(radius * 0.6, -3)
        ctx.lineTo(radius + spikeLen, 0)
        ctx.lineTo(radius * 0.6, 3)
        ctx.closePath()
        ctx.fill()
        ctx.beginPath()
        ctx.arc(radius + spikeLen, 0, 4, 0, Math.PI * 2)
        ctx.fillStyle = color.glow
        ctx.fill()
        ctx.restore()
      }

      // Body
      const bodyGrad = ctx.createRadialGradient(-3, -3, 0, 0, 0, radius * 0.7)
      bodyGrad.addColorStop(0, color.glow)
      bodyGrad.addColorStop(1, color.main)
      ctx.fillStyle = bodyGrad
      ctx.beginPath()
      ctx.arc(0, 0, radius * 0.6, 0, Math.PI * 2)
      ctx.fill()

      // Eyes
      ctx.fillStyle = "#000"
      ctx.beginPath()
      ctx.ellipse(-6, -3, 5, 6, 0, 0, Math.PI * 2)
      ctx.ellipse(6, -3, 5, 6, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = "#ff0000"
      ctx.beginPath()
      ctx.arc(-6, -3, 2.5, 0, Math.PI * 2)
      ctx.arc(6, -3, 2.5, 0, Math.PI * 2)
      ctx.fill()

      ctx.shadowBlur = 0
      ctx.restore()
    }

    const drawCoin = (coin: Coin) => {
      if (coin.collected) return
      coin.pulse += 0.1

      ctx.save()
      ctx.translate(coin.x, coin.y)

      ctx.shadowColor = "#fbbf24"
      ctx.shadowBlur = 10

      const scale = 1 + Math.sin(coin.pulse) * 0.1
      ctx.scale(scale, scale)

      ctx.fillStyle = "#fbbf24"
      ctx.beginPath()
      ctx.arc(0, 0, 12, 0, Math.PI * 2)
      ctx.fill()

      ctx.fillStyle = "#f59e0b"
      ctx.beginPath()
      ctx.arc(0, 0, 8, 0, Math.PI * 2)
      ctx.fill()

      ctx.fillStyle = "#fbbf24"
      ctx.font = "bold 12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("$", 0, 0)

      ctx.shadowBlur = 0
      ctx.restore()
    }

    let animationId: number
    const gameLoop = () => {
      // Physics
      game.playerVY += 0.8 // Gravity
      game.playerY += game.playerVY

      if (game.playerY >= game.groundY - (game.isDucking ? 30 : 50)) {
        game.playerY = game.groundY - (game.isDucking ? 30 : 50)
        game.playerVY = 0
        game.isJumping = false
      }

      // Speed increases over time
      game.speed = 6 + game.distance / 2000
      game.distance += game.speed
      setDistance(Math.floor(game.distance))

      // Move hills
      game.hills.forEach((hill) => {
        hill.x -= game.speed * 0.3
        if (hill.x + hill.width < 0) {
          hill.x = 800 + Math.random() * 100
          hill.height = 50 + Math.random() * 80
          hill.width = 120 + Math.random() * 60
        }
      })

      // Spawn obstacles
      if (game.distance - game.lastObstacle > 300 + Math.random() * 200) {
        game.lastObstacle = game.distance
        const types: ('virus' | 'flying')[] = ['virus', 'virus', 'flying']
        const type = types[Math.floor(Math.random() * types.length)]
        const size = 40 + Math.random() * 20

        game.obstacles.push({
          x: 850,
          y: type === 'flying' ? game.groundY - 100 - Math.random() * 50 : game.groundY - size,
          width: size,
          height: size,
          type,
          virusType: Math.floor(Math.random() * 3),
          pulse: Math.random() * Math.PI * 2,
        })
      }

      // Spawn coins
      if (game.distance - game.lastCoin > 150 + Math.random() * 100) {
        game.lastCoin = game.distance
        game.coins.push({
          x: 850,
          y: game.groundY - 80 - Math.random() * 100,
          collected: false,
          pulse: 0,
        })
      }

      // Update obstacles
      game.obstacles = game.obstacles.filter((obs) => {
        obs.x -= game.speed

        // Collision detection
        const playerLeft = game.playerX - 15
        const playerRight = game.playerX + 15
        const playerTop = game.playerY - (game.isDucking ? 30 : 50)
        const playerBottom = game.playerY

        const obsLeft = obs.x
        const obsRight = obs.x + obs.width
        const obsTop = obs.y
        const obsBottom = obs.y + obs.height

        if (
          playerRight > obsLeft + 10 &&
          playerLeft < obsRight - 10 &&
          playerBottom > obsTop + 10 &&
          playerTop < obsBottom - 10
        ) {
          setGameState("gameover")
          saveScore(game.score)
        }

        return obs.x > -100
      })

      // Update coins
      game.coins = game.coins.filter((coin) => {
        coin.x -= game.speed

        // Collection
        if (!coin.collected) {
          const dx = coin.x - game.playerX
          const dy = coin.y - (game.playerY - 25)
          if (Math.sqrt(dx * dx + dy * dy) < 30) {
            coin.collected = true
            game.score += 50
            setScore(game.score)

            for (let i = 0; i < 8; i++) {
              game.particles.push({
                x: coin.x,
                y: coin.y,
                vx: (Math.random() - 0.5) * 6,
                vy: (Math.random() - 0.5) * 6,
                life: 1,
                color: "#fbbf24",
              })
            }
          }
        }

        return coin.x > -50 && !coin.collected
      })

      // Score from distance
      game.score = Math.floor(game.distance / 10) + game.coins.filter((c) => c.collected).length * 50
      setScore(game.score)

      // Render
      ctx.clearRect(0, 0, 800, 600)
      drawBackground()

      game.obstacles.forEach(drawVirus)
      game.coins.forEach(drawCoin)
      drawPlayer()

      // Particles
      game.particles = game.particles.filter((p) => {
        p.x += p.vx
        p.y += p.vy
        p.life -= 0.03

        ctx.globalAlpha = p.life
        ctx.fillStyle = p.color
        ctx.beginPath()
        ctx.arc(p.x, p.y, 4 * p.life, 0, Math.PI * 2)
        ctx.fill()
        ctx.globalAlpha = 1

        return p.life > 0
      })

      // UI
      ctx.fillStyle = "#fff"
      ctx.font = "bold 24px Arial"
      ctx.textAlign = "left"
      ctx.fillText(`Score: ${game.score}`, 20, 40)
      ctx.fillText(`Distance: ${Math.floor(game.distance)}m`, 20, 70)

      const minutes = Math.floor(timeLeft / 60)
      const seconds = timeLeft % 60
      ctx.textAlign = "right"
      ctx.fillStyle = timeLeft < 30 ? "#ef4444" : "#fff"
      ctx.fillText(`${minutes}:${seconds.toString().padStart(2, "0")}`, 780, 40)

      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      cancelAnimationFrame(animationId)
      clearInterval(timerInterval)
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
      canvas.removeEventListener("touchstart", handleTouch)
      canvas.removeEventListener("click", handleTouch)
    }
  }, [gameState, timeLeft, saveScore])

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      <div className="mb-4 flex items-center gap-4">
        <Link href="/">
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
        <h1 className="text-2xl font-bold text-white">Virus Runner</h1>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          className="border-4 border-orange-500 rounded-lg shadow-2xl"
        />

        {gameState === "menu" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-white mb-4">Virus Runner</h2>
            <p className="text-gray-300 mb-2">Press Space/Up or Tap to jump</p>
            <p className="text-gray-400 mb-4 text-sm">Avoid viruses and collect coins!</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-orange-600 hover:bg-orange-700">
              Start Game
            </Button>
          </div>
        )}

        {gameState === "gameover" && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-lg">
            <h2 className="text-4xl font-bold text-red-500 mb-4">Game Over!</h2>
            <p className="text-2xl text-white mb-2">Final Score: {score}</p>
            <p className="text-xl text-gray-300 mb-2">Distance: {distance}m</p>
            <p className="text-cyan-400 mb-6">High Score: {highScore}</p>
            <Button onClick={startGame} size="lg" className="bg-orange-600 hover:bg-orange-700">
              Play Again
            </Button>
          </div>
        )}
      </div>

      <p className="mt-4 text-gray-400 text-sm">Space/Up/Tap to Jump | Down to Duck</p>
    </div>
  )
}
