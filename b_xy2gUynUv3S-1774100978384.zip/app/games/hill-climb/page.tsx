"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import Link from "next/link"
import { ArrowLeft, Play, RotateCcw, Fuel, Zap, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Virus {
  x: number
  y: number
  collected: boolean
  type: number
  value: number
}

interface TerrainPoint {
  x: number
  y: number
}

const GAME_DURATION = 120 // 2 minutes in seconds

export default function HillClimbGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameover">("menu")
  const [score, setScore] = useState(0)
  const [distance, setDistance] = useState(0)
  const [fuel, setFuel] = useState(100)
  const [highScore, setHighScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(GAME_DURATION)
  
  const gameRef = useRef({
    carX: 200,
    carY: 300,
    carAngle: 0,
    velocityX: 0,
    velocityY: 0,
    angularVelocity: 0,
    wheelAngle: 0,
    cameraX: 0,
    terrain: [] as TerrainPoint[],
    viruses: [] as Virus[],
    fuel: 100,
    score: 0,
    distance: 0,
    gasPressed: false,
    brakePressed: false,
    crashed: false,
    rpm: 0,
    boost: 0,
    frontSuspension: 0,
    rearSuspension: 0,
    frontSuspensionVel: 0,
    rearSuspensionVel: 0,
    bodyAngleVel: 0,
    timeLeft: GAME_DURATION,
    lastTime: 0,
  })

  // Save score to leaderboard
  const saveToLeaderboard = useCallback((finalScore: number, finalDistance: number) => {
    const stored = localStorage.getItem("hillClimbLeaderboard")
    const leaderboard = stored ? JSON.parse(stored) : []
    const username = localStorage.getItem("ddosGuardUser") || "Player"
    
    leaderboard.push({
      username,
      score: finalScore,
      distance: `${finalDistance}m`,
      date: new Date().toISOString(),
      game: "hill-climb"
    })
    
    // Sort by score and keep top 20
    leaderboard.sort((a: { score: number }, b: { score: number }) => b.score - a.score)
    const top20 = leaderboard.slice(0, 20)
    
    localStorage.setItem("hillClimbLeaderboard", JSON.stringify(top20))
  }, [])

  const generateTerrain = useCallback(() => {
    const terrain: TerrainPoint[] = []
    const totalWidth = 50000
    const baseY = 350
    
    // Smooth terrain - removed sharp hills
    for (let x = -200; x < totalWidth; x += 15) {
      // Combine multiple sine waves for smooth rolling hills
      const wave1 = Math.sin(x * 0.002) * 50  // Large gentle hills
      const wave2 = Math.sin(x * 0.005) * 30  // Medium smooth hills
      const wave3 = Math.sin(x * 0.001) * 80  // Very large gradual changes
      const wave4 = Math.sin(x * 0.0008) * 40 // Extra smooth variation
      
      const y = baseY + wave1 + wave2 + wave3 + wave4
      
      terrain.push({ x, y: Math.max(200, Math.min(420, y)) })
    }
    
    return terrain
  }, [])

  const generateViruses = useCallback((terrain: TerrainPoint[]) => {
    const viruses: Virus[] = []
    
    for (let i = 0; i < terrain.length; i += 6) {
      if (Math.random() > 0.35 && terrain[i]) {
        const value = Math.random() > 0.7 ? 100 : Math.random() > 0.4 ? 25 : 5
        // Place viruses closer to the ground (25-45 units above terrain) so car can collect them
        viruses.push({
          x: terrain[i].x,
          y: terrain[i].y - 25 - Math.random() * 20,
          collected: false,
          type: Math.floor(Math.random() * 3),
          value,
        })
      }
    }
    
    return viruses
  }, [])

  const getTerrainYAtX = useCallback((x: number, terrain: TerrainPoint[]): number => {
    for (let i = 0; i < terrain.length - 1; i++) {
      if (terrain[i].x <= x && terrain[i + 1].x > x) {
        const t = (x - terrain[i].x) / (terrain[i + 1].x - terrain[i].x)
        return terrain[i].y + t * (terrain[i + 1].y - terrain[i].y)
      }
    }
    return 350
  }, [])

  const startGame = useCallback(() => {
    const terrain = generateTerrain()
    const viruses = generateViruses(terrain)
    
    gameRef.current = {
      carX: 200,
      carY: getTerrainYAtX(200, terrain) - 30,
      carAngle: 0,
      velocityX: 0,
      velocityY: 0,
      angularVelocity: 0,
      wheelAngle: 0,
      cameraX: 0,
      terrain,
      viruses,
      fuel: 100,
      score: 0,
      distance: 0,
      gasPressed: false,
      brakePressed: false,
      crashed: false,
      rpm: 0,
      boost: 0,
      frontSuspension: 0,
      rearSuspension: 0,
      frontSuspensionVel: 0,
      rearSuspensionVel: 0,
      bodyAngleVel: 0,
      timeLeft: GAME_DURATION,
      lastTime: Date.now(),
    }
    
    setScore(0)
    setDistance(0)
    setFuel(100)
    setTimeLeft(GAME_DURATION)
    setGameState("playing")
  }, [generateTerrain, generateViruses, getTerrainYAtX])

  useEffect(() => {
    if (gameState !== "playing") return

    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationId: number

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") {
        gameRef.current.gasPressed = true
      }
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") {
        gameRef.current.brakePressed = true
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") {
        gameRef.current.gasPressed = false
      }
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") {
        gameRef.current.brakePressed = false
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    const drawCar = (x: number, y: number, angle: number) => {
      ctx.save()
      ctx.translate(x - gameRef.current.cameraX, y)
      ctx.rotate(angle)

      const wheelRotation = gameRef.current.wheelAngle

      // Car shadow
      ctx.fillStyle = "rgba(0, 0, 0, 0.4)"
      ctx.beginPath()
      ctx.ellipse(0, 28, 75, 12, 0, 0, Math.PI * 2)
      ctx.fill()

      // Suspension springs (back)
      const rearSusp = gameRef.current.rearSuspension
      const frontSusp = gameRef.current.frontSuspension
      
      ctx.strokeStyle = "#4B5563"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(-45, 2)
      const rearSpringHeight = 20 - rearSusp * 0.5
      for (let i = 0; i < 5; i++) {
        ctx.lineTo(-45 + (i % 2 === 0 ? 6 : -6), 2 + i * (rearSpringHeight / 5))
      }
      ctx.stroke()

      // Suspension springs (front)
      ctx.beginPath()
      ctx.moveTo(50, 2)
      const frontSpringHeight = 20 - frontSusp * 0.5
      for (let i = 0; i < 5; i++) {
        ctx.lineTo(50 + (i % 2 === 0 ? 6 : -6), 2 + i * (frontSpringHeight / 5))
      }
      ctx.stroke()

      // Car undercarriage
      ctx.fillStyle = "#1F2937"
      ctx.fillRect(-60, 8, 130, 8)

      // Car body - main chassis
      const bodyGradient = ctx.createLinearGradient(-70, -45, -70, 15)
      bodyGradient.addColorStop(0, "#60A5FA")
      bodyGradient.addColorStop(0.3, "#3B82F6")
      bodyGradient.addColorStop(0.7, "#2563EB")
      bodyGradient.addColorStop(1, "#1D4ED8")
      
      ctx.fillStyle = bodyGradient
      ctx.beginPath()
      ctx.moveTo(-70, 8)
      ctx.lineTo(-70, -15)
      ctx.lineTo(-55, -25)
      ctx.quadraticCurveTo(-40, -30, -20, -30)
      ctx.lineTo(15, -30)
      ctx.quadraticCurveTo(25, -30, 35, -45)
      ctx.lineTo(65, -45)
      ctx.quadraticCurveTo(75, -45, 75, -30)
      ctx.lineTo(75, 8)
      ctx.closePath()
      ctx.fill()

      // Body outline
      ctx.strokeStyle = "#1E40AF"
      ctx.lineWidth = 2
      ctx.stroke()

      // Hood detail line
      ctx.strokeStyle = "#1E40AF"
      ctx.lineWidth = 1.5
      ctx.beginPath()
      ctx.moveTo(-65, -5)
      ctx.lineTo(-55, -5)
      ctx.stroke()

      // Side panel detail
      ctx.beginPath()
      ctx.moveTo(-60, 0)
      ctx.lineTo(70, 0)
      ctx.stroke()

      // Door line
      ctx.beginPath()
      ctx.moveTo(0, -28)
      ctx.lineTo(0, 5)
      ctx.stroke()

      // Door handle
      ctx.fillStyle = "#93C5FD"
      ctx.fillRect(5, -12, 12, 4)

      // Window frame
      ctx.fillStyle = "#1E40AF"
      ctx.fillRect(-18, -28, 85, 3)

      // Windshield
      const windowGradient = ctx.createLinearGradient(0, -45, 0, -15)
      windowGradient.addColorStop(0, "rgba(147, 197, 253, 0.9)")
      windowGradient.addColorStop(1, "rgba(96, 165, 250, 0.7)")
      
      ctx.fillStyle = windowGradient
      ctx.beginPath()
      ctx.moveTo(-15, -28)
      ctx.lineTo(10, -28)
      ctx.quadraticCurveTo(18, -28, 28, -43)
      ctx.lineTo(60, -43)
      ctx.lineTo(60, -28)
      ctx.lineTo(-15, -28)
      ctx.closePath()
      ctx.fill()

      // Window reflection
      ctx.strokeStyle = "rgba(255, 255, 255, 0.4)"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(-10, -35)
      ctx.lineTo(5, -30)
      ctx.stroke()

      // Driver
      ctx.fillStyle = "#FBBF24"
      ctx.beginPath()
      ctx.arc(25, -34, 9, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = "#F59E0B"
      ctx.lineWidth = 1.5
      ctx.stroke()
      
      // Cap
      ctx.fillStyle = "#DC2626"
      ctx.beginPath()
      ctx.arc(25, -38, 8, Math.PI, 0)
      ctx.fill()
      ctx.fillRect(17, -38, 16, 3)
      ctx.fillStyle = "#B91C1C"
      ctx.fillRect(25, -38, 12, 3)
      
      // Face
      ctx.fillStyle = "#1F2937"
      ctx.beginPath()
      ctx.arc(28, -35, 1.5, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.strokeStyle = "#92400E"
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.arc(27, -31, 3, 0.2, Math.PI - 0.2)
      ctx.stroke()
      
      // Body
      ctx.fillStyle = "#DC2626"
      ctx.fillRect(18, -26, 14, 12)
      
      // Arms
      ctx.fillStyle = "#FBBF24"
      ctx.beginPath()
      ctx.moveTo(20, -20)
      ctx.lineTo(10, -15)
      ctx.lineTo(12, -12)
      ctx.lineTo(22, -17)
      ctx.closePath()
      ctx.fill()

      // Steering wheel
      ctx.strokeStyle = "#1F2937"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.arc(8, -15, 6, 0, Math.PI * 2)
      ctx.stroke()

      // Roll cage
      ctx.strokeStyle = "#6B7280"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(-15, -28)
      ctx.lineTo(-15, 5)
      ctx.moveTo(65, -43)
      ctx.lineTo(65, 5)
      ctx.stroke()

      // Headlights
      ctx.fillStyle = "#FEF3C7"
      ctx.shadowColor = "#FEF08A"
      ctx.shadowBlur = 10
      ctx.beginPath()
      ctx.ellipse(72, -15, 6, 8, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.shadowBlur = 0

      ctx.fillStyle = "#FBBF24"
      ctx.beginPath()
      ctx.arc(72, -15, 3, 0, Math.PI * 2)
      ctx.fill()

      // Tail lights
      ctx.fillStyle = "#EF4444"
      ctx.shadowColor = "#EF4444"
      ctx.shadowBlur = 8
      ctx.fillRect(-72, -18, 5, 12)
      ctx.shadowBlur = 0

      // Exhaust pipe
      ctx.fillStyle = "#4B5563"
      ctx.fillRect(-80, 2, 15, 6)
      ctx.fillStyle = "#374151"
      ctx.beginPath()
      ctx.arc(-80, 5, 3, 0, Math.PI * 2)
      ctx.fill()
      
      // Exhaust smoke
      if (gameRef.current.gasPressed) {
        ctx.fillStyle = "rgba(156, 163, 175, 0.6)"
        ctx.beginPath()
        ctx.arc(-88, 5, 5, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = "rgba(156, 163, 175, 0.3)"
        ctx.beginPath()
        ctx.arc(-98, 4, 7, 0, Math.PI * 2)
        ctx.fill()
      }

      // Antenna
      ctx.strokeStyle = "#1F2937"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(-60, -25)
      ctx.lineTo(-65, -50)
      ctx.stroke()
      ctx.fillStyle = "#EF4444"
      ctx.beginPath()
      ctx.arc(-65, -52, 3, 0, Math.PI * 2)
      ctx.fill()

      // Wheels
      const wheelRadius = 22

      // Back wheel
      ctx.save()
      ctx.translate(-45, 18)
      ctx.rotate(wheelRotation)
      
      ctx.fillStyle = "#1F2937"
      ctx.beginPath()
      ctx.arc(0, 0, wheelRadius, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.strokeStyle = "#374151"
      ctx.lineWidth = 2
      for (let i = 0; i < 12; i++) {
        const treadAngle = (i * Math.PI * 2) / 12
        ctx.beginPath()
        ctx.moveTo(Math.cos(treadAngle) * (wheelRadius - 3), Math.sin(treadAngle) * (wheelRadius - 3))
        ctx.lineTo(Math.cos(treadAngle) * wheelRadius, Math.sin(treadAngle) * wheelRadius)
        ctx.stroke()
      }
      
      ctx.fillStyle = "#60A5FA"
      ctx.beginPath()
      ctx.arc(0, 0, 12, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.fillStyle = "#1E40AF"
      ctx.beginPath()
      ctx.arc(0, 0, 6, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.strokeStyle = "#93C5FD"
      ctx.lineWidth = 3
      for (let i = 0; i < 5; i++) {
        const spokeAngle = (i * Math.PI * 2) / 5
        ctx.beginPath()
        ctx.moveTo(Math.cos(spokeAngle) * 6, Math.sin(spokeAngle) * 6)
        ctx.lineTo(Math.cos(spokeAngle) * 11, Math.sin(spokeAngle) * 11)
        ctx.stroke()
      }
      
      ctx.fillStyle = "#3B82F6"
      ctx.beginPath()
      ctx.arc(0, 0, 3, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.restore()

      // Front wheel
      ctx.save()
      ctx.translate(50, 18)
      ctx.rotate(wheelRotation)
      
      ctx.fillStyle = "#1F2937"
      ctx.beginPath()
      ctx.arc(0, 0, wheelRadius, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.strokeStyle = "#374151"
      ctx.lineWidth = 2
      for (let i = 0; i < 12; i++) {
        const treadAngle = (i * Math.PI * 2) / 12
        ctx.beginPath()
        ctx.moveTo(Math.cos(treadAngle) * (wheelRadius - 3), Math.sin(treadAngle) * (wheelRadius - 3))
        ctx.lineTo(Math.cos(treadAngle) * wheelRadius, Math.sin(treadAngle) * wheelRadius)
        ctx.stroke()
      }
      
      ctx.fillStyle = "#60A5FA"
      ctx.beginPath()
      ctx.arc(0, 0, 12, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.fillStyle = "#1E40AF"
      ctx.beginPath()
      ctx.arc(0, 0, 6, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.strokeStyle = "#93C5FD"
      ctx.lineWidth = 3
      for (let i = 0; i < 5; i++) {
        const spokeAngle = (i * Math.PI * 2) / 5
        ctx.beginPath()
        ctx.moveTo(Math.cos(spokeAngle) * 6, Math.sin(spokeAngle) * 6)
        ctx.lineTo(Math.cos(spokeAngle) * 11, Math.sin(spokeAngle) * 11)
        ctx.stroke()
      }
      
      ctx.fillStyle = "#3B82F6"
      ctx.beginPath()
      ctx.arc(0, 0, 3, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.restore()

      ctx.restore()
    }

    const drawVirus = (x: number, y: number, type: number, value: number) => {
      ctx.save()
      ctx.translate(x - gameRef.current.cameraX, y)
      
      const floatOffset = Math.sin(Date.now() * 0.005 + x) * 5
      ctx.translate(0, floatOffset)
      
      const colors = [
        ["#EF4444", "#DC2626"],
        ["#22C55E", "#16A34A"],
        ["#3B82F6", "#2563EB"],
      ]
      
      const [main, dark] = colors[type] || colors[0]
      
      ctx.shadowColor = main
      ctx.shadowBlur = 20
      
      ctx.fillStyle = main
      ctx.beginPath()
      ctx.arc(0, 0, 18, 0, Math.PI * 2)
      ctx.fill()
      
      const innerGradient = ctx.createRadialGradient(-5, -5, 0, 0, 0, 18)
      innerGradient.addColorStop(0, "rgba(255, 255, 255, 0.4)")
      innerGradient.addColorStop(1, "transparent")
      ctx.fillStyle = innerGradient
      ctx.beginPath()
      ctx.arc(0, 0, 18, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.fillStyle = dark
      for (let i = 0; i < 8; i++) {
        const angle = (i * Math.PI * 2) / 8 + Date.now() * 0.001
        ctx.beginPath()
        ctx.moveTo(Math.cos(angle) * 14, Math.sin(angle) * 14)
        ctx.lineTo(Math.cos(angle) * 26, Math.sin(angle) * 26)
        ctx.lineTo(Math.cos(angle + 0.25) * 14, Math.sin(angle + 0.25) * 14)
        ctx.fill()
        
        ctx.beginPath()
        ctx.arc(Math.cos(angle) * 26, Math.sin(angle) * 26, 5, 0, Math.PI * 2)
        ctx.fill()
      }
      
      ctx.shadowBlur = 0
      ctx.fillStyle = "#fff"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(value.toString(), 0, 0)
      
      ctx.restore()
    }

    const drawTerrain = () => {
      const { terrain, cameraX } = gameRef.current
      
      const groundGradient = ctx.createLinearGradient(0, 300, 0, canvas.height)
      groundGradient.addColorStop(0, "#4a1c4a")
      groundGradient.addColorStop(0.3, "#5d2e46")
      groundGradient.addColorStop(1, "#2d1a2d")
      
      ctx.fillStyle = groundGradient
      ctx.beginPath()
      ctx.moveTo(0, canvas.height)
      
      for (const point of terrain) {
        const screenX = point.x - cameraX
        if (screenX > -100 && screenX < canvas.width + 100) {
          ctx.lineTo(screenX, point.y)
        }
      }
      
      ctx.lineTo(canvas.width, canvas.height)
      ctx.closePath()
      ctx.fill()

      ctx.fillStyle = "rgba(90, 40, 70, 0.5)"
      for (let i = 0; i < 100; i++) {
        const dotX = ((i * 97 + cameraX * 0.5) % canvas.width)
        const dotY = 380 + (i * 43) % 120
        ctx.beginPath()
        ctx.arc(dotX, dotY, 3 + (i % 3), 0, Math.PI * 2)
        ctx.fill()
      }

      ctx.fillStyle = "#166534"
      ctx.beginPath()
      let started = false
      
      for (const point of terrain) {
        const screenX = point.x - cameraX
        if (screenX > -100 && screenX < canvas.width + 100) {
          if (!started) {
            ctx.moveTo(screenX, point.y)
            started = true
          } else {
            ctx.lineTo(screenX, point.y)
          }
        }
      }
      
      const lastVisiblePoint = terrain.find(p => (p.x - cameraX) > canvas.width) || terrain[terrain.length - 1]
      
      ctx.lineTo(lastVisiblePoint.x - cameraX, lastVisiblePoint.y + 18)
      for (let i = terrain.length - 1; i >= 0; i--) {
        const screenX = terrain[i].x - cameraX
        if (screenX > -100 && screenX < canvas.width + 100) {
          ctx.lineTo(screenX, terrain[i].y + 18)
        }
      }
      ctx.closePath()
      ctx.fill()
      
      ctx.fillStyle = "#15803d"
      ctx.beginPath()
      started = false
      for (const point of terrain) {
        const screenX = point.x - cameraX
        if (screenX > -100 && screenX < canvas.width + 100) {
          if (!started) {
            ctx.moveTo(screenX, point.y)
            started = true
          } else {
            ctx.lineTo(screenX, point.y)
          }
        }
      }
      const lastPoint = terrain.find(p => (p.x - cameraX) > canvas.width) || terrain[terrain.length - 1]
      ctx.lineTo(lastPoint.x - cameraX, lastPoint.y + 6)
      for (let i = terrain.length - 1; i >= 0; i--) {
        const screenX = terrain[i].x - cameraX
        if (screenX > -100 && screenX < canvas.width + 100) {
          ctx.lineTo(screenX, terrain[i].y + 6)
        }
      }
      ctx.closePath()
      ctx.fill()

      // Draw grass blades - using seeded positions based on terrain x coordinate for consistency
      ctx.strokeStyle = "#14532d"
      ctx.lineWidth = 2
      for (const point of terrain) {
        const screenX = point.x - cameraX
        if (screenX > -50 && screenX < canvas.width + 50) {
          // Use terrain x position as seed for consistent grass placement
          const seed = point.x
          for (let g = 0; g < 3; g++) {
            const seededRandom1 = Math.sin(seed * 0.1 + g * 100) * 0.5 + 0.5
            const seededRandom2 = Math.sin(seed * 0.2 + g * 200) * 0.5 + 0.5
            const seededRandom3 = Math.sin(seed * 0.3 + g * 300) * 0.5 + 0.5
            const seededRandom4 = Math.sin(seed * 0.4 + g * 400) * 0.5 + 0.5
            
            if (seededRandom1 > 0.5) {
              const grassX = screenX + (seededRandom2 - 0.5) * 20
              const grassHeight = 12 + seededRandom4 * 8
              ctx.beginPath()
              ctx.moveTo(grassX, point.y)
              ctx.quadraticCurveTo(
                grassX + (seededRandom3 - 0.5) * 8,
                point.y - grassHeight / 2,
                grassX + (seededRandom2 - 0.5) * 6,
                point.y - grassHeight
              )
              ctx.stroke()
            }
          }
        }
      }
    }

    const drawBackground = () => {
      const skyGradient = ctx.createLinearGradient(0, 0, 0, canvas.height * 0.7)
      skyGradient.addColorStop(0, "#1e1b4b")
      skyGradient.addColorStop(0.3, "#4c1d95")
      skyGradient.addColorStop(0.5, "#7c3aed")
      skyGradient.addColorStop(0.7, "#f97316")
      skyGradient.addColorStop(1, "#fbbf24")
      ctx.fillStyle = skyGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
      for (let i = 0; i < 50; i++) {
        const starX = (i * 73 + gameRef.current.cameraX * 0.01) % canvas.width
        const starY = 20 + (i * 31) % 120
        const starSize = 0.5 + (i % 3) * 0.5
        const twinkle = Math.sin(Date.now() * 0.003 + i) * 0.3 + 0.7
        ctx.globalAlpha = twinkle
        ctx.beginPath()
        ctx.arc(starX, starY, starSize, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.globalAlpha = 1

      const sunX = canvas.width - 150
      const sunY = 200
      const sunGradient = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, 60)
      sunGradient.addColorStop(0, "#fef3c7")
      sunGradient.addColorStop(0.3, "#fbbf24")
      sunGradient.addColorStop(0.7, "#f97316")
      sunGradient.addColorStop(1, "transparent")
      ctx.fillStyle = sunGradient
      ctx.beginPath()
      ctx.arc(sunX, sunY, 60, 0, Math.PI * 2)
      ctx.fill()

      const virusPositions = [
        { baseX: 100, baseY: 60, type: 0 },
        { baseX: 300, baseY: 90, type: 1 },
        { baseX: 550, baseY: 50, type: 2 },
        { baseX: 750, baseY: 100, type: 0 },
        { baseX: 900, baseY: 70, type: 1 },
      ]
      
      virusPositions.forEach((virus, i) => {
        let virusX = ((virus.baseX - gameRef.current.cameraX * 0.03) % (canvas.width + 200))
        if (virusX < -50) virusX += canvas.width + 200
        const floatY = virus.baseY + Math.sin(Date.now() * 0.002 + i * 2) * 10
        
        const colors = [
          ["#EF4444", "#DC2626"],
          ["#22C55E", "#16A34A"],
          ["#3B82F6", "#2563EB"],
        ]
        const [main, dark] = colors[virus.type]
        
        ctx.save()
        ctx.globalAlpha = 0.6
        ctx.translate(virusX, floatY)
        
        ctx.shadowColor = main
        ctx.shadowBlur = 15
        
        ctx.fillStyle = main
        ctx.beginPath()
        ctx.arc(0, 0, 15, 0, Math.PI * 2)
        ctx.fill()
        
        ctx.fillStyle = dark
        for (let j = 0; j < 6; j++) {
          const angle = (j * Math.PI * 2) / 6 + Date.now() * 0.001
          ctx.beginPath()
          ctx.arc(Math.cos(angle) * 20, Math.sin(angle) * 20, 4, 0, Math.PI * 2)
          ctx.fill()
        }
        
        ctx.restore()
      })

      const hillGradient = ctx.createLinearGradient(0, 180, 0, 300)
      hillGradient.addColorStop(0, "#581c87")
      hillGradient.addColorStop(1, "#7c3aed")
      ctx.fillStyle = hillGradient
      ctx.beginPath()
      ctx.moveTo(0, 280)
      for (let x = 0; x <= canvas.width; x += 40) {
        const y = 220 + Math.sin((x + gameRef.current.cameraX * 0.08) * 0.008) * 60
        ctx.lineTo(x, y)
      }
      ctx.lineTo(canvas.width, canvas.height)
      ctx.lineTo(0, canvas.height)
      ctx.closePath()
      ctx.fill()
    }

    const drawPedals = () => {
      const { gasPressed, brakePressed } = gameRef.current
      
      const brakeX = 80
      const brakeY = canvas.height - 80
      
      ctx.fillStyle = brakePressed ? "#9CA3AF" : "#D1D5DB"
      ctx.strokeStyle = "#6B7280"
      ctx.lineWidth = 3
      
      ctx.beginPath()
      ctx.roundRect(brakeX - 35, brakeY - 50, 70, 100, 8)
      ctx.fill()
      ctx.stroke()
      
      ctx.fillStyle = "#4B5563"
      for (let row = 0; row < 4; row++) {
        for (let col = 0; col < 3; col++) {
          ctx.beginPath()
          ctx.arc(brakeX - 15 + col * 15, brakeY - 30 + row * 20, 4, 0, Math.PI * 2)
          ctx.fill()
        }
      }
      
      ctx.fillStyle = "#1F2937"
      ctx.font = "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText("BRAKE", brakeX, brakeY + 65)

      const gasX = canvas.width - 80
      const gasY = canvas.height - 80
      
      ctx.fillStyle = gasPressed ? "#9CA3AF" : "#D1D5DB"
      
      ctx.beginPath()
      ctx.roundRect(gasX - 35, gasY - 50, 70, 100, 8)
      ctx.fill()
      ctx.stroke()
      
      ctx.fillStyle = "#4B5563"
      for (let row = 0; row < 4; row++) {
        for (let col = 0; col < 3; col++) {
          ctx.beginPath()
          ctx.arc(gasX - 15 + col * 15, gasY - 30 + row * 20, 4, 0, Math.PI * 2)
          ctx.fill()
        }
      }
      
      ctx.fillStyle = "#1F2937"
      ctx.font = "bold 14px sans-serif"
      ctx.fillText("GAS", gasX, gasY + 65)
    }

    const drawGauges = () => {
      const { rpm, boost } = gameRef.current
      
      const rpmX = canvas.width / 2 - 80
      const rpmY = canvas.height - 70
      const gaugeRadius = 50
      
      ctx.fillStyle = "#1F2937"
      ctx.beginPath()
      ctx.arc(rpmX, rpmY, gaugeRadius, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.strokeStyle = "#374151"
      ctx.lineWidth = 4
      ctx.stroke()
      
      ctx.strokeStyle = "#4B5563"
      ctx.lineWidth = 8
      ctx.beginPath()
      ctx.arc(rpmX, rpmY, gaugeRadius - 10, Math.PI * 0.75, Math.PI * 2.25)
      ctx.stroke()
      
      ctx.strokeStyle = "#EF4444"
      ctx.beginPath()
      ctx.arc(rpmX, rpmY, gaugeRadius - 10, Math.PI * 1.9, Math.PI * 2.25)
      ctx.stroke()
      
      const rpmAngle = Math.PI * 0.75 + (rpm / 100) * Math.PI * 1.5
      ctx.strokeStyle = "#fff"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(rpmX, rpmY)
      ctx.lineTo(
        rpmX + Math.cos(rpmAngle) * (gaugeRadius - 15),
        rpmY + Math.sin(rpmAngle) * (gaugeRadius - 15)
      )
      ctx.stroke()
      
      ctx.fillStyle = "#6B7280"
      ctx.beginPath()
      ctx.arc(rpmX, rpmY, 8, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.fillStyle = "#fff"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText("RPM", rpmX, rpmY + 25)

      const boostX = canvas.width / 2 + 80
      const boostY = canvas.height - 70
      
      ctx.fillStyle = "#1F2937"
      ctx.beginPath()
      ctx.arc(boostX, boostY, gaugeRadius, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.strokeStyle = "#374151"
      ctx.lineWidth = 4
      ctx.stroke()
      
      ctx.strokeStyle = "#4B5563"
      ctx.lineWidth = 8
      ctx.beginPath()
      ctx.arc(boostX, boostY, gaugeRadius - 10, Math.PI * 0.75, Math.PI * 2.25)
      ctx.stroke()
      
      ctx.strokeStyle = "#3B82F6"
      ctx.beginPath()
      ctx.arc(boostX, boostY, gaugeRadius - 10, Math.PI * 0.75, Math.PI * 0.75 + (boost / 100) * Math.PI * 1.5)
      ctx.stroke()
      
      const boostAngle = Math.PI * 0.75 + (boost / 100) * Math.PI * 1.5
      ctx.strokeStyle = "#fff"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(boostX, boostY)
      ctx.lineTo(
        boostX + Math.cos(boostAngle) * (gaugeRadius - 15),
        boostY + Math.sin(boostAngle) * (gaugeRadius - 15)
      )
      ctx.stroke()
      
      ctx.fillStyle = "#6B7280"
      ctx.beginPath()
      ctx.arc(boostX, boostY, 8, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.fillStyle = "#fff"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText("BOOST", boostX, boostY + 25)

      const fuelX = canvas.width / 2
      const fuelY = canvas.height - 130
      
      ctx.fillStyle = "rgba(31, 41, 55, 0.8)"
      ctx.beginPath()
      ctx.arc(fuelX, fuelY, 25, 0, Math.PI * 2)
      ctx.fill()
      
      ctx.fillStyle = "#3B82F6"
      ctx.beginPath()
      ctx.roundRect(fuelX - 8, fuelY - 10, 16, 20, 3)
      ctx.fill()
      ctx.fillRect(fuelX - 4, fuelY - 14, 8, 6)
      
      ctx.fillStyle = "#fff"
      ctx.font = "bold 16px sans-serif"
      ctx.fillText(Math.floor(gameRef.current.fuel).toString(), fuelX + 35, fuelY + 5)
    }

    const drawUI = () => {
      // Timer (top center)
      const minutes = Math.floor(gameRef.current.timeLeft / 60)
      const seconds = Math.floor(gameRef.current.timeLeft % 60)
      const timeString = `${minutes}:${seconds.toString().padStart(2, '0')}`
      
      ctx.fillStyle = gameRef.current.timeLeft <= 30 ? "#EF4444" : "#fff"
      ctx.font = "bold 36px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(timeString, canvas.width / 2, 50)
      
      // Distance bar
      ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
      ctx.fillRect(canvas.width / 2 - 100, 60, 200, 8)
      ctx.fillStyle = "#22C55E"
      ctx.fillRect(canvas.width / 2 - 100, 60, Math.min(200, gameRef.current.distance / 50), 8)
      
      ctx.fillStyle = "#fff"
      ctx.font = "bold 20px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(`${Math.floor(gameRef.current.distance)}m`, canvas.width / 2, 95)

      // Fuel bar (top left)
      ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
      ctx.fillRect(20, 20, 150, 25)
      
      const fuelPercent = gameRef.current.fuel / 100
      const fuelGradient = ctx.createLinearGradient(22, 0, 168, 0)
      if (fuelPercent > 0.5) {
        fuelGradient.addColorStop(0, "#22C55E")
        fuelGradient.addColorStop(1, "#22C55E")
      } else if (fuelPercent > 0.25) {
        fuelGradient.addColorStop(0, "#FBBF24")
        fuelGradient.addColorStop(1, "#FBBF24")
      } else {
        fuelGradient.addColorStop(0, "#EF4444")
        fuelGradient.addColorStop(1, "#EF4444")
      }
      
      ctx.fillStyle = fuelGradient
      ctx.fillRect(22, 22, 146 * fuelPercent, 21)
      
      ctx.strokeStyle = "#fff"
      ctx.lineWidth = 2
      ctx.strokeRect(20, 20, 150, 25)

      // Score (top left under fuel)
      ctx.fillStyle = "#fff"
      ctx.font = "bold 32px sans-serif"
      ctx.textAlign = "left"
      ctx.fillText(gameRef.current.score.toString(), 20, 80)
      
      // Virus count icon
      ctx.fillStyle = "#3B82F6"
      ctx.beginPath()
      ctx.arc(35, 105, 12, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = "#fff"
      ctx.font = "bold 20px sans-serif"
      ctx.fillText(Math.floor(gameRef.current.score / 100).toString(), 55, 112)
    }

    const gameLoop = () => {
      const game = gameRef.current
      
      // Update timer
      const now = Date.now()
      const deltaTime = (now - game.lastTime) / 1000
      game.lastTime = now
      game.timeLeft -= deltaTime
      setTimeLeft(Math.max(0, game.timeLeft))
      
      // Check if time is up
      if (game.timeLeft <= 0) {
        saveToLeaderboard(game.score, Math.floor(game.distance))
        setGameState("gameover")
        if (game.score > highScore) {
          setHighScore(game.score)
        }
        return
      }
      
      if (game.crashed) {
        saveToLeaderboard(game.score, Math.floor(game.distance))
        setGameState("gameover")
        if (game.score > highScore) {
          setHighScore(game.score)
        }
        return
      }

      const gravity = 0.35
      const friction = 0.985
      const enginePower = 0.32
      
      const suspensionStiffness = 0.15
      const suspensionDamping = 0.3
      const maxSuspensionTravel = 15

      const frontWheelX = game.carX + 50
      const backWheelX = game.carX - 45
      const frontTerrainY = getTerrainYAtX(frontWheelX, game.terrain)
      const backTerrainY = getTerrainYAtX(backWheelX, game.terrain)
      
      const carBaseY = game.carY
      const wheelRadius = 22
      
      const frontWheelRestY = carBaseY + 18
      const frontGroundContact = frontTerrainY - wheelRadius
      const frontCompression = Math.max(0, frontWheelRestY - frontGroundContact)
      
      const rearWheelRestY = carBaseY + 18
      const rearGroundContact = backTerrainY - wheelRadius
      const rearCompression = Math.max(0, rearWheelRestY - rearGroundContact)
      
      const frontSpringForce = frontCompression * suspensionStiffness - game.frontSuspensionVel * suspensionDamping
      const rearSpringForce = rearCompression * suspensionStiffness - game.rearSuspensionVel * suspensionDamping
      
      game.frontSuspensionVel += frontSpringForce
      game.rearSuspensionVel += rearSpringForce
      
      game.frontSuspension = Math.max(-maxSuspensionTravel, Math.min(maxSuspensionTravel, game.frontSuspension + game.frontSuspensionVel))
      game.rearSuspension = Math.max(-maxSuspensionTravel, Math.min(maxSuspensionTravel, game.rearSuspension + game.rearSuspensionVel))
      
      const targetAngle = Math.atan2(frontTerrainY - backTerrainY, 95)
      game.bodyAngleVel += (targetAngle - game.carAngle) * 0.05
      game.bodyAngleVel *= 0.85
      game.carAngle += game.bodyAngleVel

      if (game.gasPressed && game.fuel > 0) {
        game.rpm = Math.min(100, game.rpm + 3)
        game.boost = Math.min(100, game.boost + 1)
        game.velocityX += Math.cos(game.carAngle) * enginePower
        game.fuel -= 0.12
        setFuel(Math.max(0, game.fuel))
      } else {
        game.rpm = Math.max(0, game.rpm - 2)
        game.boost = Math.max(0, game.boost - 0.5)
        game.fuel -= 0.02
        setFuel(Math.max(0, game.fuel))
      }
      
      if (game.brakePressed) {
        game.velocityX *= 0.94
        game.rpm = Math.max(0, game.rpm - 5)
      }

      game.velocityY += gravity
      game.velocityX *= friction
      
      game.carX += game.velocityX
      game.carY += game.velocityY

      game.wheelAngle += game.velocityX * 0.05

      const avgSuspensionOffset = (game.frontSuspension + game.rearSuspension) / 2
      const groundY = getTerrainYAtX(game.carX, game.terrain) - 35 + avgSuspensionOffset
      if (game.carY > groundY) {
        game.carY = groundY
        game.velocityY *= -0.1
        if (game.velocityY > -0.5) game.velocityY = 0
      }

      if (Math.abs(game.carAngle) > Math.PI * 0.6) {
        game.crashed = true
      }

      game.cameraX = game.carX - 250

      game.distance = Math.max(0, (game.carX - 200) / 10)
      setDistance(Math.floor(game.distance))

      for (const virus of game.viruses) {
        if (!virus.collected) {
          const dx = game.carX - virus.x
          const dy = game.carY - virus.y
          const dist = Math.sqrt(dx * dx + dy * dy)
          
          // Increased collection radius to 70 for easier pickup
          if (dist < 70) {
            virus.collected = true
            game.score += virus.value
            game.fuel = Math.min(100, game.fuel + 8)
            setScore(game.score)
            setFuel(Math.min(100, game.fuel))
          }
        }
      }

      if (game.fuel <= 0 && Math.abs(game.velocityX) < 0.1) {
        game.crashed = true
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      drawBackground()
      drawTerrain()
      
      for (const virus of game.viruses) {
        if (!virus.collected) {
          const screenX = virus.x - game.cameraX
          if (screenX > -50 && screenX < canvas.width + 50) {
            drawVirus(virus.x, virus.y, virus.type, virus.value)
          }
        }
      }
      
      drawCar(game.carX, game.carY, game.carAngle)
      drawUI()
      drawPedals()
      drawGauges()

      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [gameState, getTerrainYAtX, highScore, saveToLeaderboard])

  const handleTouchStart = (pedal: "gas" | "brake") => {
    if (pedal === "gas") {
      gameRef.current.gasPressed = true
    } else {
      gameRef.current.brakePressed = true
    }
  }

  const handleTouchEnd = (pedal: "gas" | "brake") => {
    if (pedal === "gas") {
      gameRef.current.gasPressed = false
    } else {
      gameRef.current.brakePressed = false
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div className="min-h-screen gradient-bg-animated wave-lines flex flex-col">
      <header className="glass border-b border-purple-500/20 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="text-purple-300 hover:text-white hover:bg-purple-500/20">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Назад
            </Button>
          </Link>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Virus Hill Climb
          </h1>
          <div className="flex items-center gap-4 text-purple-300">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-cyan-400" />
              <span className={`font-bold ${timeLeft <= 30 ? 'text-red-400' : ''}`}>{formatTime(timeLeft)}</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span className="font-bold">{score}</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 flex items-center justify-center p-4">
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={1000}
            height={550}
            className="rounded-2xl border-4 border-purple-500/30 shadow-2xl"
          />
          
          {gameState === "playing" && (
            <>
              <div
                className="absolute left-0 bottom-0 w-1/3 h-1/3 opacity-0"
                onTouchStart={() => handleTouchStart("brake")}
                onTouchEnd={() => handleTouchEnd("brake")}
                onMouseDown={() => handleTouchStart("brake")}
                onMouseUp={() => handleTouchEnd("brake")}
                onMouseLeave={() => handleTouchEnd("brake")}
              />
              <div
                className="absolute right-0 bottom-0 w-1/3 h-1/3 opacity-0"
                onTouchStart={() => handleTouchStart("gas")}
                onTouchEnd={() => handleTouchEnd("gas")}
                onMouseDown={() => handleTouchStart("gas")}
                onMouseUp={() => handleTouchEnd("gas")}
                onMouseLeave={() => handleTouchEnd("gas")}
              />
            </>
          )}
          
          {gameState === "menu" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center glass rounded-2xl">
              <div className="flex items-center gap-4 mb-8">
                <Fuel className="w-16 h-16 text-blue-400" />
                <h2 className="text-4xl font-bold text-white">Virus Hill Climb</h2>
              </div>
              <p className="text-purple-300 mb-4 text-center max-w-md">
                Собирай вирусы для топлива и очков! Не переворачивайся и не останавливайся без топлива.
              </p>
              <p className="text-cyan-400 mb-8 text-center">
                <Clock className="w-5 h-5 inline-block mr-2" />
                Время: 2 минуты
              </p>
              <Button
                onClick={startGame}
                className="px-12 py-6 text-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 rounded-xl"
              >
                <Play className="w-8 h-8 mr-3" />
                Играть
              </Button>
              <p className="text-purple-400/60 mt-6 text-sm">
                Клавиши A/D или стрелки, или нажимайте на педали
              </p>
            </div>
          )}

          {gameState === "gameover" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center glass rounded-2xl">
              <h2 className="text-4xl font-bold text-cyan-400 mb-4">
                {timeLeft <= 0 ? "Время вышло!" : "Игра окончена!"}
              </h2>
              <div className="text-center mb-8">
                <p className="text-2xl text-white mb-2">Очки: <span className="text-cyan-400">{score}</span></p>
                <p className="text-lg text-purple-300">Дистанция: {distance}m</p>
                <p className="text-lg text-yellow-400">Рекорд: {highScore}</p>
                <p className="text-sm text-green-400 mt-2">Результат сохранен в рейтинг!</p>
              </div>
              <Button
                onClick={startGame}
                className="px-8 py-4 text-lg bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 rounded-xl"
              >
                <RotateCcw className="w-6 h-6 mr-2" />
                Играть снова
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
